const e={};throw new Error('Could not resolve "katex/contrib/mhchem" imported by "markstream-vue".');export{e as default};
