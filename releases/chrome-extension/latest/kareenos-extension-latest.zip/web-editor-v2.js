var webEditorV2=(function(){"use strict";var jm=Object.defineProperty,Km=Object.defineProperties;var qm=Object.getOwnPropertyDescriptors;var Wr=Object.getOwnPropertySymbols;var ja=Object.prototype.hasOwnProperty,Ka=Object.prototype.propertyIsEnumerable;var si=(Ke,qe,_e)=>qe in Ke?jm(Ke,qe,{enumerable:!0,configurable:!0,writable:!0,value:_e}):Ke[qe]=_e,je=(Ke,qe)=>{for(var _e in qe||(qe={}))ja.call(qe,_e)&&si(Ke,_e,qe[_e]);if(Wr)for(var _e of Wr(qe))Ka.call(qe,_e)&&si(Ke,_e,qe[_e]);return Ke},mt=(Ke,qe)=>Km(Ke,qm(qe));var qa=(Ke,qe)=>{var _e={};for(var ht in Ke)ja.call(Ke,ht)&&qe.indexOf(ht)<0&&(_e[ht]=Ke[ht]);if(Ke!=null&&Wr)for(var ht of Wr(Ke))qe.indexOf(ht)<0&&Ka.call(Ke,ht)&&(_e[ht]=Ke[ht]);return _e};var Dt=(Ke,qe,_e)=>si(Ke,typeof qe!="symbol"?qe+"":qe,_e);var Qe=(Ke,qe,_e)=>new Promise((ht,Tn)=>{var Yn=Pt=>{try{Je(_e.next(Pt))}catch(hn){Tn(hn)}},Xr=Pt=>{try{Je(_e.throw(Pt))}catch(hn){Tn(hn)}},Je=Pt=>Pt.done?ht(Pt.value):Promise.resolve(Pt.value).then(Yn,Xr);Je((_e=_e.apply(Ke,qe)).next())});var za,Ua;function Ke(e){return e==null||typeof e=="function"?{main:e}:e}const qe=2,_e="[WebEditorV2]",ht="__mcp_web_editor_v2_host__",Tn="__mcp_web_editor_v2_overlay__",Yn="__mcp_web_editor_v2_ui__",Xr=2147483647,Je={hover:"#3b82f6",selected:"#22c55e",selectionBorder:"#6366f1",dragGhost:"rgba(99, 102, 241, 0.3)",insertionLine:"#f59e0b",guideLine:"#ec4899",distanceLabelBg:"rgba(15, 23, 42, 0.92)",distanceLabelBorder:"rgba(51, 65, 85, 0.5)",distanceLabelText:"rgba(255, 255, 255, 0.98)"},Pt=5,hn=6,Za=8,Qa=3,Ja=6,el=2,tl=30,ai=300,nl=1,rl=1,ol=1,il=4,sl='600 11px system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',al=6,ll=3,cl=4,ul=8,Ot={SWITCH_SEMANTIC_MODEL:"switch_semantic_model",GET_MODEL_STATUS:"get_model_status",UPDATE_MODEL_STATUS:"update_model_status",GET_STORAGE_STATS:"get_storage_stats",CLEAR_ALL_DATA:"clear_all_data",GET_SERVER_STATUS:"get_server_status",REFRESH_SERVER_STATUS:"refresh_server_status",SERVER_STATUS_CHANGED:"server_status_changed",INITIALIZE_SEMANTIC_ENGINE:"initialize_semantic_engine",RR_START_RECORDING:"rr_start_recording",RR_STOP_RECORDING:"rr_stop_recording",RR_PAUSE_RECORDING:"rr_pause_recording",RR_RESUME_RECORDING:"rr_resume_recording",RR_GET_RECORDING_STATUS:"rr_get_recording_status",RR_LIST_FLOWS:"rr_list_flows",RR_FLOWS_CHANGED:"rr_flows_changed",RR_GET_FLOW:"rr_get_flow",RR_DELETE_FLOW:"rr_delete_flow",RR_PUBLISH_FLOW:"rr_publish_flow",RR_UNPUBLISH_FLOW:"rr_unpublish_flow",RR_RUN_FLOW:"rr_run_flow",RR_SAVE_FLOW:"rr_save_flow",RR_EXPORT_FLOW:"rr_export_flow",RR_EXPORT_ALL:"rr_export_all",RR_IMPORT_FLOW:"rr_import_flow",RR_LIST_RUNS:"rr_list_runs",RR_LIST_TRIGGERS:"rr_list_triggers",RR_SAVE_TRIGGER:"rr_save_trigger",RR_DELETE_TRIGGER:"rr_delete_trigger",RR_REFRESH_TRIGGERS:"rr_refresh_triggers",RR_SCHEDULE_FLOW:"rr_schedule_flow",RR_UNSCHEDULE_FLOW:"rr_unschedule_flow",RR_LIST_SCHEDULES:"rr_list_schedules",ELEMENT_MARKER_LIST_ALL:"element_marker_list_all",ELEMENT_MARKER_LIST_FOR_URL:"element_marker_list_for_url",ELEMENT_MARKER_SAVE:"element_marker_save",ELEMENT_MARKER_UPDATE:"element_marker_update",ELEMENT_MARKER_DELETE:"element_marker_delete",ELEMENT_MARKER_VALIDATE:"element_marker_validate",ELEMENT_MARKER_START:"element_marker_start_from_popup",ELEMENT_PICKER_UI_EVENT:"element_picker_ui_event",ELEMENT_PICKER_FRAME_EVENT:"element_picker_frame_event",WEB_EDITOR_TOGGLE:"web_editor_toggle",WEB_EDITOR_APPLY:"web_editor_apply",WEB_EDITOR_STATUS_QUERY:"web_editor_status_query",WEB_EDITOR_APPLY_BATCH:"web_editor_apply_batch",WEB_EDITOR_TX_CHANGED:"web_editor_tx_changed",WEB_EDITOR_HIGHLIGHT_ELEMENT:"web_editor_highlight_element",WEB_EDITOR_REVERT_ELEMENT:"web_editor_revert_element",WEB_EDITOR_SELECTION_CHANGED:"web_editor_selection_changed",WEB_EDITOR_CLEAR_SELECTION:"web_editor_clear_selection",WEB_EDITOR_CANCEL_EXECUTION:"web_editor_cancel_execution",WEB_EDITOR_PROPS_REGISTER_EARLY_INJECTION:"web_editor_props_register_early_injection",WEB_EDITOR_OPEN_SOURCE:"web_editor_open_source",QUICK_PANEL_SEND_TO_AI:"quick_panel_send_to_ai",QUICK_PANEL_CANCEL_AI:"quick_panel_cancel_ai",QUICK_PANEL_TABS_QUERY:"quick_panel_tabs_query",QUICK_PANEL_TAB_ACTIVATE:"quick_panel_tab_activate",QUICK_PANEL_TAB_CLOSE:"quick_panel_tab_close"};class Pe{constructor(){Dt(this,"disposed",!1);Dt(this,"disposers",[])}get isDisposed(){return this.disposed}add(t){if(this.disposed){try{t()}catch(n){}return}this.disposers.push(t)}listen(t,n,r,o){t.addEventListener(n,r,o),this.add(()=>t.removeEventListener(n,r,o))}observeResize(t,n,r){const o=new ResizeObserver(n);return o.observe(t,r),this.add(()=>o.disconnect()),o}observeMutation(t,n,r){const o=new MutationObserver(n);return o.observe(t,r),this.add(()=>o.disconnect()),o}requestAnimationFrame(t){const n=requestAnimationFrame(t);let r=!1;const o=()=>{r||(r=!0,cancelAnimationFrame(n))};return this.add(o),o}dispose(){if(!this.disposed){this.disposed=!0;for(let t=this.disposers.length-1;t>=0;t--)try{this.disposers[t]()}catch(n){}this.disposers.length=0}}}const dl=`
  :host {
    all: initial;

    /* Design tokens aligned with attr-ui.html design spec */
    /* Surface colors */
    --we-surface-bg: #ffffff;
    --we-surface-secondary: #fafafa;

    /* Control colors - input containers use gray bg */
    --we-control-bg: #f3f3f3;
    --we-control-bg-hover: #e8e8e8;
    --we-control-border-hover: #e0e0e0;
    --we-control-bg-focus: #ffffff;
    --we-control-border-focus: #3b82f6;

    /* Border colors */
    --we-border-subtle: #e5e5e5;
    --we-border-strong: #d4d4d4;
    --we-border-section: #f3f3f3;

    /* Text colors */
    --we-text-primary: #333333;
    --we-text-secondary: #737373;
    --we-text-muted: #a3a3a3;

    /* Accent surfaces (used by CSS/Props panels) */
    --we-accent-info-bg: rgba(59, 130, 246, 0.08);
    --we-accent-brand-bg: rgba(99, 102, 241, 0.12);
    --we-accent-brand-border: rgba(99, 102, 241, 0.25);
    --we-accent-warning-bg: rgba(251, 191, 36, 0.14);
    --we-accent-warning-border: rgba(251, 191, 36, 0.25);
    --we-accent-danger-bg: rgba(248, 113, 113, 0.12);
    --we-accent-danger-border: rgba(248, 113, 113, 0.25);

    /* Shadows - Tailwind-like shadow-xl */
    --we-shadow-subtle: 0 1px 2px rgba(0, 0, 0, 0.05);
    --we-shadow-panel: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
    --we-shadow-tab: 0 1px 2px rgba(0, 0, 0, 0.05);

    /* Radii */
    --we-radius-panel: 8px;
    --we-radius-control: 6px;
    --we-radius-tab: 4px;

    /* Sizes */
    --we-icon-btn-size: 24px;

    /* Focus ring - blue inset border style */
    --we-focus-ring: #3b82f6;

    /* Motion - bounce easing for toolbar animations */
    --we-ease-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  /* Overlay container - for Canvas and visual feedback */
  #${Tn} {
    position: fixed;
    inset: 0;
    pointer-events: none;
    contain: layout style;
  }

  /* ==========================================================================
   * Resize Handles (Phase 4.9)
   * ========================================================================== */

  /* Handles layer - covers viewport, pass-through by default */
  .we-handles-layer {
    position: absolute;
    inset: 0;
    pointer-events: none;
    contain: layout style paint;
  }

  /* Selection frame - positioned by selection rect */
  .we-selection-frame {
    position: absolute;
    top: 0;
    left: 0;
    width: 0;
    height: 0;
    transform: translate3d(0, 0, 0);
    pointer-events: none;
    will-change: transform, width, height;
  }

  /* Individual resize handle */
  .we-resize-handle {
    position: absolute;
    width: 8px;
    height: 8px;
    border-radius: 2px;
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid ${Je.selectionBorder};
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
    pointer-events: auto;
    touch-action: none;
    user-select: none;
    transition: background-color 0.1s ease, border-color 0.1s ease, transform 0.1s ease;
  }

  .we-resize-handle:hover {
    background: ${Je.selectionBorder};
    border-color: ${Je.selectionBorder};
    transform: translate(-50%, -50%) scale(1.15);
  }

  .we-resize-handle:active {
    transform: translate(-50%, -50%) scale(1.0);
  }

  /* Handle positions - all use translate(-50%, -50%) as base */
  .we-resize-handle[data-dir="n"]  { left: 50%; top: 0; transform: translate(-50%, -50%); cursor: ns-resize; }
  .we-resize-handle[data-dir="s"]  { left: 50%; top: 100%; transform: translate(-50%, -50%); cursor: ns-resize; }
  .we-resize-handle[data-dir="e"]  { left: 100%; top: 50%; transform: translate(-50%, -50%); cursor: ew-resize; }
  .we-resize-handle[data-dir="w"]  { left: 0; top: 50%; transform: translate(-50%, -50%); cursor: ew-resize; }
  .we-resize-handle[data-dir="nw"] { left: 0; top: 0; transform: translate(-50%, -50%); cursor: nwse-resize; }
  .we-resize-handle[data-dir="ne"] { left: 100%; top: 0; transform: translate(-50%, -50%); cursor: nesw-resize; }
  .we-resize-handle[data-dir="sw"] { left: 0; top: 100%; transform: translate(-50%, -50%); cursor: nesw-resize; }
  .we-resize-handle[data-dir="se"] { left: 100%; top: 100%; transform: translate(-50%, -50%); cursor: nwse-resize; }

  /* Size HUD - shows W×H while resizing */
  .we-size-hud {
    position: absolute;
    left: 50%;
    top: 0;
    transform: translate(-50%, calc(-100% - 8px));
    padding: 3px 8px;
    font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 11px;
    font-weight: 600;
    line-height: 1.2;
    color: rgba(255, 255, 255, 0.98);
    background: rgba(15, 23, 42, 0.92);
    border: 1px solid rgba(51, 65, 85, 0.5);
    border-radius: 4px;
    pointer-events: none;
    user-select: none;
    white-space: nowrap;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    backdrop-filter: blur(4px);
    -webkit-backdrop-filter: blur(4px);
  }

  /* ==========================================================================
   * Performance HUD (Phase 5.3)
   * ========================================================================== */

  .we-perf-hud {
    position: fixed;
    left: 12px;
    bottom: 12px;
    padding: 8px 10px;
    border-radius: 10px;
    background: rgba(15, 23, 42, 0.78);
    border: 1px solid rgba(51, 65, 85, 0.45);
    color: rgba(255, 255, 255, 0.96);
    font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 12px;
    line-height: 1.25;
    pointer-events: none;
    user-select: none;
    white-space: nowrap;
    z-index: 10;
    box-shadow: 0 4px 14px rgba(0, 0, 0, 0.18);
    backdrop-filter: blur(6px);
    -webkit-backdrop-filter: blur(6px);
    font-variant-numeric: tabular-nums;
  }

  .we-perf-hud-line + .we-perf-hud-line {
    margin-top: 4px;
  }

  /* UI container - for panels and controls */
  /* Position below toolbar: 16px (toolbar top) + 40px (toolbar height) + 8px (gap) = 64px */
  #${Yn} {
    position: fixed;
    top: 64px;
    right: 16px;
    pointer-events: auto;
    /* Inter font with system fallbacks (aligned with design spec) */
    font-family: "Inter", system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 11px;
    line-height: 1.4;
    color: var(--we-text-primary);
    -webkit-font-smoothing: antialiased;
  }

  /* Panel styles */
  /* max-height: 100vh - 64px (top offset) - 16px (bottom margin) = 100vh - 80px */
  .we-panel {
    width: 280px;
    max-width: calc(100vw - 32px);
    max-height: calc(100vh - 80px);
    background: var(--we-surface-bg);
    border: 1px solid var(--we-border-subtle);
    border-radius: var(--we-radius-panel);
    box-shadow: var(--we-shadow-panel);
    overflow: hidden;
    contain: layout style paint;
  }

  .we-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    padding: 8px 12px;
    background: var(--we-surface-bg);
    border-bottom: 1px solid var(--we-border-subtle);
    user-select: none;
  }

  .we-title {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    font-weight: 600;
    color: var(--we-text-primary);
  }

  .we-badge {
    font-size: 10px;
    font-weight: 500;
    padding: 2px 6px;
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    color: white;
    border-radius: 4px;
  }

  .we-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 6px 12px;
    font-size: 12px;
    font-weight: 500;
    color: #475569;
    background: white;
    border: 1px solid rgba(148, 163, 184, 0.5);
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.15s ease;
  }

  .we-btn:hover {
    background: #f8fafc;
    border-color: rgba(148, 163, 184, 0.7);
  }

  .we-btn:active {
    background: #f1f5f9;
  }

  .we-btn:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px var(--we-focus-ring);
  }

  .we-btn:disabled {
    opacity: 0.55;
    cursor: not-allowed;
  }

  .we-btn--primary {
    background: linear-gradient(135deg, #0f172a, #1e293b);
    color: #ffffff;
    border-color: rgba(15, 23, 42, 0.5);
  }

  .we-btn--primary:hover:not(:disabled) {
    background: linear-gradient(135deg, #1e293b, #334155);
    border-color: rgba(15, 23, 42, 0.65);
  }

  .we-btn--danger {
    color: #b91c1c;
    border-color: rgba(248, 113, 113, 0.45);
  }

  .we-btn--danger:hover:not(:disabled) {
    background: rgba(248, 113, 113, 0.08);
    border-color: rgba(248, 113, 113, 0.6);
  }

  /* Icon button (28x28) - used for window controls (close/minimize, etc.) */
  .we-icon-btn {
    width: var(--we-icon-btn-size);
    height: var(--we-icon-btn-size);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    background: var(--we-control-bg);
    border: 0;
    border-radius: var(--we-radius-control);
    color: var(--we-text-secondary);
    cursor: pointer;
    transition: background 0.15s ease, box-shadow 0.15s ease;
  }

  .we-icon-btn:hover {
    background: var(--we-control-bg-hover);
    color: var(--we-text-primary);
  }

  .we-icon-btn:active {
    background: var(--we-control-bg-hover);
  }

  .we-icon-btn:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px var(--we-focus-ring);
  }

  .we-icon-btn svg {
    width: 16px;
    height: 16px;
    display: block;
  }

  /* Drag handle (grip) - used for repositioning floating UI */
  .we-drag-handle {
    width: var(--we-icon-btn-size);
    height: var(--we-icon-btn-size);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    padding: 0;
    background: transparent;
    border: 0;
    border-radius: var(--we-radius-control);
    color: var(--we-text-muted);
    cursor: grab;
    touch-action: none;
    user-select: none;
    transition: background 0.15s ease, color 0.15s ease, box-shadow 0.15s ease;
  }

  .we-drag-handle:hover {
    background: var(--we-control-bg);
    color: var(--we-text-secondary);
  }

  .we-drag-handle:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px var(--we-focus-ring);
  }

  .we-drag-handle:active,
  .we-drag-handle[data-dragging="true"] {
    cursor: grabbing;
    background: var(--we-control-bg-hover);
    color: var(--we-text-primary);
  }

  .we-drag-handle svg {
    width: 14px;
    height: 14px;
    display: block;
  }

  /* ==========================================================================
   * Toolbar (Redesigned per toolbar-ui.html design spec)
   * - Bounce easing animations
   * - Collapsible pill (580x40 <-> 40x40)
   * - Grip icon rotation on collapse
   * ========================================================================== */

  .we-toolbar {
    position: fixed;
    left: 50%;
    top: 16px;
    transform: translateX(-50%);
    width: 580px;
    height: 40px;
    max-width: calc(100vw - 32px);
    display: flex;
    align-items: center;
    background: #ffffff;
    border-radius: 999px;
    box-shadow: 0 -4px 10px -6px rgba(15, 23, 42, 0.18),
      0 10px 15px -3px rgba(203, 213, 225, 0.5),
      0 4px 6px -4px rgba(203, 213, 225, 0.5);
    pointer-events: auto;
    user-select: none;
    font-family: 'Inter', system-ui, -apple-system, sans-serif;
    font-size: 11px;
    color: #475569;
    transition: width 500ms var(--we-ease-bounce), height 500ms var(--we-ease-bounce);
    overflow: visible;
    will-change: width, height;
  }

  .we-toolbar[data-position="bottom"] {
    top: auto;
    bottom: 16px;
  }

  /* Dragged toolbar: use left/top (inline styles) instead of docked centering */
  .we-toolbar[data-dragged="true"] {
    left: auto;
    right: auto;
    top: auto;
    bottom: auto;
    transform: none;
  }

  /* Collapsed toolbar - 40x40 circle */
  .we-toolbar[data-minimized="true"] {
    width: 40px;
    height: 40px;
  }

  /* Toolbar content row (collapses with toolbar) */
  .we-toolbar-content {
    display: flex;
    align-items: center;
    flex: 1;
    min-width: 0;
    gap: 10px;
    white-space: nowrap;
    padding-right: 8px;
    transition: opacity 350ms ease, transform 400ms var(--we-ease-bounce);
    will-change: opacity, transform;
  }

  .we-toolbar[data-minimized="true"] .we-toolbar-content {
    opacity: 0;
    transform: translateX(-16px) scale(0.95);
    pointer-events: none;
  }

  .we-toolbar[data-minimized="false"] .we-toolbar-content {
    opacity: 1;
    transform: translateX(0) scale(1);
    pointer-events: auto;
  }

  /* Grip toggle button (40x40, hover slate-50, active scale-90) */
  .we-toolbar .we-drag-handle {
    width: 40px;
    height: 40px;
    flex-shrink: 0;
    border-radius: 999px;
    cursor: pointer;
    transition: background-color 150ms ease, transform 150ms ease;
  }

  .we-toolbar .we-drag-handle:hover {
    background: #f8fafc;
  }

  .we-toolbar .we-drag-handle:active {
    transform: scale(0.9);
  }

  /* Grip icon rotation (collapsed 90deg -> expanded 0deg) */
  .we-toolbar .we-drag-handle svg {
    width: 16px;
    height: 16px;
    color: #94a3b8;
    transition: transform 500ms var(--we-ease-bounce);
    transform: rotate(0deg);
  }

  .we-toolbar[data-minimized="true"] .we-drag-handle svg {
    transform: rotate(90deg);
  }

  /* Status indicator: green dot + "Editor" label */
  .we-toolbar-indicator {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 10px;
    background: #f1f5f9;
    border-radius: 999px;
  }

  .we-toolbar-indicator-dot {
    width: 6px;
    height: 6px;
    border-radius: 999px;
    background: #10b981;
  }

  .we-toolbar-indicator-label {
    font-size: 11px;
    font-weight: 700;
    color: #334155;
    letter-spacing: 0.04em;
  }

  /* Status-driven dot color + pulse */
  .we-toolbar[data-status="progress"] .we-toolbar-indicator-dot {
    background: #6366f1;
    animation: we-toolbar-dot-pulse 1.5s ease-in-out infinite;
  }

  .we-toolbar[data-status="success"] .we-toolbar-indicator-dot {
    background: #10b981;
  }

  .we-toolbar[data-status="error"] .we-toolbar-indicator-dot {
    background: #ef4444;
  }

  @keyframes we-toolbar-dot-pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.55; }
  }

  /* Undo/Redo counts */
  .we-toolbar-history {
    display: flex;
    gap: 10px;
    font-size: 10px;
    font-weight: 500;
    color: #94a3b8;
    font-variant-numeric: tabular-nums;
  }

  .we-toolbar-history-value {
    color: #475569;
    font-weight: 700;
  }

  /* Divider */
  .we-toolbar-divider {
    width: 1px;
    height: 16px;
    background: #e2e8f0;
  }

  /* Structure group (Structure button + divider + Undo/Redo icons) */
  .we-toolbar-structure-group {
    display: inline-flex;
    align-items: center;
    background: #f1f5f9;
    border-radius: 999px;
    padding: 2px;
  }

  .we-toolbar-structure-btn {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 4px 10px;
    font-size: 11px;
    font-weight: 500;
    color: #64748b;
    background: transparent;
    border: 0;
    border-radius: 999px;
    cursor: pointer;
    transition: color 150ms ease, background-color 150ms ease;
  }

  .we-toolbar-structure-btn:hover:not(:disabled) {
    color: #1e293b;
    background: #ffffff;
  }

  .we-toolbar-structure-btn:disabled {
    opacity: 0.55;
    cursor: not-allowed;
  }

  .we-toolbar-structure-btn svg {
    width: 10px;
    height: 10px;
    opacity: 0.5;
    display: block;
  }

  .we-toolbar-structure-separator {
    width: 1px;
    height: 12px;
    background: #e2e8f0;
  }

  .we-toolbar-group-icon-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 4px;
    background: transparent;
    border: 0;
    border-radius: 999px;
    color: #94a3b8;
    cursor: pointer;
    transition: color 150ms ease, background-color 150ms ease;
  }

  .we-toolbar-group-icon-btn:hover:not(:disabled) {
    color: #334155;
    background: #ffffff;
  }

  .we-toolbar-group-icon-btn:disabled {
    opacity: 0.45;
    cursor: not-allowed;
  }

  .we-toolbar-group-icon-btn svg {
    width: 14px;
    height: 14px;
    display: block;
  }

  /* End actions container: pushes apply + close to far right */
  .we-toolbar-end-actions {
    margin-left: auto;
    display: inline-flex;
    align-items: center;
    gap: 10px;
  }

  /* Apply button (indigo-500) */
  .we-toolbar-apply-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 6px 16px;
    font-size: 11px;
    font-weight: 700;
    color: #ffffff;
    background: #6366f1;
    border: 0;
    border-radius: 999px;
    cursor: pointer;
    transition: background-color 150ms ease, transform 150ms ease, box-shadow 150ms ease;
    box-shadow: 0 4px 6px -1px rgba(99, 102, 241, 0.25),
      0 2px 4px -2px rgba(99, 102, 241, 0.25);
  }

  .we-toolbar-apply-btn:hover:not(:disabled) {
    background: #4f46e5;
  }

  .we-toolbar-apply-btn:active:not(:disabled) {
    transform: scale(0.95);
  }

  .we-toolbar-apply-btn:disabled {
    opacity: 0.55;
    cursor: not-allowed;
    box-shadow: none;
  }

  /* Close button (red hover) */
  .we-toolbar-close-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 6px;
    background: transparent;
    border: 0;
    border-radius: 999px;
    color: #94a3b8;
    cursor: pointer;
    transition: color 150ms ease, background-color 150ms ease;
  }

  .we-toolbar-close-btn:hover:not(:disabled) {
    color: #ef4444;
    background: #fef2f2;
  }

  .we-toolbar-close-btn:disabled {
    opacity: 0.45;
    cursor: not-allowed;
  }

  .we-toolbar-close-btn svg {
    width: 14px;
    height: 14px;
    display: block;
  }

  /* Screen-reader-only utility */
  .we-sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border: 0;
  }

  /* Respect reduced motion preference */
  @media (prefers-reduced-motion: reduce) {
    .we-toolbar,
    .we-toolbar-content,
    .we-toolbar .we-drag-handle,
    .we-toolbar .we-drag-handle svg,
    .we-toolbar-structure-btn,
    .we-toolbar-group-icon-btn,
    .we-toolbar-apply-btn,
    .we-toolbar-close-btn {
      transition: none;
    }
  }

  /* ==========================================================================
     Breadcrumbs (Phase 2.2) - Anchored to selection element
     ========================================================================== */
  .we-breadcrumbs {
    position: fixed;
    /* left/top set dynamically via JS based on selection rect */
    left: 16px;
    top: 72px;
    width: auto;
    max-width: min(600px, calc(100vw - 400px));
    display: flex;
    align-items: center;
    gap: 2px;
    padding: 6px 12px;
    background: #5494D7;
    border: none;
    border-radius: 0;
    box-shadow: 0 2px 8px rgba(84, 148, 215, 0.3);
    pointer-events: auto;
    user-select: none;
    overflow-x: auto;
    white-space: nowrap;
    scrollbar-width: none;
    z-index: 5;
  }

  .we-breadcrumbs[data-hidden="true"] {
    display: none;
  }

  .we-breadcrumbs[data-position="bottom"] {
    top: auto;
    bottom: 72px;
  }

  .we-breadcrumbs::-webkit-scrollbar {
    display: none;
  }

  .we-crumb {
    display: inline-flex;
    align-items: center;
    max-width: 220px;
    padding: 2px 6px;
    border-radius: 3px;
    border: none;
    background: transparent;
    color: #ffffff;
    font-size: 12px;
    font-weight: 500;
    line-height: 1.2;
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    transition: background 0.15s ease;
  }

  .we-crumb:hover {
    background: rgba(255, 255, 255, 0.15);
  }

  .we-crumb:active {
    background: rgba(255, 255, 255, 0.25);
  }

  .we-crumb:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.5);
  }

  .we-crumb--current {
    background: rgba(255, 255, 255, 0.2);
  }

  .we-crumb-sep {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 14px;
    flex: 0 0 auto;
    color: rgba(255, 255, 255, 0.7);
    font-size: 12px;
  }

  .we-crumb-sep--shadow {
    color: rgba(255, 255, 255, 0.9);
  }

  .we-body {
    padding: 14px;
    color: #475569;
    font-size: 12px;
  }

  .we-status {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    background: rgba(34, 197, 94, 0.1);
    border-radius: 6px;
    color: #15803d;
    font-size: 12px;
  }

  .we-status-dot {
    width: 8px;
    height: 8px;
    background: #22c55e;
    border-radius: 50%;
    animation: pulse 2s ease-in-out infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }

  /* ==========================================================================
     Property Panel (Phase 3)
     ========================================================================== */

  .we-prop-panel {
    display: flex;
    flex-direction: column;
    max-height: calc(100vh - 80px);
  }

  /* Dragged property panel: becomes a floating fixed panel positioned via left/top (inline styles) */
  .we-prop-panel[data-dragged="true"][data-minimized="false"] {
    position: fixed;
    left: auto;
    right: auto;
    top: auto;
    bottom: auto;
  }

  /* Minimized property panel - becomes a small icon button fixed at top-right */
  .we-prop-panel[data-minimized="true"] {
    position: fixed;
    top: 16px;
    right: 16px;
    width: auto;
    max-height: none;
    background: transparent;
    border: 0;
    box-shadow: none;
    overflow: visible;
    z-index: 10;
  }

  .we-prop-panel[data-minimized="true"] .we-header {
    padding: 0;
    background: transparent;
    border-bottom: 0;
  }

  /* Symmetric header layout: drag (left) | tabs (center) | minimize (right) */
  .we-prop-panel .we-header {
    padding: 8px;
    gap: 4px;
  }

  .we-prop-panel .we-header .we-prop-tabs {
    flex: 1;
    justify-content: center;
  }

  /* Minimize button chevron rotation */
  .we-minimize-btn svg {
    transition: transform 200ms ease;
  }

  .we-prop-panel[data-minimized="true"] .we-minimize-btn svg {
    transform: rotate(180deg);
  }

  /* Header tooltips: show below to avoid being clipped by panel overflow */
  .we-prop-panel .we-header [data-tooltip]::after {
    bottom: auto;
    top: calc(100% + 6px);
  }

  .we-prop-panel .we-header [data-tooltip]::before {
    bottom: auto;
    top: calc(100% + 2px);
    border-top-color: transparent;
    border-bottom-color: var(--we-text-primary);
  }

  /* Tab container with pill/segmented style (aligned with design spec) */
  .we-prop-tabs {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    padding: 2px;
    background: var(--we-control-bg);
    border-radius: var(--we-radius-tab);
  }

  .we-tab {
    border: 0;
    background: transparent;
    color: var(--we-text-secondary);
    padding: 4px 10px;
    border-radius: var(--we-radius-tab);
    cursor: pointer;
    font-size: 12px;
    font-weight: 500;
    transition: all 0.1s ease;
  }

  .we-tab:hover {
    color: var(--we-text-primary);
  }

  .we-tab:focus-visible {
    outline: none;
    box-shadow: inset 0 0 0 2px var(--we-focus-ring);
  }

  /* Active tab: white background with subtle shadow */
  .we-tab[aria-selected="true"] {
    background: var(--we-surface-bg);
    color: var(--we-text-primary);
    box-shadow: var(--we-shadow-tab);
  }

  .we-prop-body {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    padding: 12px;
    padding-bottom: 80px; /* Extra space for scrolling (design spec: pb-20) */
    display: flex;
    flex-direction: column;
    gap: 12px;
    scrollbar-width: none; /* Firefox */
    -ms-overflow-style: none; /* IE 10+ */
  }

  /* Hide scrollbar for webkit browsers */
  .we-prop-body::-webkit-scrollbar {
    width: 0;
    height: 0;
  }

  /* Force hidden state for property panel sections during minimization */
  .we-prop-body[hidden],
  .we-prop-tabs[hidden] {
    display: none;
  }

  .we-prop-tab-content {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .we-prop-tab-content[hidden] {
    display: none;
  }

  .we-prop-empty {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px 12px;
    color: #64748b;
    font-size: 12px;
    text-align: center;
  }

  .we-prop-empty[hidden] {
    display: none;
  }

  .we-prop-panel[data-empty="true"] .we-prop-tab-content {
    display: none;
  }

  /* ==========================================================================
     Components Tree (Phase 3.2)
     ========================================================================== */

  .we-tree {
    font-size: 12px;
    line-height: 1.4;
  }

  .we-tree-empty {
    padding: 24px 12px;
    color: #64748b;
    text-align: center;
  }

  .we-tree-empty[hidden] {
    display: none;
  }

  .we-tree-list {
    display: flex;
    flex-direction: column;
  }

  .we-tree-list[hidden] {
    display: none;
  }

  .we-tree-item {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 6px 8px;
    cursor: pointer;
    border-radius: 4px;
    transition: background 0.12s;
    color: #475569;
  }

  .we-tree-item:hover {
    background: rgba(59, 130, 246, 0.08);
  }

  .we-tree-item--selected {
    background: rgba(59, 130, 246, 0.12);
    color: #1d4ed8;
    font-weight: 500;
  }

  .we-tree-item--selected:hover {
    background: rgba(59, 130, 246, 0.16);
  }

  .we-tree-item--ancestor {
    color: #64748b;
  }

  .we-tree-item--child {
    color: #64748b;
    font-size: 11px;
  }

  .we-tree-indent {
    color: #94a3b8;
    font-family: monospace;
    user-select: none;
  }

  .we-tree-icon {
    flex-shrink: 0;
    color: #94a3b8;
    font-size: 10px;
  }

  .we-tree-item--selected .we-tree-icon {
    color: #3b82f6;
  }

  .we-tree-label {
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  }

  /* ==========================================================================
     Control Groups (Section style - aligned with design spec)
     Uses separator lines instead of card borders
     ========================================================================== */

  .we-group {
    /* No card-style border, use separator lines between sections */
    border: 0;
    border-radius: 0;
    overflow: visible;
    background: transparent;
  }

  /* Section separator - top border for non-first groups */
  .we-group + .we-group {
    border-top: 1px solid var(--we-border-section);
    padding-top: 12px;
    margin-top: 4px;
  }

  .we-group-header {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
    padding: 0 0 8px 0;
    background: transparent;
  }

  .we-group-toggle {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 6px;
    padding: 0;
    background: transparent;
    border: 0;
    cursor: pointer;
    color: #333333;
    font-size: 11px;
    font-weight: 600;
    text-align: left;
    transition: color 0.1s ease;
  }

  .we-group-toggle:hover {
    color: var(--we-text-primary);
  }

  .we-group-toggle:focus-visible {
    outline: none;
    box-shadow: inset 0 0 0 2px var(--we-focus-ring);
    border-radius: 2px;
  }

  .we-group-toggle--static {
    cursor: default;
    pointer-events: none;
  }

  .we-group-header-actions {
    display: flex;
    align-items: center;
    gap: 2px;
    flex: 0 0 auto;
  }

  .we-group-body {
    padding: 0;
    background: transparent;
    border-top: 0;
  }

  .we-group[data-collapsed="true"] .we-group-body {
    display: none;
  }

  .we-chevron {
    width: 12px;
    height: 12px;
    flex: 0 0 auto;
    color: var(--we-text-muted);
    transition: transform 0.1s ease;
  }

  .we-group[data-collapsed="true"] .we-chevron {
    transform: rotate(-90deg);
  }

  /* ==========================================================================
     Form Controls (for Design controls)
     ========================================================================== */

  /* Field row: vertical stack (label on top, control below) */
  .we-field {
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: 4px;
  }

  /* Horizontal field variant (label left, control right) */
  .we-field--horizontal {
    flex-direction: row;
    align-items: center;
    gap: 8px;
  }

  .we-field-label {
    flex: 0 0 auto;
    width: auto;
    font-size: 10px;
    font-weight: 500;
    color: var(--we-text-secondary);
  }

  /* Fixed width label for horizontal layout */
  .we-field--horizontal .we-field-label {
    width: 48px;
  }

  .we-field-label--short {
    width: 20px;
  }

  /* Hint text (small label above icon groups for H/V distinction) */
  .we-field-hint {
    font-size: 9px;
    color: var(--we-text-muted);
    text-align: center;
    line-height: 1;
  }

  /* Content container for complex controls (icon groups, grids, etc.) */
  .we-field-content {
    width: 100%;
    min-width: 0;
  }

  /* Input styling aligned with design spec:
   * - Gray background by default
   * - Inset border on hover
   * - White background + blue inset border on focus
   */
  .we-input {
    flex: 1 1 auto;
    flex-shrink: 0; /* Prevent height shrinking in column flex containers */
    min-width: 0;
    height: 28px; /* Design spec: h-[28px] */
    padding: 0 8px;
    font-size: 11px;
    line-height: 26px; /* Ensure vertical centering: 28px - 2px border */
    font-family: inherit;
    color: var(--we-text-primary);
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    outline: none;
    transition: background 0.1s ease, border-color 0.1s ease, box-shadow 0.1s ease;
  }

  .we-input::placeholder {
    color: var(--we-text-muted);
  }

  .we-input:hover:not(:focus) {
    border-color: var(--we-control-border-hover);
  }

  .we-input:focus {
    background: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  /* ==========================================================================
   * Input Container (Phase 2.1)
   *
   * A wrapper for inputs with prefix/suffix support.
   * Container handles hover/focus-within styling instead of input itself.
   * ========================================================================== */
  .we-input-container {
    min-width: 0;
    display: flex;
    align-items: center;
    height: 28px; /* Design spec: h-[28px] - must be explicit, not flex-controlled */
    flex-shrink: 0; /* Prevent height shrinking in column flex containers */
    padding: 0 8px;
    gap: 4px;
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    transition: background 0.1s ease, border-color 0.1s ease, box-shadow 0.1s ease;
  }

  /* In row flex containers, allow input-container to grow horizontally */
  .we-field-row > .we-input-container,
  .we-radius-control .we-field-row > .we-input-container {
    flex: 1 1 0;
  }

  .we-input-container:hover:not(:focus-within) {
    border-color: var(--we-control-border-hover);
  }

  .we-input-container:focus-within {
    background: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  .we-input-container__input {
    flex: 1;
    min-width: 0;
    height: 100%;
    padding: 0;
    font-size: 11px;
    line-height: 26px; /* Ensure vertical centering within 28px container */
    font-family: inherit;
    color: var(--we-text-primary);
    background: transparent;
    border: none;
    outline: none;
  }

  .we-input-container__input::placeholder {
    color: var(--we-text-muted);
  }

  /* Number inputs: right-aligned text in containers */
  .we-input-container__input[inputmode="decimal"],
  .we-input-container__input[inputmode="numeric"] {
    text-align: right;
  }

  /* Prefix and suffix elements */
  .we-input-container__prefix,
  .we-input-container__suffix {
    flex: 0 0 auto;
    font-size: 10px;
    color: var(--we-text-muted);
    user-select: none;
    pointer-events: none;
  }

  .we-input-container__prefix {
    margin-right: 2px;
  }

  .we-input-container__suffix {
    margin-left: 2px;
  }

  /* Icon in prefix/suffix */
  .we-input-container__prefix svg,
  .we-input-container__suffix svg {
    width: 12px;
    height: 12px;
    display: block;
  }

  /* ==========================================================================
   * Slider Input (Opacity and other numeric ranges)
   * ========================================================================== */
  .we-slider-input {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    min-width: 0;
  }

  .we-slider-input__slider {
    flex: 1 1 auto;
    min-width: 0;
    height: 28px;
    margin: 0;
    padding: 0;
    background: transparent;
    -webkit-appearance: none;
    appearance: none;
    cursor: pointer;
  }

  .we-slider-input__slider:disabled {
    opacity: 0.55;
    cursor: not-allowed;
  }

  .we-slider-input__slider::-webkit-slider-runnable-track {
    height: 4px;
    background: linear-gradient(
      to right,
      var(--we-control-border-focus) 0%,
      var(--we-control-border-focus) var(--progress, 0%),
      var(--we-control-bg) var(--progress, 0%),
      var(--we-control-bg) 100%
    );
    border: 1px solid var(--we-control-border-hover);
    border-radius: 999px;
  }

  .we-slider-input__slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 12px;
    height: 12px;
    margin-top: -5px; /* (12px thumb - 4px track) / 2 + border */
    border-radius: 999px;
    background: var(--we-control-bg-focus);
    border: 1px solid var(--we-border-strong);
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.15);
  }

  .we-slider-input__slider:focus-visible {
    outline: none;
  }

  .we-slider-input__slider:focus-visible::-webkit-slider-thumb {
    border-color: var(--we-control-border-focus);
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.25);
  }

  .we-slider-input__slider::-moz-range-track {
    height: 4px;
    background: linear-gradient(
      to right,
      var(--we-control-border-focus) 0%,
      var(--we-control-border-focus) var(--progress, 0%),
      var(--we-control-bg) var(--progress, 0%),
      var(--we-control-bg) 100%
    );
    border: 1px solid var(--we-control-border-hover);
    border-radius: 999px;
  }

  .we-slider-input__slider::-moz-range-thumb {
    width: 12px;
    height: 12px;
    border-radius: 999px;
    background: var(--we-control-bg-focus);
    border: 1px solid var(--we-border-strong);
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.15);
  }

  .we-slider-input__slider:focus-visible::-moz-range-thumb {
    border-color: var(--we-control-border-focus);
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.25);
  }

  .we-slider-input__number {
    flex: 0 0 auto;
  }

  /* ==========================================================================
   * Icon Button Group (Phase 4.1)
   *
   * A single-select grid of icon buttons (e.g. flex-direction control).
   * ========================================================================== */
  .we-icon-button-group {
    display: grid;
    gap: 4px;
  }

  .we-icon-button-group__btn {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 28px; /* Design spec: h-[28px] */
    padding: 4px;
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    cursor: pointer;
    transition: background-color 0.1s ease, border-color 0.1s ease;
  }

  .we-icon-button-group__btn:hover:not(:disabled) {
    background: var(--we-control-bg-hover);
  }

  .we-icon-button-group__btn:focus-visible {
    outline: none;
    border-color: var(--we-control-border-focus);
    box-shadow: inset 0 0 0 2px var(--we-control-border-focus); /* Design spec: 2px inset */
  }

  .we-icon-button-group__btn[data-selected="true"] {
    background: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  .we-icon-button-group__btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .we-icon-button-group__btn svg {
    width: 14px;
    height: 14px;
    color: var(--we-text-secondary);
  }

  .we-icon-button-group__btn[data-selected="true"] svg {
    color: var(--we-control-border-focus);
  }

  /* ==========================================================================
   * Toggle Button
   *
   * A pressable toggle button (e.g. flip X/Y controls).
   * ========================================================================== */
  .we-toggle-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    padding: 4px;
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    cursor: pointer;
    transition: background-color 0.1s ease, border-color 0.1s ease;
  }

  .we-toggle-btn:hover:not(:disabled) {
    background: var(--we-control-bg-hover);
  }

  .we-toggle-btn[aria-pressed="true"] {
    background: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  .we-toggle-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .we-toggle-btn svg {
    width: 14px;
    height: 14px;
    color: var(--we-text-secondary);
  }

  .we-toggle-btn[aria-pressed="true"] svg {
    color: var(--we-control-border-focus);
  }

  /* ==========================================================================
   * Alignment Grid (Phase 4.2)
   *
   * 3×3 single-select grid for justify-content + align-items.
   * ========================================================================== */
  .we-alignment-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
    padding: 8px;
    min-height: 90px;
    background: #f9f9f9;
    border: 1px solid #f0f0f0;
    border-radius: var(--we-radius-control);
    place-items: center;
  }

  .we-alignment-grid__cell {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 20px;
    padding: 0;
    background: transparent;
    border: none;
    border-radius: 2px;
    cursor: pointer;
    transition: background-color 0.1s ease;
  }

  .we-alignment-grid__cell:hover:not(:disabled) {
    background: rgba(0, 0, 0, 0.05);
  }

  .we-alignment-grid__cell:focus-visible {
    outline: 2px solid var(--we-control-border-focus);
    outline-offset: 1px;
  }

  .we-alignment-grid__cell:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  /* Inactive dot */
  .we-alignment-grid__dot {
    width: 2px;
    height: 2px;
    background: var(--we-text-muted);
    border-radius: 50%;
  }

  /* Active marker (3 bars showing alignment) */
  .we-alignment-grid__marker {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    width: 12px;
    height: 12px;
  }

  .we-alignment-grid__bar {
    height: 2px;
    background: var(--we-control-border-focus);
    border-radius: 1px;
  }

  .we-alignment-grid__bar--1 { width: 8px; }
  .we-alignment-grid__bar--2 { width: 12px; }
  .we-alignment-grid__bar--3 { width: 4px; }

  /* ==========================================================================
   * Grid + Gap Two Column Layout (Layout Control)
   * ========================================================================== */

  .we-grid-gap-row {
    display: flex;
    gap: 8px;
  }

  .we-grid-gap-col {
    flex: 1;
    min-width: 0;
  }

  /* Keep Grid label space for alignment; hide text only when both columns are visible (grid mode) */
  .we-grid-gap-col--grid:not([hidden]):has(+ .we-grid-gap-col--gap:not([hidden])) .we-field-label {
    visibility: hidden;
  }

  .we-grid-gap-col .we-field-content {
    width: 100%;
    overflow: visible;
  }

  /* Gap inputs vertical layout */
  .we-grid-gap-inputs {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  /* ==========================================================================
   * Grid Dimensions Picker (Layout Control)
   * ========================================================================== */

  .we-grid-dimensions-preview {
    width: 100%;
    height: 64px; /* Match two rows of gap inputs: 28px + 8px gap + 28px */
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    font-size: 12px;
    font-family: inherit;
    color: var(--we-text-primary);
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    cursor: pointer;
    transition: background-color 0.1s ease, border-color 0.1s ease;
  }

  .we-grid-dimensions-preview:hover:not(:disabled) {
    background: var(--we-control-bg-hover);
  }

  .we-grid-dimensions-preview:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .we-grid-dimensions-popover {
    position: absolute;
    top: calc(100% + 4px);
    left: 0;
    min-width: 220px;
    padding: 10px;
    background: var(--we-surface-bg);
    border: 1px solid var(--we-border-subtle);
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.12);
    z-index: 60;
  }

  .we-grid-dimensions-popover[hidden] {
    display: none;
  }

  .we-grid-dimensions-inputs {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-bottom: 10px;
  }

  .we-grid-dimensions-times {
    font-size: 12px;
    color: var(--we-text-muted);
    user-select: none;
  }

  .we-grid-dimensions-matrix {
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    gap: 3px;
    padding: 6px;
    background: var(--we-surface-secondary);
    border: 1px solid var(--we-border-subtle);
    border-radius: var(--we-radius-control);
  }

  .we-grid-dimensions-cell {
    width: 100%;
    aspect-ratio: 1 / 1;
    background: transparent;
    border: 1px solid rgba(0, 0, 0, 0.10);
    border-radius: 2px;
    padding: 0;
    cursor: pointer;
    transition: background-color 0.08s ease, border-color 0.08s ease;
  }

  .we-grid-dimensions-cell[data-active="true"] {
    border-color: rgba(59, 130, 246, 0.65);
    background: rgba(59, 130, 246, 0.10);
  }

  .we-grid-dimensions-cell[data-selected="true"] {
    border-color: rgba(59, 130, 246, 0.9);
    background: rgba(59, 130, 246, 0.16);
  }

  .we-grid-dimensions-tooltip {
    margin-top: 8px;
    text-align: center;
    font-size: 11px;
    color: var(--we-text-secondary);
  }

  .we-grid-dimensions-tooltip[hidden] {
    display: none;
  }

  .we-input--short {
    width: 56px;
    flex: 0 0 auto;
  }

  /* Number inputs: right-aligned text */
  .we-input[type="text"][inputmode="decimal"],
  .we-input[type="number"] {
    text-align: right;
  }

  .we-select {
    flex: 1 1 auto;
    flex-shrink: 0; /* Prevent height shrinking in column flex containers */
    min-width: 0;
    height: 28px; /* Design spec: h-[28px] */
    padding: 0 24px 0 8px;
    font-size: 11px;
    line-height: 26px; /* Ensure vertical centering: 28px - 2px border */
    font-family: inherit;
    color: var(--we-text-primary);
    background: var(--we-control-bg) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 10 10'%3E%3Cpath fill='%23737373' d='M2.5 3.5l2.5 3 2.5-3'/%3E%3C/svg%3E") no-repeat right 8px center;
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    outline: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    cursor: pointer;
    transition: background-color 0.1s ease, border-color 0.1s ease, box-shadow 0.1s ease;
  }

  .we-select:hover:not(:focus) {
    border-color: var(--we-control-border-hover);
  }

  .we-select:focus {
    background-color: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  /* Field row for multiple inputs side by side */
  .we-field-row {
    display: flex;
    align-items: stretch;
    gap: 8px;
  }

  /* Size field with mode select + input stacked vertically */
  .we-size-field {
    display: flex;
    flex-direction: column;
    gap: 4px;
    flex: 1;
    min-width: 0;
  }

  .we-size-mode-select {
    width: 100%;
  }

  .we-field-group {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  /* ==========================================================================
     Effects (Box Shadow List)
     ========================================================================== */

  .we-effects-toolbar {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 6px;
  }

  .we-effects-list {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .we-effects-item-wrap {
    position: relative;
  }

  .we-effects-item {
    height: 28px;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 0 6px;
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    transition: background-color 0.1s ease, border-color 0.1s ease, opacity 0.1s ease;
  }

  .we-effects-item:hover {
    background: var(--we-control-bg-hover);
  }

  .we-effects-item[data-open="true"] {
    background: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  .we-effects-item[data-enabled="false"] {
    opacity: 0.55;
  }

  .we-effects-name {
    flex: 1;
    min-width: 0;
    padding: 0;
    border: 0;
    background: transparent;
    text-align: left;
    font-size: 11px;
    color: var(--we-text-primary);
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .we-effects-name:focus-visible {
    outline: none;
    box-shadow: inset 0 0 0 2px var(--we-focus-ring);
    border-radius: 4px;
  }

  .we-effects-icon-btn {
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: 0;
    border-radius: var(--we-radius-control);
    color: var(--we-text-secondary);
    cursor: pointer;
    padding: 0;
    transition: background-color 0.1s ease, color 0.1s ease;
  }

  .we-effects-icon-btn:hover:not(:disabled) {
    background: rgba(0, 0, 0, 0.06);
    color: var(--we-text-primary);
  }

  .we-effects-icon-btn:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px var(--we-focus-ring);
  }

  .we-effects-icon-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .we-effects-icon-btn svg {
    width: 14px;
    height: 14px;
  }

  .we-effects-popover {
    position: absolute;
    top: calc(100% + 6px);
    left: 0;
    width: 220px;
    max-width: 220px;
    padding: 10px;
    background: var(--we-surface-bg);
    border: 1px solid var(--we-border-subtle);
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.12);
    z-index: 60;
  }

  .we-effects-popover[hidden] {
    display: none;
  }

  .we-effects-popover-content {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  /* ==========================================================================
     Gradient Preview Bar (Phase 4B)
     ========================================================================== */

  .we-gradient-bar-row {
    width: 100%;
    padding: 4px 0 8px;
  }

  .we-gradient-bar {
    position: relative;
    width: 100%;
    height: 60px;
    border-radius: 14px;
    border: 1px solid var(--we-border-subtle);
    background-color: var(--we-control-bg);
    background-image: none; /* set inline by GradientControl */
    box-shadow:
      inset 0 1px 2px rgba(0, 0, 0, 0.08),
      inset 0 0 0 1px rgba(255, 255, 255, 0.5);
    overflow: hidden;
  }

  /* Gradient thumbs container */
  .we-gradient-bar-thumbs {
    position: absolute;
    inset: 0;
    pointer-events: none; /* thumbs enable pointer events individually */
  }

  /* Gradient thumb (color stop marker) */
  .we-gradient-thumb {
    pointer-events: auto;
    position: absolute;
    top: 50%;
    left: 0;
    transform: translate(-50%, -50%);
    z-index: 1;
    width: 32px;
    height: 32px;
    border-radius: 6px;
    border: 2px solid rgba(255, 255, 255, 0.98);
    background-color: transparent; /* set inline */
    cursor: pointer;
    padding: 0;
    box-sizing: border-box;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
    touch-action: none;
    user-select: none;
    transition: box-shadow 0.15s ease, z-index 0s;
  }

  .we-gradient-thumb:hover {
    box-shadow:
      0 0 0 2px rgba(59, 130, 246, 0.25),
      0 1px 3px rgba(0, 0, 0, 0.2);
  }

  .we-gradient-thumb:focus-visible {
    outline: none;
    box-shadow:
      0 0 0 3px rgba(59, 130, 246, 0.4),
      0 1px 3px rgba(0, 0, 0, 0.2);
  }

  /* Selected thumb state - raise above unselected thumbs */
  .we-gradient-thumb--active {
    z-index: 2;
    box-shadow:
      0 0 0 3px rgba(59, 130, 246, 0.4),
      0 1px 3px rgba(0, 0, 0, 0.2);
  }

  /* Dragging thumb - always on top when overlapping at same position */
  .we-gradient-thumb--dragging {
    z-index: 3;
  }

  /* Dragging state - cursor feedback on entire bar */
  .we-gradient-bar--dragging {
    cursor: grabbing;
  }

  .we-gradient-bar--dragging .we-gradient-thumb {
    cursor: grabbing;
  }

  /* ==========================================================================
     Gradient Stops List (Phase 4D)
     ========================================================================== */

  .we-gradient-stops-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 0 4px;
  }

  .we-gradient-stops-title {
    font-size: 10px;
    font-weight: 600;
    color: var(--we-text-secondary);
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .we-gradient-stops-add,
  .we-gradient-stop-remove {
    font-size: 14px;
    font-weight: 500;
    line-height: 1;
  }

  .we-gradient-stops-add:disabled,
  .we-gradient-stop-remove:disabled {
    opacity: 0.4;
    cursor: not-allowed;
  }

  .we-gradient-stops-list {
    border: 1px solid var(--we-border-subtle);
    border-radius: 12px;
    background: rgba(255, 255, 255, 0.6);
    padding: 6px;
    display: flex;
    flex-direction: column;
    gap: 4px;
    max-height: 180px;
    overflow-y: auto;
    overscroll-behavior: contain;
  }

  .we-gradient-stop-row {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 5px 6px;
    border-radius: 8px;
    border: 1px solid transparent;
    background: rgba(255, 255, 255, 0.85);
    cursor: pointer;
    user-select: none;
    transition: border-color 0.15s ease, background 0.15s ease;
  }

  .we-gradient-stop-row:hover {
    background: rgba(59, 130, 246, 0.06);
  }

  .we-gradient-stop-row:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.35);
  }

  .we-gradient-stop-row--active {
    border-color: rgba(59, 130, 246, 0.6);
    box-shadow: 0 0 0 1px rgba(59, 130, 246, 0.2);
  }

  .we-gradient-stop-pos {
    flex: 0 0 auto;
    min-width: 44px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    text-align: right;
    font-variant-numeric: tabular-nums;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    color: var(--we-text-secondary);
    padding: 3px 6px;
    border-radius: 6px;
    background: var(--we-control-bg);
    cursor: pointer;
    transition: box-shadow 0.15s ease;
  }

  .we-gradient-stop-pos:hover {
    background: var(--we-control-bg-hover, var(--we-control-bg));
  }

  .we-gradient-stop-pos:focus-within {
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.25);
  }

  /* Static position display (visible when row is not selected) */
  .we-gradient-stop-pos-static {
    display: block;
    width: 100%;
    text-align: right;
  }

  /* Position editor slot (visible when row is selected) */
  .we-gradient-stop-pos-editor {
    display: none;
    width: 100%;
  }

  /* Show editor and hide static in active row */
  .we-gradient-stop-row--active .we-gradient-stop-pos-static {
    display: none;
  }

  .we-gradient-stop-row--active .we-gradient-stop-pos-editor {
    display: block;
  }

  /* Position input styling */
  .we-gradient-stop-pos-input {
    width: 100%;
    border: 0;
    padding: 0;
    margin: 0;
    background: transparent;
    color: inherit;
    font: inherit;
    text-align: right;
    outline: none;
    cursor: text;
  }

  .we-gradient-stop-pos-input::placeholder {
    color: var(--we-text-muted);
  }

  .we-gradient-stop-color {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 3px 8px;
    border-radius: 6px;
    background: var(--we-control-bg);
  }

  /* Static color display (visible when row is not selected) */
  .we-gradient-stop-color-static {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 0;
    border: 0;
    background: transparent;
    color: inherit;
    cursor: pointer;
    text-align: left;
    font-family: inherit;
  }

  .we-gradient-stop-color-static:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.25);
    border-radius: 4px;
  }

  /* Color editor slot (visible when row is selected) */
  .we-gradient-stop-color-editor {
    flex: 1;
    min-width: 0;
    display: none;
  }

  /* When row is active: hide static, show editor */
  .we-gradient-stop-row--active .we-gradient-stop-color {
    padding: 0;
    background: transparent;
  }

  .we-gradient-stop-row--active .we-gradient-stop-color-static {
    display: none;
  }

  .we-gradient-stop-row--active .we-gradient-stop-color-editor {
    display: block;
  }

  .we-gradient-stop-swatch {
    flex: 0 0 auto;
    width: 14px;
    height: 14px;
    border-radius: 3px;
    border: 1px solid rgba(0, 0, 0, 0.12);
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.2);
    background: transparent;
  }

  .we-gradient-stop-color-text {
    flex: 1;
    min-width: 0;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    color: var(--we-text-primary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* Spacing section (Padding / Margin) */
  .we-spacing-section {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .we-spacing-section + .we-spacing-section {
    margin-top: 10px;
  }

  .we-spacing-header {
    font-size: 10px;
    font-weight: 600;
    color: #6b7280;
  }

  /* Spacing 2x2 grid layout */
  .we-spacing-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
  }

  /* ==========================================================================
   * Border Radius Control
   * ========================================================================== */

  .we-radius-control {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .we-radius-corners-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
  }

  /* ==========================================================================
     CSS Panel (Phase 4.6)
     ========================================================================== */

  .we-css-panel {
    font-size: 11px;
    line-height: 1.5;
  }

  /* Code-semantic elements use monospace font */
  .we-css-rule-selector,
  .we-css-decl-name,
  .we-css-decl-value,
  .we-css-decl-colon,
  .we-css-decl-semi,
  .we-css-decl-important,
  .we-css-rule-source,
  .we-css-rule-spec {
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  }

  /* ==========================================================================
     Class Editor (Phase 4.7)
     ========================================================================== */

  .we-css-class-editor-mount {
    margin-bottom: 12px;
  }

  .we-class-editor {
    position: relative;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 6px;
    padding: 8px 10px;
    border: 1px solid var(--we-border-subtle);
    border-radius: var(--we-radius-panel);
    background: var(--we-surface-bg);
    font-family: system-ui, -apple-system, sans-serif;
  }

  .we-class-chips {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    flex: 0 1 auto;
  }

  .we-class-chip {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border-radius: 999px;
    background: var(--we-accent-brand-bg);
    border: 1px solid var(--we-accent-brand-border);
    color: #4338ca;
    font-size: 11px;
    line-height: 1.2;
  }

  .we-class-chip-text {
    word-break: break-all;
  }

  .we-class-chip-remove {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 16px;
    height: 16px;
    padding: 0;
    border: none;
    border-radius: 999px;
    background: transparent;
    color: rgba(67, 56, 202, 0.8);
    cursor: pointer;
    font-size: 14px;
    line-height: 1;
    transition: background-color 0.15s ease;
  }

  .we-class-chip-remove:hover {
    background: rgba(99, 102, 241, 0.15);
    color: #4338ca;
  }

  .we-class-input {
    flex: 1 1 100px;
    min-width: 80px;
    padding: 5px 8px;
    font-size: 12px;
    border: 1px solid var(--we-border-subtle);
    border-radius: var(--we-radius-control);
    background: var(--we-control-bg-focus);
    outline: none;
    transition: border-color 0.15s ease, box-shadow 0.15s ease;
  }

  .we-class-input:focus {
    border-color: var(--we-control-border-focus);
    box-shadow: 0 0 0 2px var(--we-focus-ring);
  }

  .we-class-input:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .we-class-input::placeholder {
    color: #94a3b8;
  }

  .we-class-suggestions {
    position: absolute;
    top: calc(100% + 4px);
    left: 0;
    right: 0;
    background: var(--we-surface-bg);
    border: 1px solid var(--we-border-subtle);
    border-radius: var(--we-radius-panel);
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.12);
    overflow: hidden;
    z-index: 20;
  }

  .we-class-suggestions[hidden] {
    display: none;
  }

  .we-class-suggestion {
    display: block;
    width: 100%;
    text-align: left;
    padding: 8px 10px;
    border: none;
    background: transparent;
    cursor: pointer;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    color: #0f172a;
    transition: background-color 0.1s ease;
  }

  .we-class-suggestion:hover {
    background: rgba(99, 102, 241, 0.08);
  }

  .we-class-suggestion:focus {
    outline: none;
    background: rgba(99, 102, 241, 0.12);
  }

  .we-css-info {
    padding: 8px 10px;
    background: var(--we-accent-info-bg);
    border-radius: var(--we-radius-control);
    color: var(--we-text-secondary);
    font-size: 10px;
    margin-bottom: 8px;
  }

  .we-css-info[hidden] {
    display: none;
  }

  .we-css-warnings {
    margin-bottom: 8px;
  }

  .we-css-warnings[hidden] {
    display: none;
  }

  .we-css-warning {
    padding: 6px 10px;
    background: var(--we-accent-warning-bg);
    border: 1px solid var(--we-accent-warning-border);
    border-radius: var(--we-radius-control);
    color: #92400e;
    font-size: 10px;
    margin-bottom: 4px;
  }

  .we-css-warning-more {
    padding: 4px 10px;
    color: #92400e;
    font-size: 10px;
    font-style: italic;
  }

  .we-css-empty {
    padding: 24px 12px;
    color: #64748b;
    text-align: center;
    font-family: system-ui, sans-serif;
    font-size: 12px;
  }

  .we-css-empty[hidden] {
    display: none;
  }

  .we-css-sections {
    display: flex;
    flex-direction: column;
    gap: 0;
  }

  .we-css-section {
    border: 0;
    border-radius: 0;
    overflow: visible;
    background: transparent;
  }

  .we-css-section + .we-css-section {
    border-top: 1px solid var(--we-border-section);
    padding-top: 12px;
    margin-top: 4px;
  }

  .we-css-section[data-kind="inherited"] {
    background: transparent;
  }

  .we-css-section-header {
    padding: 0 0 8px 0;
    background: transparent;
    border-bottom: 0;
    font-weight: 600;
    color: var(--we-text-primary);
    font-size: 11px;
    text-transform: none;
    letter-spacing: normal;
  }

  .we-css-section-rules {
    padding: 0;
  }

  /* Flat list style (computed-like view) */
  .we-css-rule {
    margin: 0;
    padding: 0;
    background: transparent;
    border: 0;
    border-radius: 0;
  }

  .we-css-rule + .we-css-rule {
    border-top: 1px solid var(--we-border-section);
    padding-top: 10px;
    margin-top: 10px;
  }

  .we-css-rule[data-origin="inline"] {
    background: transparent;
  }

  .we-css-rule-header {
    display: flex;
    align-items: baseline;
    gap: 8px;
    flex-wrap: nowrap;
    margin-bottom: 8px;
    padding-bottom: 0;
    border-bottom: 0;
  }

  .we-css-rule-selector {
    flex: 1 1 auto;
    min-width: 0;
    font-weight: 500;
    color: var(--we-text-secondary);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .we-css-rule[data-origin="inline"] .we-css-rule-selector {
    color: #92400e;
    font-style: italic;
  }

  .we-css-rule-source {
    flex-shrink: 0;
    color: var(--we-text-muted);
    font-size: 10px;
    margin-left: auto;
    max-width: 45%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .we-css-rule-spec {
    flex-shrink: 0;
    color: var(--we-text-muted);
    font-size: 9px;
    padding: 1px 4px;
    background: var(--we-control-bg);
    border-radius: 3px;
  }

  .we-css-decls {
    padding-left: 0;
  }

  /* Two-column grid layout for declarations */
  .we-css-decl {
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(0, 1.4fr);
    column-gap: 12px;
    align-items: baseline;
    padding: 5px 0;
    color: var(--we-text-primary);
  }


  .we-css-decl[data-status="overridden"] {
    text-decoration: line-through;
    color: var(--we-text-muted);
  }

  .we-css-decl-name {
    color: var(--we-text-secondary);
    overflow-wrap: anywhere;
  }

  /* Hide punctuation for computed-like view */
  .we-css-decl-colon,
  .we-css-decl-semi {
    display: none;
  }

  /* Value container for flex layout with !important */
  .we-css-decl-value-container {
    display: flex;
    align-items: baseline;
    gap: 4px;
    min-width: 0;
  }

  .we-css-decl-value {
    color: var(--we-text-primary);
    margin-left: 0;
    min-width: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .we-css-decl[data-status="overridden"] .we-css-decl-name,
  .we-css-decl[data-status="overridden"] .we-css-decl-value {
    color: var(--we-text-muted);
  }

  .we-css-decl-important {
    flex-shrink: 0;
    color: #dc2626;
    font-weight: 600;
    font-size: 10px;
  }

  .we-css-decl[data-status="overridden"] .we-css-decl-important {
    color: #b8c4d0;
  }

  /* ==========================================================================
   * Token Picker (Phase 5.4)
   * ========================================================================== */

  .we-token-picker {
    position: absolute;
    top: calc(100% + 4px);
    left: 0;
    right: 0;
    background: white;
    border: 1px solid rgba(226, 232, 240, 0.95);
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(15, 23, 42, 0.12);
    overflow: hidden;
    z-index: 30;
  }

  .we-token-picker[hidden] {
    display: none;
  }

  .we-token-filter {
    width: 100%;
    padding: 8px 10px;
    border: none;
    border-bottom: 1px solid rgba(226, 232, 240, 0.8);
    background: transparent;
    font-family: inherit;
    font-size: 11px;
    color: #0f172a;
    outline: none;
  }

  .we-token-filter::placeholder {
    color: #94a3b8;
  }

  .we-token-toggle-row {
    padding: 6px 10px;
    border-bottom: 1px solid rgba(226, 232, 240, 0.6);
    background: rgba(248, 250, 252, 0.5);
  }

  .we-token-toggle-label {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 10px;
    color: #64748b;
    cursor: pointer;
  }

  .we-token-toggle-checkbox {
    width: 12px;
    height: 12px;
    margin: 0;
    cursor: pointer;
  }

  .we-token-list {
    overflow-y: auto;
    overscroll-behavior: contain;
  }

  .we-token-list[hidden] {
    display: none;
  }

  .we-token-item {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    text-align: left;
    padding: 8px 10px;
    border: none;
    background: transparent;
    cursor: pointer;
    transition: background-color 0.1s ease;
  }

  .we-token-item:hover {
    background: rgba(99, 102, 241, 0.06);
  }

  .we-token-item--selected,
  .we-token-item:focus {
    outline: none;
    background: rgba(99, 102, 241, 0.1);
  }

  .we-token-swatch {
    flex-shrink: 0;
    width: 14px;
    height: 14px;
    border-radius: 3px;
    border: 1px solid rgba(0, 0, 0, 0.1);
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.2);
  }

  .we-token-name {
    flex: 1;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    color: #0f172a;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .we-token-value {
    flex-shrink: 0;
    max-width: 80px;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 10px;
    color: #64748b;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .we-token-empty {
    padding: 16px 10px;
    text-align: center;
    color: #94a3b8;
    font-size: 11px;
  }

  .we-token-empty[hidden] {
    display: none;
  }

  /* Token button for input fields */
  .we-token-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 20px;
    padding: 0;
    border: none;
    border-radius: 4px;
    background: rgba(99, 102, 241, 0.08);
    color: #6366f1;
    cursor: pointer;
    transition: background-color 0.15s ease;
  }

  .we-token-btn:hover {
    background: rgba(99, 102, 241, 0.15);
  }

  .we-token-btn:focus {
    outline: none;
    box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.3);
  }

  .we-token-btn-icon {
    width: 12px;
    height: 12px;
  }

  /* ==========================================================================
   * Token Pill (Phase 5.3)
   *
   * Compact pill UI for displaying a CSS var() reference in input fields.
   * Used when ColorField value is a standalone var(--token) expression.
   * ========================================================================== */

  .we-token-pill {
    flex: 1;
    min-width: 0;
    height: 28px;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 0 6px 0 4px;
    background: var(--we-control-bg);
    border: 1px solid transparent;
    border-radius: var(--we-radius-control);
    transition: background 0.1s ease, border-color 0.1s ease;
  }

  .we-token-pill:hover:not([data-disabled="true"]) {
    border-color: var(--we-control-border-hover);
  }

  .we-token-pill:focus-within {
    background: var(--we-control-bg-focus);
    border-color: var(--we-control-border-focus);
  }

  .we-token-pill[data-disabled="true"] {
    opacity: 0.5;
    pointer-events: none;
  }

  .we-token-pill[hidden] {
    display: none;
  }

  /* Leading slot: holds external element (ColorField swatch) or internal swatch */
  .we-token-pill__leading {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
  }

  /* Internal swatch (used when no external leading element provided) */
  .we-token-pill__swatch {
    width: 16px;
    height: 16px;
    border-radius: 4px;
    border: 1px solid rgba(0, 0, 0, 0.1);
    background: transparent;
  }

  /* Main clickable area */
  .we-token-pill__main {
    flex: 1;
    min-width: 0;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    padding: 0;
    border: none;
    background: transparent;
    color: var(--we-text-primary);
    cursor: pointer;
    font-size: 11px;
    text-align: left;
  }

  .we-token-pill__main:focus {
    outline: none;
  }

  .we-token-pill__main:disabled {
    cursor: default;
  }

  /* Token name with ellipsis */
  .we-token-pill__name {
    min-width: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
  }

  /* Link icon (rotated 45° to indicate variable binding) */
  .we-token-pill__icon {
    width: 14px;
    height: 14px;
    flex: 0 0 auto;
    color: var(--we-text-muted);
    transform: rotate(45deg);
  }

  /* Clear button (hover to reveal) */
  .we-token-pill__clear {
    width: 18px;
    height: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    border: none;
    border-radius: 4px;
    background: transparent;
    color: var(--we-text-muted);
    font-size: 14px;
    line-height: 1;
    cursor: pointer;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.12s ease, background 0.12s ease, color 0.12s ease;
  }

  .we-token-pill:hover .we-token-pill__clear {
    opacity: 1;
    pointer-events: auto;
  }

  .we-token-pill__clear:hover {
    background: rgba(15, 23, 42, 0.06);
    color: var(--we-text-primary);
  }

  .we-token-pill__clear:focus {
    outline: none;
    opacity: 1;
    pointer-events: auto;
  }

  .we-token-pill__clear:disabled {
    cursor: default;
  }

  /* ==========================================================================
     Props Panel (Phase 7.3)
     ========================================================================== */

  .we-props-panel {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .we-props-meta {
    padding: 0 0 8px 0;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .we-props-meta-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    color: var(--we-text-primary);
    font-size: 11px;
    font-weight: 600;
  }

  .we-props-component {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .we-props-badge {
    flex: 0 0 auto;
    font-size: 10px;
    font-weight: 600;
    padding: 2px 6px;
    border-radius: 999px;
    background: var(--we-accent-brand-bg);
    color: #1d4ed8;
  }

  .we-props-status {
    font-size: 11px;
    color: #64748b;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  }

  .we-props-warning {
    font-size: 11px;
    color: #92400e;
    background: var(--we-accent-warning-bg);
    border: 1px solid var(--we-accent-warning-border);
    border-radius: var(--we-radius-control);
    padding: 6px 8px;
  }

  .we-props-error {
    font-size: 11px;
    color: #b91c1c;
    background: var(--we-accent-danger-bg);
    border: 1px solid var(--we-accent-danger-border);
    border-radius: var(--we-radius-control);
    padding: 6px 8px;
  }

  .we-props-source {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 11px;
    padding: 4px 0;
  }

  .we-props-source[hidden] {
    display: none;
  }

  .we-props-source-label {
    flex: 0 0 auto;
    color: #64748b;
    font-weight: 500;
  }

  .we-props-source-path {
    flex: 1 1 auto;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: var(--we-text-primary);
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  }

  .we-btn-small {
    padding: 2px 8px;
    font-size: 11px;
  }

  /* Source open button - minimal link style */
  .we-props-source-btn {
    flex: 0 0 auto;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 2px;
    margin-left: 2px;
    border: none;
    background: none;
    color: #64748b;
    cursor: pointer;
    transition: color 0.12s ease;
  }

  .we-props-source-btn:hover:not(:disabled) {
    color: #3b82f6;
  }

  .we-props-source-btn:disabled {
    opacity: 0.35;
    cursor: not-allowed;
  }

  .we-props-source-btn svg {
    display: block;
  }

  /* Tooltip - fixed position, mounted at shadow root level */
  .we-tooltip {
    position: fixed;
    transform: translateX(-50%);
    padding: 4px 8px;
    font-size: 11px;
    font-weight: 500;
    line-height: 1.2;
    color: #fff;
    background: rgba(15, 23, 42, 0.92);
    border-radius: 4px;
    white-space: nowrap;
    pointer-events: none;
    z-index: 10000;
  }

  .we-tooltip[hidden] {
    display: none;
  }

  .we-props-title-left {
    display: flex;
    align-items: center;
    gap: 6px;
    min-width: 0;
  }

  .we-props-title-actions {
    display: flex;
    align-items: center;
    gap: 2px;
    margin-left: auto;
  }

  /* Action button - minimal icon style for title bar */
  .we-props-action-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 4px;
    border: none;
    background: none;
    color: var(--we-text-secondary);
    cursor: pointer;
    transition: color 0.12s ease;
  }

  .we-props-action-btn:hover:not(:disabled) {
    color: var(--we-text-primary);
  }

  .we-props-action-btn:disabled {
    opacity: 0.35;
    cursor: not-allowed;
  }

  .we-props-action-btn svg {
    display: block;
  }

  .we-props-list {
    overflow: hidden;
  }

  .we-props-empty {
    padding: 16px 12px;
    color: #64748b;
    font-size: 12px;
    text-align: center;
  }

  .we-props-empty[hidden] {
    display: none;
  }

  /* Loading animations */
  @keyframes we-shimmer {
    to {
      background-position: 200% center;
    }
  }

  @keyframes we-spin {
    to {
      transform: rotate(360deg);
    }
  }

  .we-props-empty.we-loading {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
  }

  .we-props-empty.we-loading svg {
    flex-shrink: 0;
    color: #94a3b8;
  }

  .we-props-empty.we-loading span {
    background: linear-gradient(
      90deg,
      #64748b 0%,
      #94a3b8 50%,
      #64748b 100%
    );
    background-size: 200% auto;
    color: transparent;
    -webkit-background-clip: text;
    background-clip: text;
    animation: we-shimmer 2s linear infinite;
  }

  .we-props-group {
    padding: 0 0 8px 0;
    margin-top: 4px;
    color: var(--we-text-primary);
    font-size: 11px;
    font-weight: 600;
    border-top: 1px solid var(--we-border-section);
    padding-top: 12px;
  }

  .we-props-group:first-child {
    border-top: 0;
    margin-top: 0;
    padding-top: 0;
  }

  .we-props-group + .we-props-row {
    border-top: 0;
  }

  .we-props-rows {
    display: flex;
    flex-direction: column;
  }

  .we-props-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
    border-top: 1px solid var(--we-border-section);
  }

  .we-props-row:first-child {
    border-top: 0;
  }

  .we-props-key {
    flex: 0 0 110px;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    color: #334155;
  }

  .we-props-value {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 8px;
  }

  .we-props-value--readonly {
    justify-content: flex-start;
    color: #475569;
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    font-size: 11px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .we-props-input {
    width: 140px;
    max-width: 100%;
  }

  .we-props-input--invalid {
    border-color: rgba(248, 113, 113, 0.85);
  }

  .we-props-bool {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-size: 11px;
    color: #475569;
    cursor: pointer;
  }

  .we-props-checkbox {
    width: 14px;
    height: 14px;
    accent-color: #6366f1;
    cursor: pointer;
  }

  .we-props-checkbox:disabled {
    cursor: not-allowed;
    opacity: 0.5;
  }

  /* ==========================================================================
   * Color Field (Phase 4.4)
   * ========================================================================== */

  .we-color-field {
    flex: 1;
    display: flex;
    align-items: center;
    gap: 6px;
    min-width: 0;
  }

  .we-color-swatch {
    flex: 0 0 auto;
    width: 24px;
    height: 24px;
    padding: 0;
    position: relative;
    border: 1px solid var(--we-border-subtle);
    border-radius: var(--we-radius-control);
    background: var(--we-control-bg);
    cursor: pointer;
    transition: border-color 0.15s ease, box-shadow 0.15s ease;
    overflow: hidden;
  }

  .we-color-swatch:hover {
    border-color: var(--we-border-strong);
  }

  .we-color-swatch:focus-visible,
  .we-color-swatch:focus-within {
    outline: none;
    box-shadow: 0 0 0 2px var(--we-focus-ring);
  }

  .we-color-swatch:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  /* Native color input overlays the swatch for direct click interaction */
  .we-color-native-input {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    cursor: pointer;
    border: none;
    padding: 0;
    margin: 0;
  }

  .we-color-text {
    flex: 1;
    min-width: 0;
  }

  /* ==========================================================================
   * Tooltip (data-tooltip)
   *
   * CSS-only tooltips using the data-tooltip attribute.
   * Shows on hover/focus with minimal delay.
   * ========================================================================== */

  [data-tooltip] {
    position: relative;
  }

  [data-tooltip]::after {
    content: attr(data-tooltip);
    position: absolute;
    bottom: calc(100% + 6px);
    left: 50%;
    transform: translateX(-50%);
    padding: 4px 8px;
    font-size: 11px;
    font-family: inherit;
    font-weight: 400;
    line-height: 1.3;
    white-space: nowrap;
    color: var(--we-surface-bg);
    background-color: var(--we-text-primary);
    border-radius: var(--we-radius-control);
    opacity: 0;
    visibility: hidden;
    transition:
      opacity 100ms ease,
      visibility 100ms ease;
    pointer-events: none;
    z-index: 99999;
  }

  [data-tooltip]::before {
    content: '';
    position: absolute;
    bottom: calc(100% + 2px);
    left: 50%;
    transform: translateX(-50%);
    border: 4px solid transparent;
    border-top-color: var(--we-text-primary);
    opacity: 0;
    visibility: hidden;
    transition:
      opacity 100ms ease,
      visibility 100ms ease;
    pointer-events: none;
    z-index: 99999;
  }

  [data-tooltip]:hover::after,
  [data-tooltip]:focus-visible::after,
  [data-tooltip]:focus-within::after {
    opacity: 1;
    visibility: visible;
  }

  [data-tooltip]:hover::before,
  [data-tooltip]:focus-visible::before,
  [data-tooltip]:focus-within::before {
    opacity: 1;
    visibility: visible;
  }

  /* ==========================================================================
   * Global Hidden Rule
   * Ensures [hidden] attribute always hides elements, even when they have
   * explicit display values (flex, inline-flex, etc.)
   * ========================================================================== */
  [hidden] {
    display: none !important;
  }
`;function gn(e,t,n){e.style.setProperty(t,n,"important")}function fl(e={}){var d;const t=new Pe;let n=null;const r=document.getElementById(ht);if(r)try{r.remove()}catch(b){}const o=document.createElement("div");o.id=ht,o.setAttribute("data-mcp-web-editor","v2"),gn(o,"position","fixed"),gn(o,"inset","0"),gn(o,"z-index",String(Xr)),gn(o,"pointer-events","none"),gn(o,"contain","layout style paint"),gn(o,"isolation","isolate");const i=o.attachShadow({mode:"open"}),s=document.createElement("style");s.textContent=dl,i.append(s);const a=document.createElement("div");a.id=Tn;const l=document.createElement("div");l.id=Yn,i.append(a,l),((d=document.documentElement)!=null?d:document.body).append(o),t.add(()=>o.remove()),n={host:o,shadowRoot:i,overlayRoot:a,uiRoot:l};const u=["pointerdown","pointerup","pointermove","pointerenter","pointerleave","mousedown","mouseup","mousemove","mouseenter","mouseleave","click","dblclick","contextmenu","keydown","keyup","keypress","wheel","touchstart","touchmove","touchend","touchcancel","focus","blur","input","change"],f=b=>{b.stopPropagation()};for(const b of u)t.listen(l,b,f),t.listen(a,b,f);const m=b=>{if(!(b instanceof Node))return!1;if(b===o)return!0;const S=typeof b.getRootNode=="function"?b.getRootNode():null;return S instanceof ShadowRoot&&S.host===o};return{getElements:()=>n,isOverlayElement:m,isEventFromUi:b=>{try{if(typeof b.composedPath=="function")return b.composedPath().some(S=>m(S))}catch(S){}return m(b.target)},dispose:()=>{n=null,t.dispose()}}}const Tt={capture:!0,passive:!1};function Nn(e){e.cancelable&&e.preventDefault(),e.stopImmediatePropagation(),e.stopPropagation()}function li(e,t,n){if(!Number.isFinite(e))return t;const r=Math.min(t,n),o=Math.max(t,n);return Math.min(o,Math.max(r,e))}function pl(e,t,n,r){const o=Number.isFinite(n)?Math.max(0,n):0,i=Math.max(o,r.width-o-t.width),s=Math.max(o,r.height-o-t.height);return{left:li(e.left,o,i),top:li(e.top,o,s)}}function ci(e){return{left:Math.round(e.left),top:Math.round(e.top)}}function ui(e){var P,j;const{handleEl:t,targetEl:n,onPositionChange:r,clampMargin:o}=e,i=Math.max(0,(P=e.clickThresholdMs)!=null?P:0),s=Math.max(0,(j=e.moveThresholdPx)!=null?j:0),a=i>0,l=s*s;let c=null,u=!1,f=null;function m(){window.removeEventListener("pointermove",v,Tt),window.removeEventListener("pointerup",L,Tt),window.removeEventListener("pointercancel",A,Tt),window.removeEventListener("keydown",O,Tt),window.removeEventListener("blur",V,Tt),document.removeEventListener("visibilitychange",F)}function h(){f!==null&&(window.clearTimeout(f),f=null)}function d(E){const w=c;if(w&&w.pointerId===E){h();try{t.releasePointerCapture(E)}catch(D){}m(),c=null,t.dataset.dragging="false"}}function b(E){const w=c,D={width:window.innerWidth,height:window.innerHeight},$=w?{width:w.targetWidth,height:w.targetHeight}:(()=>{const I=n.getBoundingClientRect();return{width:I.width,height:I.height}})(),x=pl(E,$,o,D);r(ci(x))}function S(){const E=c;E&&(b(E.startPosition),d(E.pointerId))}function g(){const E=w=>{Nn(w)};t.addEventListener("click",E,{capture:!0,once:!0}),window.setTimeout(()=>{t.removeEventListener("click",E,{capture:!0})},300)}function k(E){const w=c;if(!(!w||w.pointerId!==E||w.activated)){w.activated=!0,t.dataset.dragging="true",h();try{t.setPointerCapture(E)}catch(D){}}}function v(E){const w=c;if(w&&E.pointerId===w.pointerId){if(!w.activated){if(!a||l<=0)return;const D=E.clientX-w.startClientX,$=E.clientY-w.startClientY;if(D*D+$*$<l)return;k(E.pointerId)}Nn(E),b({left:E.clientX-w.offsetX,top:E.clientY-w.offsetY})}}function L(E){const w=c;w&&E.pointerId===w.pointerId&&(w.activated&&(Nn(E),g()),d(E.pointerId))}function A(E){const w=c;w&&E.pointerId===w.pointerId&&(w.activated?(Nn(E),S()):d(E.pointerId))}function O(E){if(E.key!=="Escape")return;const w=c;w&&(w.activated?(E.preventDefault(),E.stopImmediatePropagation(),E.stopPropagation(),S()):d(w.pointerId))}function V(){const E=c;E&&(E.activated?S():d(E.pointerId))}function F(){const E=c;E&&document.visibilityState==="hidden"&&(E.activated?S():d(E.pointerId))}function T(E){if(u||!n.isConnected||c||E.button!==0||!E.isPrimary)return;a||Nn(E);const w=n.getBoundingClientRect(),D=ci({left:w.left,top:w.top});c={pointerId:E.pointerId,startPosition:D,offsetX:E.clientX-w.left,offsetY:E.clientY-w.top,targetWidth:w.width,targetHeight:w.height,startClientX:E.clientX,startClientY:E.clientY,activated:!a},t.dataset.dragging=c.activated?"true":"false";try{t.setPointerCapture(E.pointerId)}catch($){}if(a){h();const $=E.pointerId;f=window.setTimeout(()=>{k($)},i)}window.addEventListener("pointermove",v,Tt),window.addEventListener("pointerup",L,Tt),window.addEventListener("pointercancel",A,Tt),window.addEventListener("keydown",O,Tt),window.addEventListener("blur",V,Tt),document.addEventListener("visibilitychange",F)}return t.dataset.dragging="false",t.addEventListener("pointerdown",T),()=>{if(u=!0,t.removeEventListener("pointerdown",T),c)try{c.activated?S():d(c.pointerId)}catch(E){}m(),h(),c=null,t.dataset.dragging="false"}}function jn(){const e=document.createElementNS("http://www.w3.org/2000/svg","svg");return e.setAttribute("viewBox","0 0 20 20"),e.setAttribute("fill","none"),e.setAttribute("aria-hidden","true"),e}function di(){const e=document.createElementNS("http://www.w3.org/2000/svg","svg");return e.setAttribute("viewBox","0 0 24 24"),e.setAttribute("fill","none"),e.setAttribute("aria-hidden","true"),e}function _n(e){const t=document.createElementNS("http://www.w3.org/2000/svg","path");return t.setAttribute("d",e),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","2"),t.setAttribute("stroke-linecap","round"),t.setAttribute("stroke-linejoin","round"),t}function ml(){const e=jn();return e.append(_n("M6 6l8 8M14 6l-8 8")),e}function fi(){const e=jn(),t=[[7,6],[13,6],[7,10],[13,10],[7,14],[13,14]];for(const[n,r]of t){const o=document.createElementNS("http://www.w3.org/2000/svg","circle");o.setAttribute("cx",String(n)),o.setAttribute("cy",String(r)),o.setAttribute("r","1.4"),o.setAttribute("fill","currentColor"),e.append(o)}return e}function hl(){const e=jn();return e.classList.add("we-chevron"),e.append(_n("M7 8l3 3 3-3")),e}function gl(){const e=di();return e.append(_n("M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6")),e}function bl(){const e=di();return e.append(_n("M21 10h-10a8 8 0 00-8 8v2M21 10l-6 6m6-6l-6-6")),e}function wl(){const e=jn();return e.append(_n("M6 12l4-4 4 4")),e}function xl(){const e=document.createElementNS("http://www.w3.org/2000/svg","svg");e.setAttribute("viewBox","0 0 24 24"),e.setAttribute("fill","none"),e.setAttribute("aria-hidden","true");const t=document.createElementNS("http://www.w3.org/2000/svg","path");return t.setAttribute("d","M19 9l-7 7-7-7"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","2"),t.setAttribute("stroke-linecap","round"),t.setAttribute("stroke-linejoin","round"),e.append(t),e}function yl(e){return!!e&&(typeof e=="object"||typeof e=="function")&&typeof e.then=="function"}function vl(e){if(!e||typeof e!="object")return!1;const t=e.requestId;return t===void 0||typeof t=="string"}function El(e,t){const n=t!=null&&t.requestId?`requestId=${t.requestId}`:"";return n?`${e} (${n})`:e}const Sl=2400,kl=["success","completed","verified"],Cl=["error","failed","timeout","cancelled","mismatch","lost","uncertain"],Al=["applying","running","starting","locating","verifying"];function pi(e){return kl.includes(e)?"success":Cl.includes(e)?"error":Al.includes(e)?"progress":"idle"}function Tl(e){var oe,he;const t=new Pe,n=(oe=e.dock)!=null?oe:"top";let r=0,o=0,i="idle",s="",a=!1,l=null,c=!1,u=(he=e.initialPosition)!=null?he:null;const f=document.createElement("div");f.className="we-toolbar",f.dataset.position=n,f.dataset.status=i,f.dataset.minimized="false",f.dataset.dragged=u?"true":"false",f.dataset.structureOpen="false",f.setAttribute("role","toolbar"),f.setAttribute("aria-label","Web Editor Toolbar");const m=document.createElement("button");m.type="button",m.className="we-drag-handle",m.setAttribute("aria-label","Collapse toolbar"),m.dataset.tooltip="Collapse",m.append(fi());const h=document.createElement("div");h.className="we-toolbar-content";const d=document.createElement("div");d.className="we-toolbar-indicator";const b=document.createElement("span");b.className="we-toolbar-indicator-dot";const S=document.createElement("span");S.className="we-toolbar-indicator-label",S.textContent="Editor",d.append(b,S);const g=document.createElement("div");g.className="we-toolbar-history";const k=document.createElement("span"),v=document.createElement("b");v.className="we-toolbar-history-value",k.append("Undo: ",v);const L=document.createElement("span"),A=document.createElement("b");A.className="we-toolbar-history-value",L.append("Redo: ",A),g.append(k,L);const O=document.createElement("div");O.className="we-toolbar-divider";const V=document.createElement("div");V.className="we-toolbar-structure-group";const F=document.createElement("div");F.className="we-toolbar-structure-separator";const T=document.createElement("button");T.type="button",T.className="we-toolbar-apply-btn",T.textContent="Apply",T.setAttribute("aria-label","Apply changes to code");const P=document.createElement("button");P.type="button",P.className="we-toolbar-group-icon-btn",P.setAttribute("aria-label","Undo last change"),P.dataset.tooltip="Undo",P.append(gl());const j=document.createElement("button");j.type="button",j.className="we-toolbar-group-icon-btn",j.setAttribute("aria-label","Redo last undone change"),j.dataset.tooltip="Redo",j.append(bl());const E=document.createElement("button");E.type="button",E.className="we-toolbar-close-btn",E.setAttribute("aria-label","Close Web Editor"),E.dataset.tooltip="Exit Editor",E.append(ml());const w=document.createElement("span");w.className="we-sr-only",w.setAttribute("aria-live","polite");const D=new Set(["HTML","BODY","HEAD"]),$=new Set(["HTML","HEAD"]),x="10px",I=document.createElement("div");I.className="we-structure-wrap",I.style.position="relative",I.style.display="inline-flex";const N=document.createElement("button");N.type="button",N.className="we-toolbar-structure-btn",N.setAttribute("aria-label","Structure operations"),N.setAttribute("aria-haspopup","menu"),N.setAttribute("aria-expanded","false"),N.append(document.createTextNode("Structure"),xl());const _=document.createElement("div");_.className="we-structure-menu",_.setAttribute("role","menu"),_.setAttribute("aria-label","Structure actions"),Object.assign(_.style,{position:"absolute",top:"calc(100% + 8px)",right:"0",minWidth:"160px",padding:"6px",background:"rgba(255, 255, 255, 0.98)",border:"1px solid rgba(148, 163, 184, 0.45)",borderRadius:"10px",boxShadow:"0 4px 6px -1px rgba(0, 0, 0, 0.08), 0 10px 20px -5px rgba(0, 0, 0, 0.12)",backdropFilter:"blur(8px)",display:"none",flexDirection:"column",gap:"4px",zIndex:"10001"}),I.append(N,_);function M(U){switch(U){case"group":return{action:"wrap",wrapperTag:"div"};case"stack":return{action:"wrap",wrapperTag:"div",wrapperStyles:{display:"flex","flex-direction":"column",gap:x}};case"ungroup":return{action:"unwrap"};case"duplicate":return{action:"duplicate"};case"delete":return{action:"delete"}}}function W(U,ie){const ve=document.createElement("button");return ve.type="button",ve.className=U==="delete"?"we-btn we-btn--danger":"we-btn",ve.textContent=ie,ve.setAttribute("role","menuitem"),ve.dataset.action=U,Object.assign(ve.style,{width:"100%",justifyContent:"flex-start",padding:"6px 10px"}),ve}const C=[{action:"group",label:"Group",el:W("group","Group")},{action:"stack",label:"Stack",el:W("stack","Stack")},{action:"ungroup",label:"Ungroup",el:W("ungroup","Ungroup")},{action:"duplicate",label:"Duplicate",el:W("duplicate","Duplicate")},{action:"delete",label:"Delete",el:W("delete","Delete")}];for(const U of C)_.append(U.el);let p=!1;function y(U){p=U,_.style.display=U?"flex":"none",N.setAttribute("aria-expanded",U?"true":"false"),f.dataset.structureOpen=U?"true":"false"}function R(){var ie,ve;const U=(ve=(ie=e.getSelectedElement)==null?void 0:ie.call(e))!=null?ve:null;return U!=null&&U.isConnected?U:null}function B(U){var ve;const ie=(ve=U.tagName)==null?void 0:ve.toUpperCase();return D.has(ie)}function Y(U){var ve;const ie=(ve=U.tagName)==null?void 0:ve.toUpperCase();return $.has(ie)}function Q(U,ie){if(a)return"Operation in progress";if(!e.onStructure)return"Not configured";if(!ie)return"Select an element first";if(B(ie))return"Cannot edit <html>, <body>, or <head>";const ve=ie.parentElement;switch(U){case"group":case"stack":return ve?Y(ve)?"Cannot wrap under <html> or <head>":null:"Element has no parent";case"ungroup":return ve?Y(ve)?"Cannot unwrap under <html> or <head>":ie.childElementCount!==1?"Ungroup requires exactly one child":null:"Element has no parent";case"duplicate":case"delete":return ve?Y(ve)?"Cannot modify under <html> or <head>":null:"Element has no parent"}}function te(){var ve;const U=R();let ie=!1;for(const ge of C){const ye=Q(ge.action,U),ke=!!ye;ge.el.disabled=ke,ge.el.title=ye!=null?ye:"",ie=ie||!ke}N.disabled=!ie,N.title=ie?"":(ve=Q("group",U))!=null?ve:"Unavailable",N.disabled&&p&&y(!1)}V.append(I,F,P,j);const se=document.createElement("div");se.className="we-toolbar-end-actions",se.append(T,E),h.append(d,g,O,V,se),f.append(m,h,w),e.container.append(f),t.add(()=>f.remove());const pe=16;function xe(U){const ie=f.getBoundingClientRect(),ve=window.innerWidth,ge=window.innerHeight,ye=pe,ke=Math.max(ye,ve-ye-ie.width),We=Math.max(ye,ge-ye-ie.height),Re=Number.isFinite(U.left)?U.left:0,gt=Number.isFinite(U.top)?U.top:0;return{left:Math.round(Math.min(ke,Math.max(ye,Re))),top:Math.round(Math.min(We,Math.max(ye,gt)))}}function we(){if(f.dataset.dragged=u?"true":"false",!u){f.style.left="",f.style.top="",f.style.right="",f.style.bottom="",f.style.transform="";return}f.style.left=`${u.left}px`,f.style.top=`${u.top}px`,f.style.right="auto",f.style.bottom="auto",f.style.transform="none"}function H(U){var ie;u=U?xe(U):null,we(),(ie=e.onPositionChange)==null||ie.call(e,u)}function ae(){return u}t.add(ui({handleEl:m,targetEl:f,clampMargin:pe,onPositionChange:U=>H(U),clickThresholdMs:200,moveThresholdPx:5})),u!==null?H(u):we();function ne(){l!==null&&(window.clearTimeout(l),l=null)}t.add(ne);function me(U){const ie=c;c=U,f.dataset.minimized=c?"true":"false",c&&y(!1),ie&&!c&&u&&(H(u),f.addEventListener("transitionend",ve=>{ve.target===f&&(ve.propertyName!=="width"&&ve.propertyName!=="height"||!c&&u&&H(u))},{once:!0})),m.setAttribute("aria-label",c?"Expand toolbar":"Collapse toolbar"),m.dataset.tooltip=c?"Expand":"Collapse"}function z(){v.textContent=String(r),A.textContent=String(o)}function J(){var ve;P.disabled=a||r<=0,j.disabled=a||o<=0;const U=(ve=e.getApplyBlockReason)==null?void 0:ve.call(e),ie=!!U;T.disabled=a||r<=0||!e.onApply||ie,T.textContent=a?"Applying…":"Apply",T.title=ie?U:"",te()}function le(){const U=pi(i);f.dataset.status=U,f.dataset.statusDetail=i,w.textContent=i==="idle"?"":s}function be(){ne(),l=window.setTimeout(()=>Ne("idle"),Sl)}function Te(U,ie){r=Math.max(0,Math.floor(U)),o=Math.max(0,Math.floor(ie)),z(),J()}function Ne(U,ie){i=U,s=(ie!=null?ie:"").trim(),le();const ve=pi(i);ve==="success"||ve==="error"?be():ne()}function Z(){return Qe(this,null,function*(){if(!T.disabled&&e.onApply){a=!0,J(),Ne("applying","Sending…");try{const U=e.onApply(),ie=yl(U)?yield U:U,ve=vl(ie)?ie:void 0;Ne("success",El("Sent",ve))}catch(U){const ie=U instanceof Error?U.message:String(U);Ne("error",ie||"Failed")}finally{a=!1,J()}}})}t.listen(T,"click",U=>{U.preventDefault(),Z()}),t.listen(m,"click",U=>{U.preventDefault(),me(!c)}),t.listen(N,"click",U=>{U.preventDefault(),!N.disabled&&y(!p)});for(const U of C)t.listen(U.el,"click",ie=>{ie.preventDefault(),!U.el.disabled&&e.onStructure&&(e.onStructure(M(U.action)),y(!1))});t.listen(window,"pointerdown",U=>{if(!p)return;try{if(typeof U.composedPath=="function"&&U.composedPath().some(ge=>ge===I))return}catch(ve){}const ie=U.target;ie instanceof Node&&I.contains(ie)||y(!1)},{capture:!0}),t.listen(window,"keydown",U=>{p&&U.key==="Escape"&&(U.preventDefault(),U.stopPropagation(),y(!1))},{capture:!0}),t.listen(P,"click",U=>{var ie;U.preventDefault(),!P.disabled&&((ie=e.onUndo)==null||ie.call(e))}),t.listen(j,"click",U=>{var ie;U.preventDefault(),!j.disabled&&((ie=e.onRedo)==null||ie.call(e))}),t.listen(E,"click",U=>{var ie;U.preventDefault(),(ie=e.onRequestClose)==null||ie.call(e)});const G=140;let K=null,q=null;function de(){t.isDisposed||(q=window.setTimeout(()=>{q=null;const U=R();U!==K&&(K=U,y(!1),J()),de()},G))}return e.getSelectedElement&&(K=R(),de(),t.add(()=>{q!==null&&(window.clearTimeout(q),q=null)})),z(),J(),le(),{setHistory:Te,setStatus:Ne,getPosition:ae,setPosition:H,dispose:()=>t.dispose()}}const Nl=64,_l=36,Rl=2,Il="›",Ll="⬡",mi=10,Rn=8,Ml=320;function Dl(e,t){const n=e.trim();return n.length<=t?n:`${n.slice(0,Math.max(0,t-1)).trimEnd()}…`}function Pl(e){var i,s;const t=e.tagName.toLowerCase(),n=(i=e.id)==null?void 0:i.trim();let r="";if(n)r=`#${n}`;else{const a=Array.from((s=e.classList)!=null?s:[]).map(l=>l.trim()).filter(Boolean).slice(0,Rl);a.length>0&&(r=`.${a.join(".")}`)}const o=`${t}${r}`;return{fullLabel:o,label:Dl(o,_l)}}function Ol(e){var r;const t=[];let n=e;for(let o=0;n&&o<Nl;o++){const i=n.tagName.toUpperCase();if(i==="HTML"||i==="BODY")break;const s=n.parentElement;if(s){t.push({element:n,crossToParent:!1}),n=s;continue}const a=(r=n.getRootNode)==null?void 0:r.call(n);if(a instanceof ShadowRoot&&a.host instanceof Element){t.push({element:n,crossToParent:!0}),n=a.host;continue}t.push({element:n,crossToParent:!1});break}return t.reverse().map(({element:o,crossToParent:i})=>{const{label:s,fullLabel:a}=Pl(o);return{element:o,label:s,fullLabel:a,boundaryBefore:i}})}function Fl(e){var S;const t=new Pe,n=(S=e.dock)!=null?S:"top";let r=null,o=[],i=null,s=0,a=0;const l=document.createElement("nav");l.className="we-breadcrumbs",l.dataset.position=n,l.dataset.hidden="true",l.setAttribute("aria-label","Selection breadcrumbs"),e.container.append(l),t.add(()=>l.remove());function c(g,k,v){return v<k?k:Math.min(v,Math.max(k,g))}function u(g){const k=16+Ml+16;return g-k}function f(){const g=l.getBoundingClientRect();s=g.width,a=g.height}function m(){if(!r||!i||!(s>0&&a>0))return;const g=window.innerWidth,k=window.innerHeight,v=u(g),L=Math.min(g-Rn-s,v-s),A=c(i.left,Rn,L),O=i.top-mi-a,V=i.top+i.height+mi,F=O>=Rn?O:V,T=c(F,Rn,k-Rn-a);l.style.left=`${Math.round(A)}px`,l.style.top=`${Math.round(T)}px`}function h(){if(l.textContent="",!r){l.dataset.hidden="true";return}l.dataset.hidden="false";const g=document.createDocumentFragment();for(let k=0;k<o.length;k++){const v=o[k];if(k>0){const A=document.createElement("span"),O=v.boundaryBefore;A.className=O?"we-crumb-sep we-crumb-sep--shadow":"we-crumb-sep",A.textContent=O?Ll:Il,A.setAttribute("aria-hidden","true"),g.append(A)}const L=document.createElement("button");L.type="button",L.className="we-crumb",L.dataset.index=String(k),L.textContent=v.label,L.title=v.fullLabel,k===o.length-1&&(L.classList.add("we-crumb--current"),L.setAttribute("aria-current","page")),g.append(L)}l.append(g),f(),m()}t.listen(l,"click",g=>{var V;const k=g.target;if(!(k instanceof Element))return;const v=k.closest("button.we-crumb");if(!(v instanceof HTMLButtonElement))return;g.preventDefault();const L=(V=v.dataset.index)!=null?V:"",A=Number(L);if(!Number.isInteger(A)||A<0)return;const O=o[A];O&&O.element.isConnected&&e.onSelect(O.element)});function d(g){t.isDisposed||(r=g,o=g?Ol(g):[],h())}function b(g){t.isDisposed||(i=g,m())}return{setTarget:d,setAnchorRect:b,dispose:()=>t.dispose()}}function Bl(e){return typeof e=="string"&&e.trim().length>0}function Yr(e){return e==null?!1:typeof e=="string"?e.trim().length>0:!0}function hi(...e){return e.filter(Bl).join(" ")}function Xe(e){const{ariaLabel:t,type:n="text",inputMode:r,prefix:o,suffix:i,rootClassName:s,inputClassName:a,autocomplete:l="off",spellcheck:c=!1,placeholder:u}=e,f=document.createElement("div");f.className=hi("we-input-container",s);let m=null;const h=document.createElement("input");h.type=n,h.className=hi("we-input-container__input",a),h.setAttribute("autocomplete",l),h.spellcheck=c,h.setAttribute("aria-label",t),r&&(h.inputMode=r),u!==void 0&&(h.placeholder=u);let d=null;function b(S,g,k){if(!Yr(g))return k&&k.remove(),null;const v=k!=null?k:document.createElement("span");return v.className=`we-input-container__${S}`,v.textContent="",typeof g=="string"?v.textContent=g:v.append(g),v}return Yr(o)&&(m=b("prefix",o,null),m&&f.append(m)),f.append(h),Yr(i)&&(d=b("suffix",i,null),d&&f.append(d)),{root:f,input:h,setPrefix(S){const g=b("prefix",S,m);g&&!m&&f.insertBefore(g,h),m=g},setSuffix(S){const g=b("suffix",S,d);g&&!d&&f.append(g),d=g},getSuffixText(){var g;return d&&((g=d.textContent)==null?void 0:g.trim())||null}}}const gi=new Set(["auto","inherit","initial","unset","none","fit-content","min-content","max-content","revert","revert-layer"]),bi=/\b(?:calc|var|clamp|min|max|fit-content)\s*\(/i,wi=/^(-?(?:\d+|\d*\.\d+|\.\d+))\s*([a-zA-Z%]+)$/,xi=/^-?(?:\d+|\d*\.\d+|\.\d+)$/,yi=/^-?\d+\.$/;function Vl(e){var r;const t=e.trim();if(!t)return!1;const n=(r=t.split(/\s+/)[0])!=null?r:"";return/^-?(?:\d+|\d*\.\d+)([a-zA-Z%]+)$/.test(n)}function bt(e){var o,i;const t=e.trim();if(!t)return{value:"",suffix:"px"};const n=t.toLowerCase();if(gi.has(n))return{value:t,suffix:null};if(bi.test(t))return{value:t,suffix:null};const r=t.match(wi);if(r){const s=(o=r[1])!=null?o:"",a=(i=r[2])!=null?i:"";return{value:s,suffix:a||null}}return xi.test(t)?{value:t,suffix:"px"}:yi.test(t)?{value:t.slice(0,-1),suffix:"px"}:{value:t,suffix:null}}function wt(e,t){const n=e.trim();if(!n)return"";const r=n.toLowerCase();if(gi.has(r)||bi.test(n)||wi.test(n))return n;if(yi.test(n)){const o=n.slice(0,-1);return t?`${o}${t}`:`${o}px`}return xi.test(n)?t?`${n}${t}`:`${n}px`:n}const $l=1,Hl=10,zl=.1,Ul=["","px","%","rem","em","vh","vw","vmin","vmax"],Gl=10;function jr(e){const t=e.indexOf(".");return t<0?0:Math.max(0,e.length-t-1)}function Wl(e){if(!Number.isFinite(e))return 0;const t=String(e);return t.includes("e")||t.includes("E")?0:jr(t)}function Xl(e){return Number.isFinite(e)?Math.max(0,Math.min(Gl,Math.trunc(e))):0}function Yl(e,t){const n=Xl(t),r=e.toFixed(n);return n===0?r:r.replace(/(\.\d*?)0+$/,"$1").replace(/\.$/,"")}const jl=/^(-?(?:(?:\d+\.\d+)|(?:\d+\.)|(?:\d+)|(?:\.\d+)))$/;function Kl(e){var s;const t=e.trim();if(!t)return null;const n=t.match(jl);if(!n)return null;const r=(s=n[1])!=null?s:"",o=r.endsWith(".")?r.slice(0,-1):r,i=Number(o);return Number.isFinite(i)?{value:i,digits:jr(o)}:null}const ql=/^(-?(?:(?:\d+\.\d+)|(?:\d+\.)|(?:\d+)|(?:\.\d+)))\s*([a-zA-Z%]*)$/;function Zl(e,t){var l,c;const n=e.trim();if(!n)return null;const r=n.match(ql);if(!r)return null;const o=(l=r[1])!=null?l:"",i=((c=r[2])!=null?c:"").toLowerCase();if(!t.includes(i))return null;const s=o.endsWith(".")?o.slice(0,-1):o,a=Number(s);return Number.isFinite(a)?{value:a,digits:jr(s),unit:i}:null}function Ye(e,t,n){const{mode:r,step:o=$l,shiftStep:i=Hl,altStep:s=zl,min:a,max:l,integer:c=!1,allowedUnits:u=Ul}=n;e.listen(t,"keydown",f=>{if(f.key!=="ArrowUp"&&f.key!=="ArrowDown"||f.metaKey||f.ctrlKey||t.disabled||t.readOnly)return;const m=f.key==="ArrowUp"?1:-1;let h;if(f.altKey?h=s:f.shiftKey?h=i:h=o,!Number.isFinite(h)||h===0)return;const d=(t.value||t.placeholder||"").trim();let b=null,S="";if(r==="number")b=Kl(d),!b&&!d&&(b={value:0,digits:0});else{const A=Zl(d,u);A?(b=A,S=A.unit):d||(b={value:0,digits:0},S="")}if(!b)return;const g=c?0:Math.max(b.digits,Wl(h));let k=b.value+m*h;typeof a=="number"&&(k=Math.max(a,k)),typeof l=="number"&&(k=Math.min(l,k)),c&&(k=Math.round(k));const v=Yl(k,g),L=r==="css-length"?`${v}${S}`:v;f.preventDefault(),t.value=L;try{t.dispatchEvent(new Event("input",{bubbles:!0}))}catch(A){}})}const Ql=[{value:"fixed",label:"Fixed"},{value:"fit",label:"Fit"},{value:"fill",label:"Fill"}],vi=["auto","fit-content","max-content","min-content"];function Ei(e){try{const t=e.getRootNode();return t instanceof ShadowRoot?t.activeElement===e:document.activeElement===e}catch(t){return!1}}function Kr(e,t){try{const n=e.style;return!n||typeof n.getPropertyValue!="function"?"":n.getPropertyValue(t).trim()}catch(n){return""}}function Kn(e,t){try{return window.getComputedStyle(e).getPropertyValue(t).trim()}catch(n){return""}}function Jl(e,t){try{const n=e.getBoundingClientRect(),r=t==="width"?n.width:n.height;return Number.isFinite(r)?`${Math.round(r*100)/100}px`:"0px"}catch(n){return"0px"}}function In(e){const t=e.trim().toLowerCase();if(!t)return"fixed";if(t==="100%")return"fill";for(const n of vi)if(t===n||t.startsWith(`${n}(`))return"fit";return"fixed"}function ec(e,t){var r;const n=t.trim().toLowerCase();for(const o of vi)if(n===o||n.startsWith(`${o}(`))return t.trim();try{if(typeof CSS!="undefined"&&((r=CSS.supports)!=null&&r.call(CSS,e,"fit-content")))return"fit-content"}catch(o){}return"auto"}function tc(e){const t=document.createElement("select");t.className="we-select we-size-mode-select",t.setAttribute("aria-label",e);for(const{value:n,label:r}of Ql){const o=document.createElement("option");o.value=n,o.textContent=r,t.appendChild(o)}return t}function nc(e){const{container:t,transactionManager:n}=e,r=new Pe;let o=null;const i=document.createElement("div");i.className="we-field-group";function s(F,T){const P=document.createElement("div");P.className="we-size-field";const j=tc(`${F} mode`),E=Xe({ariaLabel:F.charAt(0).toUpperCase()+F.slice(1),inputMode:"decimal",prefix:T,suffix:"px"});return Ye(r,E.input,{mode:"css-length"}),P.append(j,E.root),{property:F,column:P,modeSelect:j,input:E.input,container:E,lastFixedValue:"",handle:null}}const a=s("width","W"),l=s("height","H"),c=document.createElement("div");c.className="we-field-row",c.append(a.column,l.column),i.append(c),t.append(i),r.add(()=>i.remove());const u={width:a,height:l};function f(F){if(r.isDisposed)return null;const T=o;if(!T||!T.isConnected)return null;const P=u[F];if(P.handle)return P.handle;const j=n.beginStyle(T,F);return P.handle=j,j}function m(F){const T=u[F],P=T.handle;T.handle=null,P&&P.commit({merge:!0})}function h(F){const T=u[F],P=T.handle;T.handle=null,P&&P.rollback()}function d(){m("width"),m("height")}function b(F,T){F.container.root.hidden=T!=="fixed"}function S(F,T){const P=F.lastFixedValue.trim();if(P&&In(P)==="fixed")return P;const j=Kn(T,F.property);return j&&In(j)==="fixed"?j:Jl(T,F.property)}function g(F,T=!1){const P=u[F],j=o;if(!j||!j.isConnected){P.modeSelect.value="fixed",P.modeSelect.disabled=!0,b(P,"fixed"),P.input.value="",P.input.placeholder="",P.input.disabled=!0,P.container.setSuffix("px");return}if(P.modeSelect.disabled=!1,P.input.disabled=!1,!T&&(P.handle!==null||Ei(P.input)||Ei(P.modeSelect)))return;const E=Kr(j,F),w=E||Kn(j,F),D=In(E||w);if(P.modeSelect.value=D,b(P,D),D==="fixed"){const $=E||w;$&&In($)==="fixed"&&(P.lastFixedValue=$)}if(D==="fixed"){const $=bt(w);P.input.value=$.value,P.input.placeholder="",P.container.setSuffix($.suffix)}}function k(){g("width"),g("height")}function v(F){const T=u[F],P=T.modeSelect,j=()=>{const E=o;if(!E||!E.isConnected)return;const w=P.value;if(In(Kr(E,F)||Kn(E,F))==="fixed"&&w!=="fixed"){const x=T.container.getSuffixText(),I=wt(T.input.value,x);I&&(T.lastFixedValue=I)}b(T,w);const $=f(F);if($)switch(w){case"fit":{const x=Kr(E,F)||Kn(E,F);$.set(ec(F,x));break}case"fill":$.set("100%");break;case"fixed":{const x=S(T,E);T.lastFixedValue=x,$.set(x);const I=bt(x);T.input.value=I.value,T.container.setSuffix(I.suffix);break}}};r.listen(P,"input",j),r.listen(P,"change",j),r.listen(P,"blur",()=>{m(F),k()}),r.listen(P,"keydown",E=>{E.key==="Enter"?(E.preventDefault(),m(F),k(),P.blur()):E.key==="Escape"&&(E.preventDefault(),h(F),g(F,!0))})}function L(F){const T=u[F],P=T.input;r.listen(P,"input",()=>{const j=f(F);if(!j)return;const E=T.container.getSuffixText(),w=wt(P.value,E);j.set(w)}),r.listen(P,"blur",()=>{m(F),k()}),r.listen(P,"keydown",j=>{j.key==="Enter"?(j.preventDefault(),m(F),k(),P.blur()):j.key==="Escape"&&(j.preventDefault(),h(F),g(F,!0))})}v("width"),v("height"),L("width"),L("height");function A(F){r.isDisposed||(F!==o&&(d(),u.width.lastFixedValue="",u.height.lastFixedValue=""),o=F,k())}function O(){r.isDisposed||k()}function V(){d(),o=null,r.dispose()}return k(),{setTarget:A,refresh:O,dispose:V}}const Si="http://www.w3.org/2000/svg",qn=["padding-top","padding-right","padding-bottom","padding-left","margin-top","margin-right","margin-bottom","margin-left"],rc={"padding-top":"M2 4h11M7.5 4v3.5","padding-right":"M4 2v11M4 7.5h3.5","padding-bottom":"M2 11h11M7.5 11v-3.5","padding-left":"M11 2v11M11 7.5h-3.5","margin-top":"M2 4h11M7.5 4v-3","margin-right":"M11 2v11M11 7.5h3","margin-bottom":"M2 11h11M7.5 11v3","margin-left":"M4 2v11M4 7.5h-3"};function oc(e){const[t,n]=e.split("-");return`${t.charAt(0).toUpperCase()}${t.slice(1)} ${n}`}function ic(e){try{const t=e.getRootNode();return t instanceof ShadowRoot?t.activeElement===e:document.activeElement===e}catch(t){return!1}}function sc(e,t){try{const n=e.style;return!n||typeof n.getPropertyValue!="function"?"":n.getPropertyValue(t).trim()}catch(n){return""}}function ac(e,t){try{return window.getComputedStyle(e).getPropertyValue(t).trim()}catch(n){return""}}function lc(e){const t=document.createElementNS(Si,"svg");t.setAttribute("viewBox","0 0 15 15"),t.setAttribute("fill","none"),t.setAttribute("aria-hidden","true"),t.setAttribute("focusable","false");const n=document.createElementNS(Si,"path");return n.setAttribute("d",e),n.setAttribute("stroke","currentColor"),t.append(n),t}function cc(e){const{container:t,transactionManager:n}=e,r=new Pe;let o=null;function i(v){const L=Xe({ariaLabel:oc(v),inputMode:"decimal",prefix:lc(rc[v]),suffix:"px"});return Ye(r,L.input,{mode:"css-length"}),{property:v,input:L.input,container:L,handle:null}}const s=Object.create(null);for(const v of qn)s[v]=i(v);function a(v,L){const A=document.createElement("div");A.className="we-spacing-section";const O=document.createElement("div");O.className="we-spacing-header",O.textContent=v,A.append(O);const V=document.createElement("div");return V.className="we-spacing-grid",V.append(s[L[0]].container.root),V.append(s[L[1]].container.root),V.append(s[L[2]].container.root),V.append(s[L[3]].container.root),A.append(V),A}const l=document.createElement("div");l.className="we-field-group",l.append(a("Padding",["padding-top","padding-right","padding-bottom","padding-left"]),a("Margin",["margin-top","margin-right","margin-bottom","margin-left"])),t.append(l),r.add(()=>l.remove());function c(v){if(r.isDisposed)return null;const L=o;if(!L||!L.isConnected)return null;const A=s[v];if(A.handle)return A.handle;const O=n.beginStyle(L,v);return A.handle=O,O}function u(v){const L=s[v],A=L.handle;L.handle=null,A&&A.commit({merge:!0})}function f(v){const L=s[v],A=L.handle;L.handle=null,A&&A.rollback()}function m(){for(const v of qn)u(v)}function h(v,L=!1){const A=s[v],O=o;if(!O||!O.isConnected){A.input.value="",A.input.placeholder="",A.input.disabled=!0,A.container.setSuffix("px");return}if(A.input.disabled=!1,(A.handle!==null||ic(A.input))&&!L)return;const T=sc(O,v)||ac(O,v),P=bt(T);A.input.value=P.value,A.input.placeholder="",A.container.setSuffix(P.suffix)}function d(){for(const v of qn)h(v)}function b(v){const L=s[v],A=L.input;r.listen(A,"input",()=>{const O=c(v);if(!O)return;const V=L.container.getSuffixText();O.set(wt(A.value,V))}),r.listen(A,"blur",()=>{u(v),d()}),r.listen(A,"keydown",O=>{O.key==="Enter"?(O.preventDefault(),u(v),d(),A.blur()):O.key==="Escape"&&(O.preventDefault(),f(v),h(v,!0))})}for(const v of qn)b(v);function S(v){r.isDisposed||(v!==o&&m(),o=v,d())}function g(){r.isDisposed||d()}function k(){m(),o=null,r.dispose()}return d(),{setTarget:S,refresh:g,dispose:k}}function uc(e){try{return e.cloneNode(!0)}catch(t){return e}}function qr(e,t){if(t===null)return-1;for(let n=0;n<e.length;n++)if(e[n].value===t)return n;return-1}function Zr(e){for(let t=0;t<e.length;t++)if(!e[t].disabled)return t;return-1}function dc(e){for(let t=e.length-1;t>=0;t--)if(!e[t].disabled)return t;return-1}function Ut(e){var v,L,A,O;const{container:t,ariaLabel:n,items:r,onChange:o}=e,i=new Pe;let s=!!e.disabled,a=null;const l=document.createElement("div");l.className="we-icon-button-group",l.setAttribute("role","radiogroup"),l.setAttribute("aria-label",n);const c=Math.max(1,(v=e.columns)!=null?v:r.length);l.style.gridTemplateColumns=`repeat(${c}, 1fr)`,t.append(l),i.add(()=>l.remove());const u=[];function f(){l.setAttribute("aria-disabled",String(s));for(let V=0;V<u.length;V++){const F=u[V],T=r[V];F.disabled=s||!!T.disabled}}function m(){const V=qr(r,a),F=V>=0&&!u[V].disabled?V:Zr(u);for(let T=0;T<u.length;T++){const P=u[T],j=r[T],E=a!==null&&j.value===a;P.setAttribute("aria-checked",E?"true":"false"),P.dataset.selected=E?"true":"false",P.tabIndex=T===F?0:-1}}function h(V,F){const T=qr(r,V);V!==null&&T<0&&(V=null);const P=V!==a;a=V,m(),F&&P&&a!==null&&(o==null||o(a))}function d(){const V=l.getRootNode(),F=V instanceof ShadowRoot?V.activeElement:document.activeElement,T=u.findIndex(E=>E===F);if(T>=0)return T;const P=qr(r,a);if(P>=0)return P;const j=Zr(u);return j>=0?j:0}function b(V,F){if(F===0)return-1;for(let T=V;T>=0&&T<u.length;T+=F)if(!u[T].disabled)return T;return-1}function S(V,F){if(V<0||V>=r.length)return;const T=u[V];T.disabled||(h(r[V].value,F),T.focus())}function g(V){if(s||u.length===0)return;const F=d();let T=null;switch(V.key){case"ArrowLeft":T=b(F-1,-1);break;case"ArrowRight":T=b(F+1,1);break;case"ArrowUp":T=b(F-c,-c);break;case"ArrowDown":T=b(F+c,c);break;case"Home":T=Zr(u);break;case"End":T=dc(u);break;case"Enter":case" ":V.preventDefault(),S(F,!0);return;default:return}T!==null&&T>=0&&(V.preventDefault(),S(T,!0))}for(let V=0;V<r.length;V++){const F=r[V],T=document.createElement("button");T.type="button",T.className="we-icon-button-group__btn",T.setAttribute("role","radio"),T.setAttribute("aria-label",F.ariaLabel),F.title&&(T.dataset.tooltip=F.title),T.dataset.value=F.value,T.append(uc(F.icon)),i.listen(T,"click",P=>{P.preventDefault(),!(s||T.disabled)&&(h(F.value,!0),T.focus())}),i.listen(T,"keydown",g),u.push(T),l.append(T)}f();const k=(O=(A=e.value)!=null?A:(L=r[0])==null?void 0:L.value)!=null?O:null;return h(k,!1),{root:l,getValue(){return a},setValue(V){h(V,!1)},setDisabled(V){s=V,f(),m()},dispose(){i.dispose()}}}const st="http://www.w3.org/2000/svg",ki=["static","relative","absolute","fixed","sticky"];function Qr(){const e=document.createElementNS(st,"svg");return e.setAttribute("viewBox","0 0 15 15"),e.setAttribute("fill","none"),e.setAttribute("aria-hidden","true"),e.setAttribute("focusable","false"),e}function Jr(e){const t=document.createElementNS(st,"rect");t.setAttribute("x","2"),t.setAttribute("y","2"),t.setAttribute("width","11"),t.setAttribute("height","11"),t.setAttribute("rx","1.5"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1"),t.setAttribute("stroke-dasharray","2 1"),t.setAttribute("fill","none"),t.setAttribute("opacity","0.5"),e.prepend(t)}function fc(e){const t=[];if(!e||e==="none")return t;const n=e.trim();let r=0;for(;r<n.length;){for(;r<n.length&&/\s/.test(n[r]);)r++;if(r>=n.length)break;const o=r;for(;r<n.length&&/[\w-]/.test(n[r]);)r++;const i=n.slice(o,r);for(;r<n.length&&/\s/.test(n[r]);)r++;if(n[r]!=="("){r++;continue}const s=r+1;let a=1;for(r++;r<n.length&&a>0;)n[r]==="("?a++:n[r]===")"&&a--,r++;const l=r-1,c=n.slice(s,l).trim(),u=n.slice(o,r);t.push({original:u,name:i.toLowerCase(),args:c})}return t}function Ci(e){const t=fc(e);let n=-1,r=-1,o=-1;for(let i=0;i<t.length;i++)switch(t[i].name){case"rotate":n===-1&&(n=i);break;case"scalex":r===-1&&(r=i);break;case"scaley":o===-1&&(o=i);break}return{functions:t,rotateIndex:n,scaleXIndex:r,scaleYIndex:o}}function pc(e){return e.rotateIndex<0?"":e.functions[e.rotateIndex].args}function Ai(e){if(e.scaleXIndex<0)return 1;const t=parseFloat(e.functions[e.scaleXIndex].args);return isNaN(t)?1:t}function Ti(e){if(e.scaleYIndex<0)return 1;const t=parseFloat(e.functions[e.scaleYIndex].args);return isNaN(t)?1:t}function mc(e){return Ai(e)===-1}function hc(e){return Ti(e)===-1}function gc(e,t){const n=t.trim();e.rotateIndex>=0?n?e.functions[e.rotateIndex]={original:`rotate(${n})`,name:"rotate",args:n}:(e.functions.splice(e.rotateIndex,1),e.scaleXIndex>e.rotateIndex&&e.scaleXIndex--,e.scaleYIndex>e.rotateIndex&&e.scaleYIndex--,e.rotateIndex=-1):n&&(e.rotateIndex=e.functions.length,e.functions.push({original:`rotate(${n})`,name:"rotate",args:n}))}function bc(e){Ai(e)===-1?e.scaleXIndex>=0&&(e.functions.splice(e.scaleXIndex,1),e.rotateIndex>e.scaleXIndex&&e.rotateIndex--,e.scaleYIndex>e.scaleXIndex&&e.scaleYIndex--,e.scaleXIndex=-1):e.scaleXIndex>=0?e.functions[e.scaleXIndex]={original:"scaleX(-1)",name:"scalex",args:"-1"}:(e.scaleXIndex=e.functions.length,e.functions.push({original:"scaleX(-1)",name:"scalex",args:"-1"}))}function wc(e){Ti(e)===-1?e.scaleYIndex>=0&&(e.functions.splice(e.scaleYIndex,1),e.rotateIndex>e.scaleYIndex&&e.rotateIndex--,e.scaleXIndex>e.scaleYIndex&&e.scaleXIndex--,e.scaleYIndex=-1):e.scaleYIndex>=0?e.functions[e.scaleYIndex]={original:"scaleY(-1)",name:"scaley",args:"-1"}:(e.scaleYIndex=e.functions.length,e.functions.push({original:"scaleY(-1)",name:"scaley",args:"-1"}))}function eo(e){return e.functions.map(t=>t.original).join(" ").trim()}function xc(e){if(!e)return"";const t=e.match(/^(-?[\d.]+)/);return t?t[1]:""}function yc(e){if(!e)return"deg";const t=e.match(/[\d.]+(.*)$/);return t&&t[1]?t[1]:"deg"}function vc(e){const t=Qr(),n=(i,s,a,l,c=1)=>{const u=document.createElementNS(st,"rect");u.setAttribute("x",String(i)),u.setAttribute("y",String(s)),u.setAttribute("width",String(a)),u.setAttribute("height",String(l)),u.setAttribute("rx","0.5"),u.setAttribute("fill","currentColor"),c<1&&u.setAttribute("opacity",String(c)),t.append(u)},r=(i,s,a)=>{const l=document.createElementNS(st,"rect");l.setAttribute("x",String(i)),l.setAttribute("y",String(s)),l.setAttribute("width",String(a)),l.setAttribute("height","1"),l.setAttribute("rx","0.5"),l.setAttribute("fill","currentColor"),t.append(l)},o=(i,s="1")=>{const a=document.createElementNS(st,"path");a.setAttribute("d",i),a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width",s),a.setAttribute("stroke-linecap","round"),a.setAttribute("fill","none"),t.append(a)};switch(e){case"static":r(3.5,4.5,8),r(3.5,7.5,8),r(3.5,10.5,8);break;case"relative":{const i=document.createElementNS(st,"rect");i.setAttribute("x","3.5"),i.setAttribute("y","3.5"),i.setAttribute("width","4"),i.setAttribute("height","4"),i.setAttribute("rx","0.5"),i.setAttribute("stroke","currentColor"),i.setAttribute("stroke-width","1"),i.setAttribute("stroke-dasharray","1.5 1"),i.setAttribute("fill","none"),i.setAttribute("opacity","0.5"),t.append(i),n(7.5,7.5,4,4),o("M5.5 7.5L7.5 9.5");break}case"absolute":o("M3 5.5H6M8 3V6","0.8"),n(6,6,5,5);break;case"fixed":{const i=document.createElementNS(st,"circle");i.setAttribute("cx","7.5"),i.setAttribute("cy","4"),i.setAttribute("r","1.5"),i.setAttribute("fill","currentColor"),t.append(i),o("M7.5 5.5V8"),n(4.5,8,6,4);break}case"sticky":{const i=document.createElementNS(st,"rect");i.setAttribute("x","3"),i.setAttribute("y","3"),i.setAttribute("width","9"),i.setAttribute("height","1.5"),i.setAttribute("rx","0.5"),i.setAttribute("fill","currentColor"),i.setAttribute("opacity","0.4"),t.append(i),n(4.5,5,6,6);break}}return Jr(t),t}function Ec(){const e=document.createElementNS(st,"svg");e.setAttribute("viewBox","0 0 15 15"),e.setAttribute("fill","none"),e.setAttribute("aria-hidden","true"),e.setAttribute("focusable","false");const t=document.createElementNS(st,"path");return t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1.2"),t.setAttribute("stroke-linecap","round"),t.setAttribute("stroke-linejoin","round"),t.setAttribute("d","M12 7.5a4.5 4.5 0 1 1-1.5-3.4M12 3v3h-3"),e.append(t),e}function Sc(){const e=Qr(),t=document.createElementNS(st,"rect");t.setAttribute("x","3.5"),t.setAttribute("y","5"),t.setAttribute("width","3"),t.setAttribute("height","5"),t.setAttribute("rx","0.5"),t.setAttribute("fill","currentColor"),t.setAttribute("opacity","0.4");const n=document.createElementNS(st,"rect");n.setAttribute("x","8.5"),n.setAttribute("y","5"),n.setAttribute("width","3"),n.setAttribute("height","5"),n.setAttribute("rx","0.5"),n.setAttribute("fill","currentColor");const r=document.createElementNS(st,"path");return r.setAttribute("d","M7.5 3V12"),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1"),r.setAttribute("stroke-dasharray","1.5 1"),r.setAttribute("opacity","0.6"),e.append(t,n,r),Jr(e),e}function kc(){const e=Qr(),t=document.createElementNS(st,"rect");t.setAttribute("x","5"),t.setAttribute("y","3.5"),t.setAttribute("width","5"),t.setAttribute("height","3"),t.setAttribute("rx","0.5"),t.setAttribute("fill","currentColor"),t.setAttribute("opacity","0.4");const n=document.createElementNS(st,"rect");n.setAttribute("x","5"),n.setAttribute("y","8.5"),n.setAttribute("width","5"),n.setAttribute("height","3"),n.setAttribute("rx","0.5"),n.setAttribute("fill","currentColor");const r=document.createElementNS(st,"path");return r.setAttribute("d","M3 7.5H12"),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1"),r.setAttribute("stroke-dasharray","1.5 1"),r.setAttribute("opacity","0.6"),e.append(t,n,r),Jr(e),e}function Ni(e){try{const t=e.getRootNode();return t instanceof ShadowRoot?t.activeElement===e:document.activeElement===e}catch(t){return!1}}function Zn(e,t){try{const n=e.style;return!n||typeof n.getPropertyValue!="function"?"":n.getPropertyValue(t).trim()}catch(n){return""}}function Qn(e,t){try{return window.getComputedStyle(e).getPropertyValue(t).trim()}catch(n){return""}}function Cc(e){const t=e.trim();return t?/^-?\d+\.$/.test(t)?t.slice(0,-1):t:""}function Ac(e){return ki.includes(e)}function Tc(e){const{container:t,transactionManager:n}=e,r=new Pe;let o=null;const i=document.createElement("div");i.className="we-field-group";const s=document.createElement("div");s.className="we-field";const a=document.createElement("span");a.className="we-field-label",a.textContent="Position";const l=document.createElement("div");l.className="we-field-content",s.append(a,l);const c=Ut({container:l,ariaLabel:"Position type",columns:5,items:ki.map(p=>({value:p,ariaLabel:p,title:p,icon:vc(p)})),onChange:p=>{const y=T("position");y&&y.set(p),P("position"),I()}});r.add(()=>c.dispose());const u=document.createElement("div");u.className="we-field-row";const f=Xe({ariaLabel:"X (Left)",inputMode:"decimal",prefix:"X",suffix:"px"}),m=Xe({ariaLabel:"Y (Top)",inputMode:"decimal",prefix:"Y",suffix:"px"});u.append(f.root,m.root),Ye(r,f.input,{mode:"css-length"}),Ye(r,m.input,{mode:"css-length"});const h=document.createElement("div");h.className="we-field";const d=document.createElement("span");d.className="we-field-label",d.textContent="Z-Index";const b=Xe({ariaLabel:"Z-Index",inputMode:"numeric",prefix:"Z",suffix:null});h.append(d,b.root),Ye(r,b.input,{mode:"number",integer:!0});const S=document.createElement("div");S.className="we-field";const g=document.createElement("span");g.className="we-field-label",g.textContent="Rotate";const k=document.createElement("div");k.className="we-field-content",k.style.display="flex",k.style.gap="4px",k.style.alignItems="center";const v=Xe({ariaLabel:"Rotate",inputMode:"decimal",prefix:Ec(),suffix:"deg"});v.root.style.flex="1",Ye(r,v.input,{mode:"number",step:1,shiftStep:15});const L=document.createElement("button");L.type="button",L.className="we-toggle-btn",L.setAttribute("aria-label","Flip horizontal"),L.setAttribute("aria-pressed","false"),L.dataset.tooltip="Flip horizontal",L.append(Sc());const A=document.createElement("button");A.type="button",A.className="we-toggle-btn",A.setAttribute("aria-label","Flip vertical"),A.setAttribute("aria-pressed","false"),A.dataset.tooltip="Flip vertical",A.append(kc()),k.append(v.root,L,A),S.append(g,k),i.append(s,u,h,S),t.append(i),r.add(()=>i.remove());const O={position:{kind:"icon-button-group",property:"position",group:c,handle:null},left:{kind:"input",property:"left",input:f.input,container:f,handle:null},top:{kind:"input",property:"top",input:m.input,container:m,handle:null},"z-index":{kind:"input",property:"z-index",input:b.input,container:b,handle:null},transform:{kind:"transform",rotateInput:v.input,rotateContainer:v,flipXBtn:L,flipYBtn:A,handle:null,cached:{functions:[],rotateIndex:-1,scaleXIndex:-1,scaleYIndex:-1}}},V=["position","left","top","z-index"],F=["position","left","top","z-index","transform"];function T(p){if(r.isDisposed)return null;const y=o;if(!y||!y.isConnected)return null;const R=O[p];if(R.kind==="transform")return null;if(R.handle)return R.handle;const B=n.beginStyle(y,p);return R.handle=B,B}function P(p){const y=O[p];if(y.kind==="transform")return;const R=y.handle;y.handle=null,R&&R.commit({merge:!0})}function j(p){const y=O[p];if(y.kind==="transform")return;const R=y.handle;y.handle=null,R&&R.rollback()}function E(){if(r.isDisposed)return null;const p=o;if(!p||!p.isConnected)return null;const y=O.transform;if(y.handle)return y.handle;const R=n.beginStyle(p,"transform");y.handle=R;const B=Zn(p,"transform")||Qn(p,"transform");return y.cached=Ci(B),R}function w(){const p=O.transform,y=p.handle;p.handle=null,y&&y.commit({merge:!0})}function D(){const p=O.transform,y=p.handle;p.handle=null,y&&y.rollback()}function $(){for(const p of V)P(p);w()}function x(p,y=!1){const R=O[p],B=o;if(R.kind==="icon-button-group"){const Y=R.group;if(!B||!B.isConnected){Y.setDisabled(!0),Y.setValue(null);return}if(Y.setDisabled(!1),R.handle!==null&&!y)return;const te=Zn(B,"position"),se=Qn(B,"position"),pe=(te||se).trim();Y.setValue(Ac(pe)?pe:"static");return}if(R.kind==="input"){const Y=R.input;if(!B||!B.isConnected){Y.disabled=!0,Y.value="",Y.placeholder="",R.property==="z-index"?R.container.setSuffix(null):R.container.setSuffix("px");return}if(Y.disabled=!1,(R.handle!==null||Ni(Y))&&!y)return;const se=Zn(B,R.property)||Qn(B,R.property);if(R.property==="z-index")Y.value=se,R.container.setSuffix(null);else{const pe=bt(se);Y.value=pe.value,R.container.setSuffix(pe.suffix)}Y.placeholder="";return}if(R.kind==="transform"){const{rotateInput:Y,rotateContainer:Q,flipXBtn:te,flipYBtn:se}=R;if(!B||!B.isConnected){Y.disabled=!0,Y.value="",Y.placeholder="",Q.setSuffix("deg"),te.disabled=!0,se.disabled=!0,te.setAttribute("aria-pressed","false"),se.setAttribute("aria-pressed","false");return}if(Y.disabled=!1,te.disabled=!1,se.disabled=!1,(R.handle!==null||Ni(Y))&&!y)return;const xe=Zn(B,"transform")||Qn(B,"transform"),we=Ci(xe),H=pc(we),ae=xc(H),ne=yc(H);Y.value=ae,Q.setSuffix(ne||"deg"),te.setAttribute("aria-pressed",mc(we)?"true":"false"),se.setAttribute("aria-pressed",hc(we)?"true":"false")}}function I(){for(const p of F)x(p)}function N(p){const y=O[p],R=y.input;r.listen(R,"input",()=>{const B=T(p);if(B)if(p==="z-index")B.set(Cc(R.value));else{const Y=y.container.getSuffixText();B.set(wt(R.value,Y))}}),r.listen(R,"blur",()=>{P(p),I()}),r.listen(R,"keydown",B=>{B.key==="Enter"?(B.preventDefault(),P(p),I(),R.blur()):B.key==="Escape"&&(B.preventDefault(),j(p),x(p,!0))})}N("left"),N("top"),N("z-index");const _=O.transform;r.listen(_.rotateInput,"input",()=>{const p=E();if(!p)return;const y=_.rotateInput.value.trim(),R=_.rotateContainer.getSuffixText()||"deg",B=y?`${y}${R}`:"";gc(_.cached,B),p.set(eo(_.cached))}),r.listen(_.rotateInput,"blur",()=>{w(),I()}),r.listen(_.rotateInput,"keydown",p=>{p.key==="Enter"?(p.preventDefault(),w(),I(),_.rotateInput.blur()):p.key==="Escape"&&(p.preventDefault(),D(),x("transform",!0))}),r.listen(_.flipXBtn,"click",p=>{p.preventDefault();const y=E();y&&(bc(_.cached),y.set(eo(_.cached)),w(),I())}),r.listen(_.flipYBtn,"click",p=>{p.preventDefault();const y=E();y&&(wc(_.cached),y.set(eo(_.cached)),w(),I())});function M(p){r.isDisposed||(p!==o&&$(),o=p,I())}function W(){r.isDisposed||I()}function C(){$(),o=null,r.dispose()}return I(),{setTarget:M,refresh:W,dispose:C}}const at="http://www.w3.org/2000/svg",_i=["block","inline","inline-block","flex","grid","none"],Ri=["row","column","row-reverse","column-reverse"],Nc=["nowrap","wrap","wrap-reverse"],to=["flex-start","center","flex-end"],et=12;function Jn(e){try{const t=e.getRootNode();return t instanceof ShadowRoot?t.activeElement===e:document.activeElement===e}catch(t){return!1}}function Ft(e,t){var n,r,o;try{const i=e.style;return(o=(r=(n=i==null?void 0:i.getPropertyValue)==null?void 0:n.call(i,t))==null?void 0:r.trim())!=null?o:""}catch(i){return""}}function Bt(e,t){try{return window.getComputedStyle(e).getPropertyValue(t).trim()}catch(n){return""}}function _c(e){return _i.includes(e)}function Rc(e){return Ri.includes(e)}function Ii(e){return to.includes(e)}function Li(e){const t=e.trim();return t==="inline-flex"?"flex":t==="inline-grid"?"grid":t}function dt(e,t,n){return Number.isFinite(e)?Math.min(n,Math.max(t,Math.trunc(e))):t}function Ic(e){const t=[];let n=0,r="";for(let i=0;i<e.length;i++){const s=e[i];if(s==="("&&n++,s===")"&&n>0&&n--,n===0&&/\s/.test(s)){const a=r.trim();a&&t.push(a),r="";continue}r+=s}const o=r.trim();return o&&t.push(o),t}function Lc(e){const t=e.match(/^repeat\(\s*(\d+)\s*,/i);if(!t)return null;const n=parseInt(t[1],10);return Number.isFinite(n)&&n>0?n:null}function Mi(e){var o;const t=e.trim();if(!t||t==="none")return null;const n=Ic(t);let r=0;for(const i of n)/^\[.*\]$/.test(i)||(r+=(o=Lc(i))!=null?o:1);return r>0?r:null}function Di(e){const t=dt(e,1,et);return t===1?"1fr":`repeat(${t}, 1fr)`}function bn(){const e=document.createElementNS(at,"svg");return e.setAttribute("viewBox","0 0 15 15"),e.setAttribute("fill","none"),e.setAttribute("aria-hidden","true"),e.setAttribute("focusable","false"),e}function Ln(e,t="1.2"){e.setAttribute("stroke","currentColor"),e.setAttribute("stroke-width",t),e.setAttribute("stroke-linecap","round"),e.setAttribute("stroke-linejoin","round")}function Mc(e){const t=bn(),n=document.createElementNS(at,"rect");n.setAttribute("x","2"),n.setAttribute("y","2"),n.setAttribute("width","11"),n.setAttribute("height","11"),n.setAttribute("rx","1.5"),n.setAttribute("stroke","currentColor"),n.setAttribute("stroke-width","1"),n.setAttribute("stroke-dasharray","2 1"),n.setAttribute("fill","none"),n.setAttribute("opacity","0.5");const r=(i,s,a,l)=>{const c=document.createElementNS(at,"rect");c.setAttribute("x",String(i)),c.setAttribute("y",String(s)),c.setAttribute("width",String(a)),c.setAttribute("height",String(l)),c.setAttribute("rx","0.5"),c.setAttribute("fill","currentColor"),t.append(c)},o=(i,s,a)=>{const l=document.createElementNS(at,"rect");l.setAttribute("x",String(i)),l.setAttribute("y",String(s)),l.setAttribute("width",String(a)),l.setAttribute("height","1"),l.setAttribute("rx","0.5"),l.setAttribute("fill","currentColor"),t.append(l)};switch(e){case"block":r(3.5,3.5,8,3),r(3.5,8.5,8,3);break;case"inline":o(3.5,4.5,8),o(3.5,7.5,5),o(3.5,10.5,6.5);break;case"inline-block":r(3.5,4.5,3.5,6),o(8,5.5,4),o(8,8.5,3);break;case"flex":r(3.5,4.5,2.5,6),r(6.5,4.5,2.5,6),r(9.5,4.5,2.5,6);break;case"grid":r(3.5,3.5,3.5,3.5),r(8,3.5,3.5,3.5),r(3.5,8,3.5,3.5),r(8,8,3.5,3.5);break;case"none":{const i=document.createElementNS(at,"path");i.setAttribute("d","M4 11L11 4"),i.setAttribute("stroke","currentColor"),i.setAttribute("stroke-width","1.5"),i.setAttribute("stroke-linecap","round"),t.append(i);break}}return t.prepend(n),t}function Dc(e){const t=bn(),n=document.createElementNS(at,"path");Ln(n,"1.5");const r={row:"M2 7.5H13M10 4.5L13 7.5L10 10.5","row-reverse":"M13 7.5H2M5 4.5L2 7.5L5 10.5",column:"M7.5 2V13M4.5 10L7.5 13L10.5 10","column-reverse":"M7.5 13V2M4.5 5L7.5 2L10.5 5"};return n.setAttribute("d",r[e]),t.append(n),t}function Pc(e){const t=bn(),n=document.createElementNS(at,"rect");n.setAttribute("x","2"),n.setAttribute("y","2"),n.setAttribute("width","11"),n.setAttribute("height","11"),n.setAttribute("rx","1.5"),n.setAttribute("stroke","currentColor"),n.setAttribute("stroke-width","1"),n.setAttribute("stroke-dasharray","2 1"),n.setAttribute("fill","none"),n.setAttribute("opacity","0.5");const r={"flex-start":3.5,center:5.5,"flex-end":7.5},o=document.createElementNS(at,"rect");o.setAttribute("x",String(r[e])),o.setAttribute("y","4"),o.setAttribute("width","4"),o.setAttribute("height","3"),o.setAttribute("rx","0.5"),o.setAttribute("fill","currentColor");const i=document.createElementNS(at,"rect");return i.setAttribute("x",String(r[e])),i.setAttribute("y","8"),i.setAttribute("width","4"),i.setAttribute("height","3"),i.setAttribute("rx","0.5"),i.setAttribute("fill","currentColor"),t.append(n,o,i),t}function Oc(e){const t=bn(),n=document.createElementNS(at,"rect");n.setAttribute("x","2"),n.setAttribute("y","2"),n.setAttribute("width","11"),n.setAttribute("height","11"),n.setAttribute("rx","1.5"),n.setAttribute("stroke","currentColor"),n.setAttribute("stroke-width","1"),n.setAttribute("stroke-dasharray","2 1"),n.setAttribute("fill","none"),n.setAttribute("opacity","0.5");const r={"flex-start":3.5,center:5.5,"flex-end":7.5},o=document.createElementNS(at,"rect");o.setAttribute("x","4"),o.setAttribute("y",String(r[e])),o.setAttribute("width","3"),o.setAttribute("height","4"),o.setAttribute("rx","0.5"),o.setAttribute("fill","currentColor");const i=document.createElementNS(at,"rect");return i.setAttribute("x","8"),i.setAttribute("y",String(r[e])),i.setAttribute("width","3"),i.setAttribute("height","4"),i.setAttribute("rx","0.5"),i.setAttribute("fill","currentColor"),t.append(n,o,i),t}function Pi(){const e=bn(),t=document.createElementNS(at,"rect");t.setAttribute("x","3"),t.setAttribute("y","4"),t.setAttribute("width","3.5"),t.setAttribute("height","7"),t.setAttribute("rx","1"),Ln(t);const n=document.createElementNS(at,"rect");return n.setAttribute("x","8.5"),n.setAttribute("y","4"),n.setAttribute("width","3.5"),n.setAttribute("height","7"),n.setAttribute("rx","1"),Ln(n),e.append(t,n),e}function Oi(){const e=bn(),t=document.createElementNS(at,"rect");t.setAttribute("x","4"),t.setAttribute("y","3"),t.setAttribute("width","7"),t.setAttribute("height","3.5"),t.setAttribute("rx","1"),Ln(t);const n=document.createElementNS(at,"rect");return n.setAttribute("x","4"),n.setAttribute("y","8.5"),n.setAttribute("width","7"),n.setAttribute("height","3.5"),n.setAttribute("rx","1"),Ln(n),e.append(t,n),e}function Fc(e){const{container:t,transactionManager:n}=e,r=new Pe;let o=null;const i=document.createElement("div");i.className="we-field-group";const s=document.createElement("div");s.className="we-field";const a=document.createElement("span");a.className="we-field-label",a.textContent="Display";const l=document.createElement("div");l.className="we-field-content",s.append(a,l);const c=Ut({container:l,ariaLabel:"Display",columns:6,items:_i.map(ee=>({value:ee,ariaLabel:ee,title:ee,icon:Mc(ee)})),onChange:ee=>{const ce=me("display");ce&&ce.set(ee),z("display"),de()}});r.add(()=>c.dispose());const u=document.createElement("div");u.className="we-field";const f=document.createElement("span");f.className="we-field-label",f.textContent="Flow";const m=document.createElement("div");m.className="we-field-content",u.append(f,m);const h=Ut({container:m,ariaLabel:"Flex direction",columns:4,items:Ri.map(ee=>({value:ee,ariaLabel:ee.replace("-"," "),title:ee.replace("-"," "),icon:Dc(ee)})),onChange:ee=>{const ce=me("flex-direction");ce&&ce.set(ee),z("flex-direction"),de()}});r.add(()=>h.dispose()),h.setValue(null);const d=document.createElement("div");d.className="we-field";const b=document.createElement("span");b.className="we-field-label",b.textContent="Wrap";const S=document.createElement("select");S.className="we-select",S.setAttribute("aria-label","flex-wrap");for(const ee of Nc){const ce=document.createElement("option");ce.value=ee,ce.textContent=ee,S.append(ce)}d.append(b,S);const g=document.createElement("div");g.className="we-field";const k=document.createElement("span");k.className="we-field-label",k.textContent="Align";const v=document.createElement("div");v.className="we-field-content",v.style.display="flex",v.style.gap="4px",g.append(k,v);const L=document.createElement("div");L.style.flex="1",L.style.minWidth="0",L.style.display="flex",L.style.flexDirection="column",L.style.gap="2px";const A=document.createElement("span");A.className="we-field-hint",A.textContent="H";const O=document.createElement("div");L.append(A,O);const V=document.createElement("div");V.style.flex="1",V.style.minWidth="0",V.style.display="flex",V.style.flexDirection="column",V.style.gap="2px";const F=document.createElement("span");F.className="we-field-hint",F.textContent="V";const T=document.createElement("div");V.append(F,T),v.append(L,V);const P=Ut({container:O,ariaLabel:"Justify content",columns:3,items:to.map(ee=>({value:ee,ariaLabel:`justify-content: ${ee}`,title:ee,icon:Pc(ee)})),onChange:ee=>{var Se;const ce=le();if(!ce)return;const ue=(Se=j.getValue())!=null?Se:"center";ce.set({"justify-content":ee,"align-items":ue}),be(),de()}}),j=Ut({container:T,ariaLabel:"Align items",columns:3,items:to.map(ee=>({value:ee,ariaLabel:`align-items: ${ee}`,title:ee,icon:Oc(ee)})),onChange:ee=>{var Se;const ce=le();if(!ce)return;const ue=(Se=P.getValue())!=null?Se:"center";ce.set({"justify-content":ue,"align-items":ee}),be(),de()}});r.add(()=>P.dispose()),r.add(()=>j.dispose()),P.setValue(null),j.setValue(null);const E=document.createElement("div");E.className="we-field";const w=document.createElement("span");w.className="we-field-label",w.textContent="Grid";const D=document.createElement("div");D.className="we-field-content",D.style.position="relative",E.append(w,D);const $=document.createElement("button");$.type="button",$.className="we-grid-dimensions-preview",$.setAttribute("aria-label","Grid dimensions"),$.setAttribute("aria-expanded","false"),$.setAttribute("aria-haspopup","dialog");const x=document.createElement("span");x.textContent="1";const I=document.createElement("span");I.textContent=" × ";const N=document.createElement("span");N.textContent="1",$.append(x,I,N);const _=document.createElement("div");_.className="we-grid-dimensions-popover",_.hidden=!0;const M=document.createElement("div");M.className="we-grid-dimensions-inputs";const W=Xe({ariaLabel:"Grid columns",inputMode:"numeric",prefix:Pi(),suffix:null});W.root.style.width="72px",W.root.style.flex="0 0 auto";const C=document.createElement("span");C.className="we-grid-dimensions-times",C.textContent="×";const p=Xe({ariaLabel:"Grid rows",inputMode:"numeric",prefix:Oi(),suffix:null});p.root.style.width="72px",p.root.style.flex="0 0 auto",M.append(W.root,C,p.root);const y=document.createElement("div");y.className="we-grid-dimensions-matrix",y.setAttribute("role","grid");const R=[];for(let ee=1;ee<=et;ee++)for(let ce=1;ce<=et;ce++){const ue=document.createElement("button");ue.type="button",ue.className="we-grid-dimensions-cell",ue.dataset.row=String(ee),ue.dataset.col=String(ce),ue.setAttribute("role","gridcell"),ue.setAttribute("aria-label",`${ce} × ${ee}`),R.push(ue),y.append(ue)}const B=document.createElement("div");B.className="we-grid-dimensions-tooltip",B.hidden=!0,_.append(M,y,B),D.append($,_),Ye(r,W.input,{mode:"number",integer:!0,min:1,max:et}),Ye(r,p.input,{mode:"number",integer:!0,min:1,max:et});const Y=document.createElement("div");Y.className="we-field";const Q=document.createElement("span");Q.className="we-field-label",Q.textContent="Gap";const te=document.createElement("div");te.className="we-field-content";const se=document.createElement("div");se.className="we-grid-gap-inputs";const pe=Xe({ariaLabel:"Row gap",inputMode:"decimal",prefix:Oi(),suffix:"px"}),xe=Xe({ariaLabel:"Column gap",inputMode:"decimal",prefix:Pi(),suffix:"px"});se.append(pe.root,xe.root),te.append(se),Y.append(Q,te),Ye(r,pe.input,{mode:"css-length"}),Ye(r,xe.input,{mode:"css-length"});const we=document.createElement("div");we.className="we-grid-gap-row",we.hidden=!0,E.classList.add("we-grid-gap-col","we-grid-gap-col--grid"),Y.classList.add("we-grid-gap-col","we-grid-gap-col--gap"),we.append(E,Y),i.append(s,u,d,g,we),t.append(i),r.add(()=>i.remove());const H={display:{kind:"display-group",property:"display",group:c,handle:null,row:s},"flex-direction":{kind:"flex-direction-group",property:"flex-direction",group:h,handle:null,row:u},"flex-wrap":{kind:"select",property:"flex-wrap",element:S,handle:null,row:d},alignment:{kind:"flex-alignment",properties:["justify-content","align-items"],justifyGroup:P,alignGroup:j,handle:null,row:g},"grid-dimensions":{kind:"grid-dimensions",properties:["grid-template-columns","grid-template-rows"],previewButton:$,previewColsValue:x,previewRowsValue:N,popover:_,colsContainer:W,rowsContainer:p,matrix:y,tooltip:B,cells:R,handle:null,row:E},"row-gap":{kind:"input",property:"row-gap",element:pe.input,container:pe,handle:null,row:Y},"column-gap":{kind:"input",property:"column-gap",element:xe.input,container:xe,handle:null,row:Y}},ae=["display","flex-direction","flex-wrap","row-gap","column-gap"],ne=["display","flex-direction","flex-wrap","alignment","grid-dimensions","row-gap","column-gap"];function me(ee){if(r.isDisposed)return null;const ce=o;if(!ce||!ce.isConnected)return null;const ue=H[ee];if(ue.kind==="flex-alignment"||ue.kind==="grid-dimensions")return null;if(ue.handle)return ue.handle;const Se=n.beginStyle(ce,ee);return ue.handle=Se,Se}function z(ee){const ce=H[ee];if(ce.kind==="flex-alignment"||ce.kind==="grid-dimensions")return;const ue=ce.handle;ce.handle=null,ue&&ue.commit({merge:!0})}function J(ee){const ce=H[ee];if(ce.kind==="flex-alignment"||ce.kind==="grid-dimensions")return;const ue=ce.handle;ce.handle=null,ue&&ue.rollback()}function le(){if(r.isDisposed)return null;const ee=o;if(!ee||!ee.isConnected)return null;const ce=H.alignment;if(ce.kind!=="flex-alignment")return null;if(ce.handle)return ce.handle;const ue=n.beginMultiStyle(ee,[...ce.properties]);return ce.handle=ue,ue}function be(){const ee=H.alignment;if(ee.kind!=="flex-alignment")return;const ce=ee.handle;ee.handle=null,ce==null||ce.commit({merge:!0})}function Te(){if(r.isDisposed)return null;const ee=o;if(!ee||!ee.isConnected)return null;const ce=H["grid-dimensions"];if(ce.kind!=="grid-dimensions")return null;if(ce.handle)return ce.handle;const ue=n.beginMultiStyle(ee,[...ce.properties]);return ce.handle=ue,ue}function Ne(){const ee=H["grid-dimensions"];if(ee.kind!=="grid-dimensions")return;const ce=ee.handle;ee.handle=null,ce==null||ce.commit({merge:!0})}function Z(){const ee=H["grid-dimensions"];if(ee.kind!=="grid-dimensions")return;const ce=ee.handle;ee.handle=null,ce==null||ce.rollback()}function G(){for(const ee of ae)z(ee);be(),Ne()}function K(){var nt;const ee=o,ce=ee?Ft(ee,"display")||Bt(ee,"display"):(nt=c.getValue())!=null?nt:"block",Se=Li(ce).trim(),De=Se==="flex"||Se==="inline-flex",Fe=Se==="grid"||Se==="inline-grid",Oe=De||Fe;u.hidden=!De,d.hidden=!De,g.hidden=!De,we.hidden=!Oe,E.hidden=!Fe,Y.hidden=!Oe}function q(ee,ce=!1){var De,Fe,Oe,nt,ft,pt;const ue=H[ee],Se=o;if(ue.kind==="display-group"){const Le=ue.group;if(!Se||!Se.isConnected){Le.setDisabled(!0),Le.setValue(null);return}if(Le.setDisabled(!1),ue.handle!==null&&!ce)return;const ut=Ft(Se,"display"),it=Bt(Se,"display");let X=(ut||it).trim();X=Li(X),Le.setValue(_c(X)?X:"block");return}if(ue.kind==="flex-direction-group"){const Le=ue.group;if(!Se||!Se.isConnected){Le.setDisabled(!0),Le.setValue(null);return}if(Le.setDisabled(!1),ue.handle!==null&&!ce)return;const ut=Ft(Se,"flex-direction"),it=Bt(Se,"flex-direction"),X=(ut||it).trim();Le.setValue(Rc(X)?X:null);return}if(ue.kind==="flex-alignment"){if(!Se||!Se.isConnected){ue.justifyGroup.setDisabled(!0),ue.alignGroup.setDisabled(!0),ue.justifyGroup.setValue(null),ue.alignGroup.setValue(null);return}if(ue.justifyGroup.setDisabled(!1),ue.alignGroup.setDisabled(!1),ue.handle!==null&&!ce)return;const At=Ft(Se,"justify-content"),ut=Bt(Se,"justify-content"),it=Ft(Se,"align-items"),X=Bt(Se,"align-items"),re=(At||ut).trim(),fe=(it||X).trim();Ii(re)&&Ii(fe)?(ue.justifyGroup.setValue(re),ue.alignGroup.setValue(fe)):(ue.justifyGroup.setValue(null),ue.alignGroup.setValue(null));return}if(ue.kind==="grid-dimensions"){const{previewButton:Le,popover:At,colsContainer:ut,rowsContainer:it,tooltip:X,cells:re}=ue;if(!Se||!Se.isConnected){Le.disabled=!0,ue.previewColsValue.textContent="—",ue.previewRowsValue.textContent="—",Le.setAttribute("aria-expanded","false"),At.hidden=!0,ut.input.disabled=!0,it.input.disabled=!0,X.hidden=!0;for(const Ae of re)Ae.dataset.active="false",Ae.dataset.selected="false";return}if(Le.disabled=!1,ut.input.disabled=!1,it.input.disabled=!1,(ue.handle!==null||Jn(ut.input)||Jn(it.input))&&!ce)return;const Ee=Ft(Se,"grid-template-columns")||Bt(Se,"grid-template-columns"),Ce=Ft(Se,"grid-template-rows")||Bt(Se,"grid-template-rows"),Ie=dt((De=Mi(Ee))!=null?De:1,1,et),Ve=dt((Fe=Mi(Ce))!=null?Fe:1,1,et);ut.input.value=String(Ie),it.input.value=String(Ve),ue.previewColsValue.textContent=String(Ie),ue.previewRowsValue.textContent=String(Ve),Le.setAttribute("aria-label",`Grid: ${Ie} columns, ${Ve} rows`),X.hidden=!0;for(const Ae of re){const Me=parseInt((Oe=Ae.dataset.col)!=null?Oe:"0",10),Ue=parseInt((nt=Ae.dataset.row)!=null?nt:"0",10),Be=Me>0&&Ue>0&&Me<=Ie&&Ue<=Ve;Ae.dataset.selected=Be?"true":"false",Ae.dataset.active=Be?"true":"false"}return}if(ue.kind==="input"){const Le=ue.element;if(!Se||!Se.isConnected){Le.disabled=!0,Le.value="",Le.placeholder="",ue.container.setSuffix("px");return}if(Le.disabled=!1,(ue.handle!==null||Jn(Le))&&!ce)return;const it=Ft(Se,ue.property)||Bt(Se,ue.property),X=bt(it);Le.value=X.value,ue.container.setSuffix(X.suffix),Le.placeholder="";return}if(ue.kind==="select"){const Le=ue.element;if(!Se||!Se.isConnected){Le.disabled=!0;return}if(Le.disabled=!1,(ue.handle!==null||Jn(Le))&&!ce)return;const ut=Ft(Se,ue.property),it=Bt(Se,ue.property),X=ut||it,re=Array.from(Le.options).some(fe=>fe.value===X);Le.value=re?X:(pt=(ft=Le.options[0])==null?void 0:ft.value)!=null?pt:""}}function de(){for(const ee of ne)q(ee);K()}function oe(ee){const ce=H[ee];if(ce.kind!=="select")return;const ue=ce.element,Se=()=>{const De=me(ee);De&&De.set(ue.value)};r.listen(ue,"input",Se),r.listen(ue,"change",Se),r.listen(ue,"blur",()=>{z(ee),de()}),r.listen(ue,"keydown",De=>{De.key==="Enter"?(De.preventDefault(),z(ee),de(),ue.blur()):De.key==="Escape"&&(De.preventDefault(),J(ee),q(ee,!0))})}function he(ee){const ce=H[ee];if(ce.kind!=="input")return;const ue=ce.element;r.listen(ue,"input",()=>{const Se=me(ee);if(!Se)return;const De=ce.container.getSuffixText();Se.set(wt(ue.value,De))}),r.listen(ue,"blur",()=>{z(ee),de()}),r.listen(ue,"keydown",Se=>{Se.key==="Enter"?(Se.preventDefault(),z(ee),de(),ue.blur()):Se.key==="Escape"&&(Se.preventDefault(),J(ee),q(ee,!0))})}oe("flex-wrap"),he("row-gap"),he("column-gap");let U=null,ie=null;function ve(ee,ce,ue){var Fe,Oe;const Se=U!=null?U:ce,De=ie!=null?ie:ue;for(const nt of ee.cells){const ft=parseInt((Fe=nt.dataset.col)!=null?Fe:"0",10),pt=parseInt((Oe=nt.dataset.row)!=null?Oe:"0",10),Le=ft>0&&pt>0&&ft<=ce&&pt<=ue,At=ft>0&&pt>0&&ft<=Se&&pt<=De;nt.dataset.selected=Le?"true":"false",nt.dataset.active=At?"true":"false"}U!==null&&ie!==null?(ee.tooltip.textContent=`${U} × ${ie}`,ee.tooltip.hidden=!1):ee.tooltip.hidden=!0}function ge(ee,ce){ee.popover.hidden=!ce,ee.previewButton.setAttribute("aria-expanded",ce?"true":"false"),U=null,ie=null;const ue=dt(parseInt(ee.colsContainer.input.value||"1",10)||1,1,et),Se=dt(parseInt(ee.rowsContainer.input.value||"1",10)||1,1,et);ve(ee,ue,Se)}function ye(ee,ce){const ue=Te();ue&&ue.set({"grid-template-columns":Di(ee),"grid-template-rows":Di(ce)})}const ke=H["grid-dimensions"];if(ke.kind==="grid-dimensions"){r.listen(ke.previewButton,"click",De=>{De.preventDefault(),ge(ke,ke.popover.hidden),ke.popover.hidden||(ke.colsContainer.input.focus(),ke.colsContainer.input.select())});const ee=ke.previewButton.getRootNode(),ce=ee instanceof ShadowRoot?ee:document,ue=De=>{if(ke.kind!=="grid-dimensions"||ke.popover.hidden)return;const Fe=De.target;E.contains(Fe)||ge(ke,!1)};ce.addEventListener("click",ue,!0),r.add(()=>{ce.removeEventListener("click",ue,!0)});const Se=De=>{r.listen(De,"input",()=>{const Fe=dt(parseInt(ke.colsContainer.input.value||"1",10)||1,1,et),Oe=dt(parseInt(ke.rowsContainer.input.value||"1",10)||1,1,et);ve(ke,Fe,Oe),ye(Fe,Oe)}),r.listen(De,"blur",()=>{Ne(),de()}),r.listen(De,"keydown",Fe=>{if(Fe.key==="Enter"){Fe.preventDefault(),Ne(),de();return}Fe.key==="Escape"&&(Fe.preventDefault(),Z(),ge(ke,!1),q("grid-dimensions",!0))})};Se(ke.colsContainer.input),Se(ke.rowsContainer.input),r.listen(ke.matrix,"mouseover",De=>{var pt,Le;const Oe=De.target.closest(".we-grid-dimensions-cell");if(!Oe)return;U=dt(parseInt((pt=Oe.dataset.col)!=null?pt:"1",10)||1,1,et),ie=dt(parseInt((Le=Oe.dataset.row)!=null?Le:"1",10)||1,1,et);const nt=dt(parseInt(ke.colsContainer.input.value||"1",10)||1,1,et),ft=dt(parseInt(ke.rowsContainer.input.value||"1",10)||1,1,et);ve(ke,nt,ft)}),r.listen(ke.matrix,"mouseleave",()=>{U=null,ie=null;const De=dt(parseInt(ke.colsContainer.input.value||"1",10)||1,1,et),Fe=dt(parseInt(ke.rowsContainer.input.value||"1",10)||1,1,et);ve(ke,De,Fe)}),r.listen(ke.matrix,"click",De=>{var pt,Le;const Oe=De.target.closest(".we-grid-dimensions-cell");if(!Oe)return;const nt=dt(parseInt((pt=Oe.dataset.col)!=null?pt:"1",10)||1,1,et),ft=dt(parseInt((Le=Oe.dataset.row)!=null?Le:"1",10)||1,1,et);ke.colsContainer.input.value=String(nt),ke.rowsContainer.input.value=String(ft),ye(nt,ft),Ne(),ge(ke,!1),de()})}function We(ee){r.isDisposed||(ee!==o&&G(),o=ee,de())}function Re(){r.isDisposed||de()}function gt(){G(),o=null,r.dispose()}return de(),{setTarget:We,refresh:Re,dispose:gt}}const Bc=8,Vc=100;function $c(e){const{container:t,tokensService:n,onSelect:r,maxVisible:o=Bc}=e,i=new Pe;let s=null,a=[],l=[],c=!1,u="",f=null,m=-1;const h=document.createElement("div");h.className="we-token-picker",h.hidden=!0;const d=document.createElement("input");d.type="text",d.className="we-token-filter",d.placeholder="Filter tokens...",d.autocomplete="off",d.spellcheck=!1;const b=document.createElement("div");b.className="we-token-toggle-row";const S=document.createElement("label");S.className="we-token-toggle-label";const g=document.createElement("input");g.type="checkbox",g.className="we-token-toggle-checkbox";const k=document.createElement("span");k.textContent="Show all root tokens",S.append(g,k),b.append(S);const v=document.createElement("div");v.className="we-token-list",v.style.maxHeight=`${o*36}px`;const L=document.createElement("div");L.className="we-token-empty",L.textContent="No tokens found",L.hidden=!0,h.append(d,b,v,L),t.append(h),i.add(()=>h.remove());function A(){if(!s||!s.isConnected){a=[],l=[];return}if(c){const _=s.getRootNode();a=n.getRootTokens(_).tokens.map(W=>{const C=n.resolveToken(s,W.name);return{token:W,computedValue:C.computedValue}})}else a=[...n.getContextTokens(s).tokens];O()}function O(){const _=u.toLowerCase().trim();_?l=a.filter(M=>{const W=M.token.name.toLowerCase(),C=M.computedValue.toLowerCase();return W.includes(_)||C.includes(_)}):l=a,m=l.length>0?0:-1,V()}function V(){if(v.innerHTML="",l.length===0){L.hidden=!1,v.hidden=!0;return}L.hidden=!0,v.hidden=!1;for(let _=0;_<l.length;_++){const M=l[_],W=F(M,_);v.append(W)}T()}function F(_,M){const W=document.createElement("button");W.type="button",W.className="we-token-item",W.dataset.index=String(M),W.dataset.name=_.token.name;const C=document.createElement("span");C.className="we-token-name",C.textContent=_.token.name;const p=document.createElement("span");p.className="we-token-value",p.textContent=_.computedValue||"(unset)";const y=_.computedValue.toLowerCase();if((y.startsWith("#")||y.startsWith("rgb")||y.startsWith("hsl")||/^[a-z]+$/.test(y))&&_.computedValue){const B=document.createElement("span");B.className="we-token-swatch",B.style.backgroundColor=_.computedValue,W.append(B)}return W.append(C,p),W}function T(){const _=v.querySelectorAll(".we-token-item");_.forEach((M,W)=>{M.classList.toggle("we-token-item--selected",W===m)}),m>=0&&m<_.length&&_[m].scrollIntoView({block:"nearest"})}function P(_){if(_<0||_>=l.length)return;const M=l[_],W=n.formatCssVar(M.token.name);D(),r(M.token.name,W)}function j(){m>=0&&P(m)}i.listen(d,"input",()=>{u=d.value,f&&clearTimeout(f),f=setTimeout(()=>{f=null,O()},Vc)}),i.listen(d,"keydown",_=>{switch(_.key){case"ArrowDown":_.preventDefault(),l.length>0&&(m=Math.min(m+1,l.length-1),T());break;case"ArrowUp":_.preventDefault(),l.length>0&&(m=Math.max(m-1,0),T());break;case"Enter":_.preventDefault(),j();break;case"Escape":_.preventDefault(),D();break}}),i.listen(g,"change",()=>{c=g.checked,A()}),i.listen(v,"click",_=>{var p;const W=_.target.closest(".we-token-item");if(!W)return;const C=parseInt((p=W.dataset.index)!=null?p:"-1",10);C>=0&&P(C)}),i.listen(h,"mousedown",_=>{_.preventDefault()});function E(_){i.isDisposed||(s=_&&_.isConnected?_:null,u="",d.value="",!h.hidden&&A())}function w(){i.isDisposed||h.hidden&&(h.hidden=!1,A(),d.focus())}function D(){i.isDisposed||(h.hidden=!0,u="",d.value="",m=-1)}function $(){return h.hidden?(w(),!0):(D(),!1)}function x(){return!h.hidden}function I(){i.isDisposed||h.hidden||A()}function N(){f&&(clearTimeout(f),f=null),s=null,a=[],l=[],i.dispose()}return{setTarget:E,show:w,hide:D,toggle:$,isVisible:x,refresh:I,dispose:N}}const Fi="http://www.w3.org/2000/svg",Hc="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m0-5.656a4 4 0 015.656 0l4 4a4 4 0 11-5.656 5.656l-1.1-1.102";function zc(e){const{container:t,ariaLabel:n,tokenName:r,previewColor:o=null,leadingElement:i=null,disabled:s=!1,onClick:a,onClear:l}=e,c=new Pe;let u=!!s,f=String(r),m=typeof o=="string"?o:null,h=i!=null?i:null;const d=document.createElement("div");d.className="we-token-pill",d.dataset.disabled=u?"true":"false",d.setAttribute("role","group"),d.setAttribute("aria-label",n);const b=document.createElement("div");b.className="we-token-pill__leading";const S=document.createElement("div");S.className="we-token-pill__swatch",S.setAttribute("aria-hidden","true");const g=document.createElement("button");g.type="button",g.className="we-token-pill__main",g.setAttribute("aria-label",n),g.dataset.tooltip="Change token";const k=document.createElement("span");k.className="we-token-pill__name";const v=document.createElementNS(Fi,"svg");v.setAttribute("viewBox","0 0 24 24"),v.setAttribute("fill","none"),v.setAttribute("aria-hidden","true"),v.classList.add("we-token-pill__icon");const L=document.createElementNS(Fi,"path");L.setAttribute("d",Hc),L.setAttribute("stroke","currentColor"),L.setAttribute("stroke-width","2"),L.setAttribute("stroke-linecap","round"),L.setAttribute("stroke-linejoin","round"),v.append(L),g.append(k,v);const A=document.createElement("button");A.type="button",A.className="we-token-pill__clear",A.setAttribute("aria-label","Clear token"),A.dataset.tooltip="Clear token",A.textContent="×",d.append(b,g,A),t.append(d),c.add(()=>d.remove());function O(){for(;b.firstChild;)b.removeChild(b.firstChild);h?b.append(h):(S.style.backgroundColor=m!=null?m:"",b.append(S))}function V(){k.textContent=f}function F(){d.dataset.disabled=u?"true":"false",g.disabled=u,A.disabled=u,h instanceof HTMLButtonElement&&(h.disabled=u)}return c.listen(g,"click",T=>{T.preventDefault(),!u&&(a==null||a())}),c.listen(A,"click",T=>{T.preventDefault(),T.stopPropagation(),!u&&(l==null||l())}),c.listen(d,"keydown",T=>{if(!u&&(T.key==="Backspace"||T.key==="Delete")){const P=T.composedPath();(P.includes(g)||P.includes(d))&&(T.preventDefault(),l==null||l())}}),O(),V(),F(),{root:d,setTokenName(T){f=String(T!=null?T:""),V()},setPreviewColor(T){m=typeof T=="string"?T:null,h||(S.style.backgroundColor=m!=null?m:"")},setLeadingElement(T){h=T!=null?T:null,O(),F()},setDisabled(T){u=!!T,F()},focus(){try{g.focus()}catch(T){}},dispose(){c.dispose()}}}const Bi="#000000",Uc=`
  <svg class="we-token-btn-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M12 3a9 9 0 100 18h1a2 2 0 002-2v-1a2 2 0 012-2h1a3 3 0 003-3 10 10 0 00-9-10z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="7.5" cy="10.5" r="1" fill="currentColor"/>
    <circle cx="10.5" cy="7.5" r="1" fill="currentColor"/>
    <circle cx="13.5" cy="10.5" r="1" fill="currentColor"/>
  </svg>
`;function Gc(e){return Number.isFinite(e)?Math.max(0,Math.min(255,Math.round(e))):0}function no(e){return Gc(e).toString(16).padStart(2,"0")}function Wc(e){const t=e.match(/rgba?\(\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*([0-9.]+)/i);if(!t)return null;const n=Number(t[1]),r=Number(t[2]),o=Number(t[3]);return!Number.isFinite(n)||!Number.isFinite(r)||!Number.isFinite(o)?null:`#${no(n)}${no(r)}${no(o)}`}function Xc(e){const t=e.trim().toLowerCase();if(!t.startsWith("#"))return null;if(/^#[0-9a-f]{6}$/.test(t))return t;if(/^#[0-9a-f]{3}$/.test(t)){const n=t[1],r=t[2],o=t[3];return`#${n}${n}${r}${r}${o}${o}`}if(/^#[0-9a-f]{8}$/.test(t))return t.slice(0,7);if(/^#[0-9a-f]{4}$/.test(t)){const n=t[1],r=t[2],o=t[3];return`#${n}${n}${r}${r}${o}${o}`}return null}function Yc(e){try{const t=e.getRootNode();if(t instanceof ShadowRoot)return t.activeElement}catch(t){}return document.activeElement}function Mn(e){const{container:t,ariaLabel:n,onInput:r,onCommit:o,onCancel:i,tokensService:s,getTokenTarget:a,tokenPickerMaxVisible:l}=e,c=new Pe;let u="",f="",m=Bi,h=!1,d=!1,b=null,S=null,g=null;const k=document.createElement("div");k.className="we-color-field",k.style.position="relative";const v=document.createElement("button");v.type="button",v.className="we-color-swatch",v.dataset.tooltip="Pick color",v.setAttribute("aria-label",`Pick ${n}`);const L=document.createElement("input");L.type="color",L.className="we-color-native-input",L.value=m,L.tabIndex=-1;const A=document.createElement("input");A.type="text",A.className="we-input we-color-text",A.autocomplete="off",A.spellcheck=!1,A.setAttribute("aria-label",n);const O=document.createElement("span");O.style.cssText="position:fixed;left:-9999px;top:0;width:1px;height:1px;pointer-events:none;opacity:0",O.setAttribute("aria-hidden","true"),v.append(L),s&&(S=document.createElement("button"),S.type="button",S.className="we-token-btn",S.setAttribute("aria-label","Select design token"),S.dataset.tooltip="Select design token",S.innerHTML=Uc),k.append(v,A),S&&k.append(S),k.append(O),t.append(k),c.add(()=>k.remove()),s&&(b=zc({container:k,ariaLabel:`${n} token`,tokenName:"",disabled:!1,onClick:()=>D(),onClear:()=>x()}),b.root.hidden=!0,c.add(()=>b==null?void 0:b.dispose())),s&&(g=$c({container:k,tokensService:s,maxVisible:l,onSelect:$}),c.add(()=>g==null?void 0:g.dispose()),c.listen(document,"click",I=>{if(!(g!=null&&g.isVisible()))return;const N=I.target;k.contains(N)||g.hide()}));function V(){const I=u.trim(),N=f.trim();return I&&/\bvar\s*\(/i.test(I)&&N?N:I||N}function F(I){const N=I.trim();if(!N)return{swatch:null,hex:null};const _=Xc(N);if(_)return{swatch:_,hex:_};try{if(O.style.backgroundColor="",O.style.backgroundColor=N,!O.style.backgroundColor)return{swatch:null,hex:null};const M=getComputedStyle(O).backgroundColor,W=Wc(M);return{swatch:M||null,hex:W}}catch(M){return{swatch:null,hex:null}}}function T(){const I=V(),N=F(I);N.swatch?v.style.backgroundColor=N.swatch:v.style.backgroundColor="",N.hex&&(m=N.hex,L.value=N.hex)}function P(){if(L.disabled)return;const I=V(),N=F(I);N.hex&&(m=N.hex),L.value=m;const _=L.showPicker;if(typeof _=="function")try{_.call(L);return}catch(M){}try{L.click()}catch(M){}}function j(){if(!s)return null;const I=s.parseCssVar(u.trim());return I?I.name:null}function E(I,N){var _;if(!(!s||!b)){if(I===h){I&&N&&b.setTokenName(N);return}if(h=I,I){const M=(_=N!=null?N:j())!=null?_:"";b.setTokenName(M),b.setLeadingElement(v),b.root.hidden=!1,A.hidden=!0,S&&(S.hidden=!0)}else b.root.hidden=!0,b.setLeadingElement(null),A.hidden=!1,S&&(S.hidden=!1),(v.parentElement!==k||v.nextSibling!==A)&&k.insertBefore(v,A)}}function w(){if(!s||!b)return;const I=j();E(!!I,I!=null?I:void 0)}function D(){var I;!g||!s||d||(g.setTarget((I=a==null?void 0:a())!=null?I:null),g.toggle())}function $(I,N){f="",A.placeholder="",u=N,A.value=u,T(),r==null||r(u.trim()),o==null||o(),E(!0,I)}function x(){if(!s||!b||d)return;g==null||g.hide();const I=m||Bi;f="",A.placeholder="",u=I,A.value=u,T(),r==null||r(u),o==null||o(),E(!1)}return c.listen(v,"keydown",I=>{(I.key==="Enter"||I.key===" ")&&(I.preventDefault(),P())}),c.listen(A,"input",()=>{u=A.value,T(),r==null||r(u.trim())}),c.listen(A,"blur",()=>{o==null||o(),w()}),c.listen(A,"keydown",I=>{I.key==="Enter"?(I.preventDefault(),o==null||o(),A.blur()):I.key==="Escape"&&(I.preventDefault(),i==null||i())}),c.listen(L,"input",()=>{u=L.value,A.value=u,T(),r==null||r(u)}),c.listen(L,"change",()=>{o==null||o(),w()}),S&&c.listen(S,"click",I=>{I.preventDefault(),I.stopPropagation(),D()}),T(),w(),{setValue(I){u=String(I!=null?I:""),A.value=u,T(),w()},setPlaceholder(I){f=String(I!=null?I:""),A.placeholder=f,T()},setDisabled(I){d=!!I,v.disabled=d,A.disabled=d,L.disabled=d,S&&(S.disabled=d),b==null||b.setDisabled(d),d&&(g==null||g.hide())},isFocused(){const I=Yc(k);return I instanceof HTMLElement?k.contains(I):!1},dispose(){c.dispose()}}}const Vi=[{value:"none",label:"None"},{value:"linear",label:"Linear"},{value:"radial",label:"Radial"}],jc=[{value:"ellipse",label:"Ellipse"},{value:"circle",label:"Circle"}],er=180,Qt=50,Nt={color:"#000000",position:0},ro={color:"#ffffff",position:100};let $i=0;function Dn(){try{if(typeof crypto!="undefined"&&typeof crypto.randomUUID=="function")return crypto.randomUUID()}catch(e){}return $i+=1,`stop_${$i}_${Date.now()}`}function wn(){return[{id:Dn(),color:Nt.color,position:Nt.position},{id:Dn(),color:ro.color,position:ro.position}]}function Kc(e){return e.map(t=>({id:Dn(),color:t.color,position:t.position,placeholderColor:t.placeholderColor}))}function qc(e,t){return e.length===t.length?t.map((n,r)=>{var o,i;return{id:(i=(o=e[r])==null?void 0:o.id)!=null?i:Dn(),color:n.color,position:n.position,placeholderColor:n.placeholderColor}}):Kc(t)}function Hi(e){var t;if(Pn(e.color)){const n=(t=e.placeholderColor)==null?void 0:t.trim();return n||"transparent"}return e.color}function xn(e){return Number.isFinite(e)?Math.max(0,Math.min(255,Math.round(e))):0}function oo(e){return xn(e).toString(16).padStart(2,"0")}function tr(e){const t=Jt(e.a,0,1);if(t>=1)return`#${oo(e.r)}${oo(e.g)}${oo(e.b)}`;const n=Math.round(t*1e3)/1e3;return`rgba(${xn(e.r)}, ${xn(e.g)}, ${xn(e.b)}, ${n})`}function Zc(e){const t=e.trim().toLowerCase();if(!t.startsWith("#"))return null;if(/^#[0-9a-f]{3}$/.test(t)){const n=Number.parseInt(t[1]+t[1],16),r=Number.parseInt(t[2]+t[2],16),o=Number.parseInt(t[3]+t[3],16);return{r:n,g:r,b:o,a:1}}if(/^#[0-9a-f]{4}$/.test(t)){const n=Number.parseInt(t[1]+t[1],16),r=Number.parseInt(t[2]+t[2],16),o=Number.parseInt(t[3]+t[3],16),i=Number.parseInt(t[4]+t[4],16)/255;return{r:n,g:r,b:o,a:i}}if(/^#[0-9a-f]{6}$/.test(t)){const n=Number.parseInt(t.slice(1,3),16),r=Number.parseInt(t.slice(3,5),16),o=Number.parseInt(t.slice(5,7),16);return{r:n,g:r,b:o,a:1}}if(/^#[0-9a-f]{8}$/.test(t)){const n=Number.parseInt(t.slice(1,3),16),r=Number.parseInt(t.slice(3,5),16),o=Number.parseInt(t.slice(5,7),16),i=Number.parseInt(t.slice(7,9),16)/255;return{r:n,g:r,b:o,a:i}}return null}function io(e){const t=e.trim();if(!t)return null;if(t.endsWith("%")){const r=Number(t.slice(0,-1));return Number.isFinite(r)?xn(r/100*255):null}const n=Number(t);return Number.isFinite(n)?xn(n):null}function Qc(e){const t=e.trim();if(!t)return null;if(t.endsWith("%")){const r=Number(t.slice(0,-1));return Number.isFinite(r)?Jt(r/100,0,1):null}const n=Number(t);return Number.isFinite(n)?Jt(n,0,1):null}function zi(e){const t=e.trim();if(!/^rgba?\(/i.test(t))return null;const n=t.indexOf("("),r=t.lastIndexOf(")");if(n<0||r<n)return null;const o=t.slice(n+1,r).trim();if(!o)return null;let i=o,s=null;const a=o.indexOf("/");a!==-1&&(i=o.slice(0,a).trim(),s=o.slice(a+1).trim());const l=i.includes(",")?i.split(",").map(h=>h.trim()).filter(Boolean):i.split(/\s+/).map(h=>h.trim()).filter(Boolean);if(l.length<3)return null;const c=io(l[0]),u=io(l[1]),f=io(l[2]);if(c===null||u===null||f===null)return null;let m=1;if(!s&&l.length>=4&&(s=l[3]),s){const h=Qc(s);h!==null&&(m=h)}return{r:c,g:u,b:f,a:m}}function nr(e,t,n){return e+(t-e)*n}function Jc(e,t,n){const r=Jt(n,0,1);return{r:nr(e.r,t.r,r),g:nr(e.g,t.g,r),b:nr(e.b,t.b,r),a:nr(e.a,t.a,r)}}function yn(e){try{const t=e.getRootNode();return t instanceof ShadowRoot?t.activeElement===e:document.activeElement===e}catch(t){return!1}}function eu(e,t){var n,r,o;try{const i=e.style;return(o=(r=(n=i==null?void 0:i.getPropertyValue)==null?void 0:n.call(i,t))==null?void 0:r.trim())!=null?o:""}catch(i){return""}}function tu(e,t){try{return window.getComputedStyle(e).getPropertyValue(t).trim()}catch(n){return""}}function rr(e){const t=e.trim();return!t||t.toLowerCase()==="none"}function Jt(e,t,n){return Number.isFinite(e)?Math.max(t,Math.min(n,e)):t}function or(e){const t=e.trim();if(!t)return null;const n=Number(t);return Number.isFinite(n)?n:null}function nu(e){const t=e.trim();if(!t)return null;const n=t.match(/^(-?(?:\d+\.?\d*|\.\d+))\s*deg$/i);if(!n)return null;const r=Number(n[1]);return Number.isFinite(r)?r:null}function so(e){const t=e.trim();if(!t)return null;const n=t.match(/^(-?(?:\d+\.?\d*|\.\d+))\s*%$/);if(!n)return null;const r=Number(n[1]);return Number.isFinite(r)?r:null}function ao(e){const t=e.trim().toLowerCase();if(!t)return null;const n=so(t);return n!==null?n:t==="center"?50:t==="left"?0:t==="right"?100:null}function lo(e){const t=e.trim().toLowerCase();if(!t)return null;const n=so(t);return n!==null?n:t==="center"?50:t==="top"?0:t==="bottom"?100:null}function ru(e){const t=e.trim().toLowerCase();return t==="left"||t==="right"}function ou(e){const t=e.trim().toLowerCase();return t==="top"||t==="bottom"}function Ui(e){return Jt(e,0,360)}function tt(e){return Jt(e,0,100)}function Gi(e,t){const n=[];let r=0,o=null,i=!1,s=0;for(let a=0;a<e.length;a++){const l=e[a];if(i){i=!1;continue}if(l==="\\"){i=!0;continue}if(o){l===o&&(o=null);continue}if(l==='"'||l==="'"){o=l;continue}if(l==="("){r++;continue}if(l===")"){r=Math.max(0,r-1);continue}r===0&&l===t&&(n.push(e.slice(s,a)),s=a+1)}return n.push(e.slice(s)),n}function Wi(e){const t=[];let n=0,r=null,o=!1,i="";const s=()=>{const a=i.trim();a&&t.push(a),i=""};for(let a=0;a<e.length;a++){const l=e[a];if(o){i+=l,o=!1;continue}if(l==="\\"){i+=l,o=!0;continue}if(r){i+=l,l===r&&(r=null);continue}if(l==='"'||l==="'"){i+=l,r=l;continue}if(l==="("){n++,i+=l;continue}if(l===")"){n=Math.max(0,n-1),i+=l;continue}if(n===0&&/\s/.test(l)){s();continue}i+=l}return s(),t}function Xi(e){var i,s;const t=e.trim();if(!t)return null;const n=Wi(t);if(n.length===0)return null;const r=(i=n[0])!=null?i:"";if(!r)return null;let o=null;for(let a=1;a<n.length;a++){const l=so((s=n[a])!=null?s:"");if(l!==null){o=l;break}}return{color:r,position:o}}function Yi(e){var s,a,l,c;if(e.length===0)return[];if(e.length===1)return[{color:e[0].color.trim()||Nt.color,position:tt((s=e[0].position)!=null?s:0)}];const t=e.map(u=>u.color.trim()||Nt.color),n=e.map(u=>u.position===null?null:tt(u.position));n[0]===null&&(n[0]=0);const r=n.length-1;n[r]===null&&(n[r]=100);let o=(a=n[0])!=null?a:0;for(let u=1;u<n.length;u++){const f=n[u];f!==null&&(f<o?n[u]=o:o=f)}let i=null;for(let u=0;u<n.length;u++)if(n[u]===null)i===null&&(i=u);else if(i!==null){const f=(l=n[i-1])!=null?l:0,m=(c=n[u])!=null?c:100,h=u-i+1;for(let d=i;d<u;d++){const b=(d-i+1)/h;n[d]=f+(m-f)*b}i=null}return e.map((u,f)=>{var m;return{color:t[f],position:tt((m=n[f])!=null?m:0)}})}function iu(e){const t=e.trim(),n=t.toLowerCase();let r=null,o="";if(n.startsWith("linear-gradient"))r="linear",o="linear-gradient";else if(n.startsWith("radial-gradient"))r="radial",o="radial-gradient";else return null;let i=o.length;for(;i<t.length&&/\s/.test(t[i]);)i++;if(t[i]!=="(")return null;const s=i;let a=0,l=null,c=!1;for(let u=s;u<t.length;u++){const f=t[u];if(c){c=!1;continue}if(f==="\\"){c=!0;continue}if(l){f===l&&(l=null);continue}if(f==='"'||f==="'"){l=f;continue}if(f==="("){a++;continue}if(f===")"&&(a--,a===0)){if(t.slice(u+1).trim())return null;const h=t.slice(s+1,u);return{kind:r,args:h}}}return null}function su(e){var c;const t=Gi(e,",").map(u=>u.trim()).filter(Boolean);if(t.length<2)return null;const n=(c=t[0])!=null?c:"";if(n.toLowerCase().startsWith("to "))return null;const o=nu(n);let i=er,s=0;if(o!==null){if(t.length<3)return null;i=o,s=1}const a=t.slice(s),l=[];for(const u of a){const f=Xi(u);if(!f)return null;l.push(f)}return l.length<2?null:{type:"linear",angle:Ui(i),stops:Yi(l)}}const au=new Set(["closest-side","farthest-side","closest-corner","farthest-corner"]);function lu(e){var b,S,g;const t=Gi(e,",").map(k=>k.trim()).filter(Boolean);if(t.length<2)return null;let n="ellipse",r=null,o=0;const i=(b=t[0])!=null?b:"",s=Wi(i),a=s.map(k=>k.toLowerCase());for(const k of a)if(au.has(k))return null;const l=a.indexOf("at"),c=l>=0,u=a.includes("circle"),f=a.includes("ellipse");if((u||f||c)&&(o=1,u?n="circle":f&&(n="ellipse"),c)){const k=(S=s[l+1])!=null?S:"",v=(g=s[l+2])!=null?g:"";let L=null,A=null;ou(k)?(A=lo(k),L=v?ao(v):null):(ru(k),L=ao(k),A=v?lo(v):null),r={x:tt(L!=null?L:Qt),y:tt(A!=null?A:Qt)}}const h=t.slice(o),d=[];for(const k of h){const v=Xi(k);if(!v)return null;d.push(v)}return d.length<2?null:{type:"radial",shape:n,position:r,stops:Yi(d)}}function ji(e){const t=iu(e);return t?t.kind==="linear"?su(t.args):lu(t.args):null}function Pn(e){return/\bvar\s*\(/i.test(e)}function cu(e,t){return e.length===0||t.length===0?[]:e.map(n=>{let r=t[0],o=Math.abs(r.position-n.position);for(let i=1;i<t.length;i++){const s=t[i],a=Math.abs(s.position-n.position);a<o&&(r=s,o=a)}return r.color})}function co(e){var ut,it;const{container:t,transactionManager:n,tokensService:r,property:o="background-image",allowNone:i=!0}=e,s=new Pe;let a=null,l=i?"none":"linear",c=wn(),u=(it=(ut=c[0])==null?void 0:ut.id)!=null?it:null,f=null,m=null,h=null;const d=document.createElement("div");d.className="we-field-group";function b(X,re){const fe=document.createElement("div");fe.className="we-field";const Ee=document.createElement("span");Ee.className="we-field-label",Ee.textContent=X;const Ce=document.createElement("input");return Ce.type="text",Ce.className="we-input",Ce.autocomplete="off",Ce.spellcheck=!1,Ce.inputMode="decimal",Ce.setAttribute("aria-label",re),fe.append(Ee,Ce),{row:fe,input:Ce}}function S(X,re,fe){const Ee=document.createElement("div");Ee.className="we-field";const Ce=document.createElement("span");Ce.className="we-field-label",Ce.textContent=X;const Ie=document.createElement("select");Ie.className="we-select",Ie.setAttribute("aria-label",re);for(const Ve of fe){const Ae=document.createElement("option");Ae.value=Ve.value,Ae.textContent=Ve.label,Ie.append(Ae)}return Ee.append(Ce,Ie),{row:Ee,select:Ie}}const g=i?Vi:Vi.filter(X=>X.value!=="none"),{row:k,select:v}=S("Type","Gradient Type",g),L=document.createElement("div");L.className="we-gradient-bar-row";const A=document.createElement("div");A.className="we-gradient-bar",A.setAttribute("aria-label","Gradient preview");const O=document.createElement("div");O.className="we-gradient-bar-thumbs",A.append(O),L.append(A);const{row:V,input:F}=b("Angle","Gradient Angle (deg)");F.placeholder=String(er);const{row:T,select:P}=S("Shape","Radial Gradient Shape",jc),{row:j,input:E}=b("Position X","Radial Position X (%)"),{row:w,input:D}=b("Position Y","Radial Position Y (%)"),$=document.createElement("div");$.className="we-gradient-stops-header";const x=document.createElement("span");x.className="we-gradient-stops-title",x.textContent="Stops";const I=document.createElement("button");I.type="button",I.className="we-icon-btn we-gradient-stops-add",I.setAttribute("aria-label","Add stop"),I.disabled=!1,I.textContent="+",$.append(x,I);const N=document.createElement("div");N.className="we-gradient-stops-list",N.setAttribute("role","list"),d.append(k,L,V,T,j,w,$,N),t.append(d),s.add(()=>d.remove()),Ye(s,F,{mode:"number",min:0,max:360,step:1,shiftStep:15,altStep:.1}),Ye(s,E,{mode:"number",min:0,max:100,step:1,shiftStep:10,altStep:.1}),Ye(s,D,{mode:"number",min:0,max:100,step:1,shiftStep:10,altStep:.1});const _=document.createElement("div"),M=document.createElement("input");M.type="text",M.className="we-gradient-stop-pos-input",M.autocomplete="off",M.spellcheck=!1,M.inputMode="decimal",M.placeholder="0",M.setAttribute("aria-label","Selected Stop Position (%)"),_.append(M),Ye(s,M,{mode:"number",min:0,max:100,step:1,shiftStep:10});function W(){le(),h&&(Fe(),B()),Oe()}function C(){Y(),Oe(!0)}s.listen(M,"input",()=>{const X=u;if(!X)return;const re=or(M.value);re!==null&&(Q(X,re),Fe())}),s.listen(M,"blur",W),s.listen(M,"keydown",X=>{X.key==="Enter"?(X.preventDefault(),W(),M.blur()):X.key==="Escape"&&(X.preventDefault(),C())});const p=document.createElement("div"),y=Mn({container:p,ariaLabel:"Selected Stop Color",tokensService:r,getTokenTarget:()=>a,onInput:X=>{var Ee;const re=u;if(!re)return;const fe=c.findIndex(Ce=>Ce.id===re);fe<0||(c[fe].color=X,y.setPlaceholder(Pn(X)&&(Ee=c[fe].placeholderColor)!=null?Ee:""),Fe())},onCommit:()=>{B(),Oe()},onCancel:()=>{Y(),Oe(!0)}});s.add(()=>y.dispose());function R(){if(s.isDisposed)return null;const X=a;return!X||!X.isConnected?null:h||(h=n.beginStyle(X,o),h)}function B(){const X=h;h=null,X&&X.commit({merge:!0})}function Y(){const X=h;h=null,X&&X.rollback()}function Q(X,re){const fe=c.findIndex(Ce=>Ce.id===X);if(fe<0)return;const Ee=tt(re);c[fe].position=Ee}function te(X){for(const re of c){const fe=X.get(re.id);fe!==void 0&&(re.position=fe)}}function se(X){const re=f;if(re){f=null,A.classList.remove("we-gradient-bar--dragging"),re.thumbElement.classList.remove("we-gradient-thumb--dragging");try{re.thumbElement.releasePointerCapture(re.pointerId)}catch(fe){}X?(le(),Fe(),B(),Oe()):(te(re.initialPositions),Y(),Oe(!0))}}function pe(X){const re=A.getBoundingClientRect();if(re.width<=0)return 0;const Ee=(X-re.left)/re.width*100;return tt(Ee)}function xe(X,re){if(f||l==="none"||v.disabled||(m==null?void 0:m.stopId)===X)return;m&&we(!0);const fe=new Map;for(const Ee of c)fe.set(Ee.id,Ee.position);m={stopId:X,initialPositions:fe,thumbElement:re},R()}function we(X){const re=m;re&&(m=null,X?(le(),Fe(),B(),Oe()):(te(re.initialPositions),Y(),Oe(!0)))}function H(X){if(f||l==="none"||v.disabled)return;const fe=X.currentTarget.dataset.stopId;fe&&u!==fe&&(u=fe,q({preserveThumbs:!0}))}function ae(X){const re=m;!re||X.currentTarget!==re.thumbElement||we(!0)}function ne(X){if(X.metaKey||X.ctrlKey||f||l==="none"||v.disabled)return;const re=X.currentTarget,fe=re.dataset.stopId;if(!fe)return;if(X.key==="Escape"){const Me=m;if(!Me||Me.stopId!==fe)return;X.preventDefault(),X.stopPropagation(),we(!1);return}if(!(X.key==="ArrowLeft"||X.key==="ArrowRight"||X.key==="ArrowUp"||X.key==="ArrowDown"))return;X.preventDefault(),X.stopPropagation();const Ce=X.key==="ArrowLeft"||X.key==="ArrowDown"?-1:1,Ie=X.shiftKey?10:1,Ve=Ce*Ie;u=fe,xe(fe,re);const Ae=c.findIndex(Me=>Me.id===fe);Ae<0||(Q(fe,c[Ae].position+Ve),Fe())}function me(X,re){const fe=tt(re),Ee=Math.round(fe*100)/100,Ce=Object.is(Ee,-0)?0:Ee;X.setAttribute("role","slider"),X.setAttribute("aria-label","Gradient stop position"),X.setAttribute("aria-valuemin","0"),X.setAttribute("aria-valuemax","100"),X.setAttribute("aria-valuenow",String(Ce)),X.setAttribute("aria-valuetext",`${Ce}%`),X.setAttribute("aria-orientation","horizontal")}const z=document.createElement("div");z.style.cssText="position:fixed;left:-9999px;top:0;width:1px;height:1px;pointer-events:none;opacity:0",d.append(z),s.add(()=>z.remove());function J(X){const re=X.trim();if(!re)return null;if(re.toLowerCase()==="transparent")return{r:0,g:0,b:0,a:0};const Ee=Zc(re);if(Ee)return Ee;const Ce=zi(re);if(Ce)return Ce;try{if(z.style.color="",z.style.color=re,!z.style.color)return null;const Ie=getComputedStyle(z).color;return zi(Ie)}catch(Ie){return null}}function le(){if(c.length<=1)return;const X=c.map((re,fe)=>({stop:re,index:fe}));X.sort((re,fe)=>re.stop.position-fe.stop.position||re.index-fe.index),c=X.map(re=>re.stop)}function be(X){const re=tt(X),fe=c.length>=2?c:wn();if(fe.length===0)return Nt.color;const Ee=fe.slice().sort((Be,rt)=>Be.position-rt.position);let Ce=Ee[0],Ie=Ee[Ee.length-1];for(const Be of Ee)if(Be.position<=re&&(Ce=Be),Be.position>=re){Ie=Be;break}const Ve=J(Hi(Ce)),Ae=J(Hi(Ie));if(!Ve&&!Ae)return Ce.color.trim()||Nt.color;if(!Ve)return tr(Ae);if(!Ae)return tr(Ve);const Me=Ie.position-Ce.position;if(!Number.isFinite(Me)||Me<=0)return tr(Ve);const Ue=Jt((re-Ce.position)/Me,0,1);return tr(Jc(Ve,Ae,Ue))}function Te(){const X=u;if(!X)return Qt;const fe=(c.length>=2?c:wn()).slice().sort((Ae,Me)=>Ae.position-Me.position),Ee=fe.findIndex(Ae=>Ae.id===X);if(Ee<0)return Qt;const Ce=fe[Ee],Ie=fe[Ee+1],Ve=fe[Ee-1];return Ie?tt((Ce.position+Ie.position)/2):Ve?tt((Ve.position+Ce.position)/2):Qt}function Ne(X){if(c.length===0)return null;let re=c[0],fe=Math.abs(re.position-X);for(let Ee=1;Ee<c.length;Ee++){const Ce=c[Ee],Ie=Math.abs(Ce.position-X);if(Ie<fe){re=Ce,fe=Ie;continue}if(Ie===fe){const Ve=Ce.position>=X,Ae=re.position>=X;Ve&&!Ae&&(re=Ce)}}return re.id}function Z(X,re={}){if(l==="none"||v.disabled)return;const fe=tt(X),Ee={id:Dn(),position:fe,color:be(fe)};c.push(Ee),u=Ee.id,le(),Fe(),B(),re.focusColor&&queueMicrotask(()=>{const Ce=p.querySelector("input.we-color-text");Ce==null||Ce.focus()})}function G(X){var Ee,Ce;if(l==="none"||v.disabled||c.length<=2)return;const re=c.findIndex(Ie=>Ie.id===X);if(re<0)return;const fe=c[re];c.splice(re,1),u===X&&(u=Ne(fe.position),u||(u=(Ce=(Ee=c[0])==null?void 0:Ee.id)!=null?Ce:null)),le(),Fe(),B()}function K(X){return X instanceof HTMLInputElement||X instanceof HTMLTextAreaElement||X instanceof HTMLElement&&X.isContentEditable}function q(X={}){var Ve,Ae,Me,Ue;const re=(Ve=X.refreshStopsList)!=null?Ve:!0,fe=(Ae=X.preserveThumbs)!=null?Ae:!1;if(l==="none"){A.style.backgroundImage="none",O.textContent="",re&&ge([],[],[]);return}const Ee=Se();if(Ee.length===0){A.style.backgroundImage="none",O.textContent="",re&&ge([],[],[]);return}const Ce=Ee.map((Be,rt)=>{var $e;const ot=c[rt];return{color:Pn(Be.color)?(($e=ot==null?void 0:ot.placeholderColor)==null?void 0:$e.trim())||"transparent":Be.color,position:Be.position}});A.style.backgroundImage=ue(Ce);const Ie=c.length>=2?c:wn();if((!u||!Ie.some(Be=>Be.id===u))&&(u=(Ue=(Me=Ie[0])==null?void 0:Me.id)!=null?Ue:null),fe){const Be=O.querySelectorAll(".we-gradient-thumb");for(const rt of Be){const ot=rt.dataset.stopId;if(!ot)continue;const Ze=Ie.findIndex(Xn=>Xn.id===ot);if(Ze<0)continue;const $e=Ee[Ze],vt=Ce[Ze];if(!$e||!vt)continue;rt.style.left=`${tt($e.position)}%`,rt.style.backgroundColor=vt.color,me(rt,$e.position);const Wn=ot===u;rt.classList.toggle("we-gradient-thumb--active",Wn)}}else{O.textContent="";for(let Be=0;Be<Ee.length;Be++){const rt=Ie[Be],ot=Ee[Be],Ze=Ce[Be];if(!rt||!ot||!Ze)continue;const $e=document.createElement("button");$e.type="button",$e.className=rt.id===u?"we-gradient-thumb we-gradient-thumb--active":"we-gradient-thumb",$e.dataset.stopId=rt.id,$e.style.left=`${tt(ot.position)}%`,$e.style.backgroundColor=Ze.color,me($e,ot.position),$e.addEventListener("pointerdown",de),$e.addEventListener("keydown",ne),$e.addEventListener("focus",H),$e.addEventListener("blur",ae),O.append($e)}}re&&!fe&&ge(Ie,Ee,Ce)}function de(X){if(f||l==="none"||v.disabled||X.button!==0||!X.isPrimary)return;const re=X.currentTarget,fe=re.dataset.stopId;if(!fe)return;m&&(m=null),X.preventDefault(),X.stopPropagation(),u=fe;const Ee=new Map;for(const Ce of c)Ee.set(Ce.id,Ce.position);f={stopId:fe,pointerId:X.pointerId,initialPositions:Ee,thumbElement:re},A.classList.add("we-gradient-bar--dragging"),re.classList.add("we-gradient-thumb--dragging");try{re.setPointerCapture(X.pointerId)}catch(Ce){}R(),q({preserveThumbs:!0,refreshStopsList:!1})}function oe(X){const re=f;if(!re||X.pointerId!==re.pointerId)return;const fe=pe(X.clientX);Q(re.stopId,fe),Fe()}function he(X){const re=f;re&&X.pointerId===re.pointerId&&se(!0)}function U(X){const re=f;re&&X.pointerId===re.pointerId&&se(!1)}function ie(X){f&&X.key==="Escape"&&(X.preventDefault(),X.stopImmediatePropagation(),X.stopPropagation(),se(!1))}const ve={capture:!0,passive:!1};s.listen(window,"pointermove",oe,ve),s.listen(window,"pointerup",he,ve),s.listen(window,"pointercancel",U,ve),s.listen(window,"keydown",ie,ve);function ge(X,re,fe){var Ve;if(N.textContent="",l==="none"||X.length===0||re.length===0)return;const Ee=Ae=>{const Me=tt(Ae),Ue=Math.round(Me*100)/100;return Object.is(Ue,-0)?0:Ue},Ce=Ae=>`${Ee(Ae)}%`,Ie=re.map((Ae,Me)=>({index:Me,stop:Ae,model:X[Me],preview:fe[Me]})).filter(Ae=>!!(Ae.model&&Ae.preview)).sort((Ae,Me)=>Ae.stop.position-Me.stop.position||Ae.index-Me.index);for(let Ae=0;Ae<Ie.length;Ae++){const Me=Ie[Ae],Ue=Me.model,Be=Me.stop,rt=Me.preview,ot=Ue.id===u,Ze=document.createElement("div");Ze.className=ot?"we-gradient-stop-row we-gradient-stop-row--active":"we-gradient-stop-row",Ze.dataset.stopId=Ue.id,Ze.setAttribute("role","button"),Ze.tabIndex=0,Ze.setAttribute("aria-label",`Select stop at ${Ce(Be.position)}`);const $e=document.createElement("div");$e.className="we-gradient-stop-pos";const vt=document.createElement("span");vt.className="we-gradient-stop-pos-static",vt.textContent=Ce(Be.position);const Wn=document.createElement("div");Wn.className="we-gradient-stop-pos-editor",ot&&(Wn.append(_),Re()||(M.value=String(Ee(Be.position)))),$e.append(vt,Wn);const Xn=document.createElement("div");Xn.className="we-gradient-stop-color";const pn=document.createElement("button");pn.type="button",pn.className="we-gradient-stop-color-static",pn.tabIndex=-1,pn.setAttribute("aria-label","Select stop");const ti=document.createElement("span");ti.className="we-gradient-stop-swatch",ti.style.backgroundColor=rt.color;const ni=document.createElement("span");ni.className="we-gradient-stop-color-text",ni.textContent=Be.color.trim()||Nt.color,pn.append(ti,ni);const ri=document.createElement("div");ri.className="we-gradient-stop-color-editor",ot&&(ri.append(p),y.isFocused()||(y.setValue(Be.color),y.setPlaceholder(Pn(Be.color)&&(Ve=Ue.placeholderColor)!=null?Ve:""))),Xn.append(pn,ri);const mn=document.createElement("button");mn.type="button",mn.className="we-icon-btn we-gradient-stop-remove",mn.setAttribute("aria-label","Remove stop");const Ym=!v.disabled&&X.length>2;mn.disabled=!Ym,mn.textContent="–",mn.addEventListener("click",ze=>{ze.preventDefault(),ze.stopPropagation(),G(Ue.id)});const Ga=()=>{queueMicrotask(()=>{M.focus(),M.select()})},Wa=()=>{queueMicrotask(()=>{const ze=p.querySelector("input.we-color-text");ze==null||ze.focus()})},Gr=ze=>{u=Ue.id,q(),ze!=null&&ze.focusColor&&Wa(),ze!=null&&ze.focusPosition&&Ga()};Ze.addEventListener("click",ze=>{Ue.id!==u&&(ze.preventDefault(),Gr())}),Ze.addEventListener("keydown",ze=>{var Xa;if(!K(ze.target)){if(ze.key==="ArrowUp"||ze.key==="ArrowDown"){ze.preventDefault(),ze.stopPropagation();const Ya=ze.key==="ArrowUp"?Math.max(0,Ae-1):Math.min(Ie.length-1,Ae+1);if(Ya===Ae)return;const oi=(Xa=Ie[Ya])==null?void 0:Xa.model;if(!oi)return;u=oi.id,q(),queueMicrotask(()=>{const ii=N.querySelector(`.we-gradient-stop-row[data-stop-id="${oi.id}"]`);ii==null||ii.focus()});return}Ue.id!==u&&(ze.key==="Enter"||ze.key===" ")&&(ze.preventDefault(),Gr())}}),vt.addEventListener("click",ze=>{if(ze.preventDefault(),ze.stopPropagation(),Ue.id===u){Ga();return}Gr({focusPosition:!0})}),pn.addEventListener("click",ze=>{if(ze.preventDefault(),ze.stopPropagation(),Ue.id===u){Wa();return}Gr({focusColor:!0})}),Ze.append($e,Xn,mn),N.append(Ze)}}function ye(){L.hidden=l==="none",V.hidden=l!=="linear",T.hidden=l!=="radial",j.hidden=l!=="radial",w.hidden=l!=="radial",$.hidden=l==="none",N.hidden=l==="none",I.disabled=v.disabled||l==="none"}function ke(X){v.disabled=X,F.disabled=X,P.disabled=X,E.disabled=X,D.disabled=X,I.disabled=X,M.disabled=X||l==="none",y.setDisabled(X||l==="none")}function We(X={}){var re,fe;F.value=String(er),P.value="ellipse",E.value="",D.value="",c=wn(),u=(fe=(re=c[0])==null?void 0:re.id)!=null?fe:null,X.skipPreview||q()}function Re(){return yn(M)}function gt(){return h!==null||yn(v)||yn(F)||yn(P)||yn(E)||yn(D)||Re()||y.isFocused()}function ee(X){return X.map(re=>{const fe=re.color.trim()||Nt.color,Ee=tt(re.position);return`${fe} ${Ee}%`}).join(", ")}function ce(X){var Me,Ue,Be;if(l==="none"||X.length===0)return"none";const re=ee(X);if(l==="linear")return`linear-gradient(${Ui((Me=or(F.value))!=null?Me:er)}deg, ${re})`;const fe=P.value||"ellipse",Ee=E.value.trim(),Ce=D.value.trim();if(!!!(Ee||Ce))return`radial-gradient(${fe}, ${re})`;const Ve=tt((Ue=or(Ee))!=null?Ue:Qt),Ae=tt((Be=or(Ce))!=null?Be:Qt);return`radial-gradient(${fe} at ${Ve}% ${Ae}%, ${re})`}function ue(X){return X.length===0?"linear-gradient(90deg, transparent, transparent)":`linear-gradient(90deg, ${ee(X)})`}function Se(){return(c.length>=2?c:wn()).map(re=>({color:re.color.trim()||Nt.color,position:tt(re.position)}))}function De(){if(l==="none")return"none";const X=Se();return ce(X)}function Fe(){if(s.isDisposed)return;const X=f!==null,re=m!==null,fe=y.isFocused()||Re();q({preserveThumbs:X||re,refreshStopsList:X||re?!1:!fe});const Ee=a;if(!Ee||!Ee.isConnected)return;const Ce=R();Ce&&Ce.set(De())}function Oe(X=!1){var rt,ot,Ze;const re=a;if(!re||!re.isConnected){ke(!0);const $e=i?"none":"linear";l=$e,v.value=$e,We(),ye(),q();return}if(ke(!1),gt()&&!X)return;const fe=eu(re,o),Ce=!fe||/\bvar\s*\(/i.test(fe)?tu(re,o):"",Ie=rr(fe)?null:ji(fe),Ve=rr(Ce)?null:ji(Ce);let Ae=null,Me="none";if(fe.trim()?rr(fe)?(Ae=null,Me="none"):Ie?(Ae=Ie,Me="inline"):(Ae=null,Me="none"):rr(Ce)?(Ae=null,Me="none"):Ve?(Ae=Ve,Me="computed"):(Ae=null,Me="none"),We({skipPreview:!0}),!Ae){const $e=i?"none":"linear";l=$e,v.value=$e,ye(),q();return}const Ue=Ae.stops.length>=2?Ae.stops.slice():[je({},Nt),je({},ro)];if(Me==="inline"&&Pn(fe)&&Ve){const $e=cu(Ue,Ve.stops);for(let vt=0;vt<Ue.length;vt++)Ue[vt].placeholderColor=(rt=$e[vt])!=null?rt:""}c=qc(c,Ue),(!u||!c.some($e=>$e.id===u))&&(u=(Ze=(ot=c[0])==null?void 0:ot.id)!=null?Ze:null),Ae.type==="linear"?(l="linear",v.value="linear",F.value=String(Ae.angle)):(l="radial",v.value="radial",P.value=Ae.shape,Ae.position?(E.value=String(Ae.position.x),D.value=String(Ae.position.y)):(E.value="",D.value="")),ye(),q()}function nt(X){s.listen(X,"input",Fe),s.listen(X,"blur",()=>{B(),Oe()}),s.listen(X,"keydown",re=>{re.key==="Enter"?(re.preventDefault(),B(),Oe(),X.blur()):re.key==="Escape"&&(re.preventDefault(),Y(),Oe(!0))})}function ft(X,re){const fe=()=>{re==null||re(),Fe()};s.listen(X,"input",fe),s.listen(X,"change",fe),s.listen(X,"blur",()=>{B(),Oe()}),s.listen(X,"keydown",Ee=>{Ee.key==="Enter"?(Ee.preventDefault(),B(),Oe(),X.blur()):Ee.key==="Escape"&&(Ee.preventDefault(),Y(),Oe(!0))})}ft(v,()=>{l=v.value,ye()}),ft(P),nt(F),nt(E),nt(D),s.listen(I,"click",X=>{X.preventDefault(),!I.disabled&&Z(Te(),{focusColor:!0})}),s.listen(A,"dblclick",X=>{f||l==="none"||v.disabled||X.composedPath().some(fe=>fe instanceof HTMLElement&&fe.classList.contains("we-gradient-thumb"))||(X.preventDefault(),Z(pe(X.clientX),{focusColor:!0}))}),s.listen(d,"keydown",X=>{if(X.key!=="Delete"&&X.key!=="Backspace"||f||l==="none"||v.disabled)return;const re=u;if(!re||K(X.target))return;const fe=X.composedPath();!fe.includes(N)&&!fe.includes(A)||(X.preventDefault(),X.stopPropagation(),G(re))});function pt(X){s.isDisposed||(X!==a&&B(),a=X,Oe(!0))}function Le(){s.isDisposed||Oe()}function At(){B(),a=null,s.dispose()}return v.value=l,We(),ye(),Oe(!0),{setTarget:pt,refresh:Le,dispose:At}}const en="http://www.w3.org/2000/svg",uu=["100","200","300","400","500","600","700","800","900"],Ki=["left","center","right","justify"],qi=["baseline","middle","top","bottom"],du=["solid","gradient"],Zi=["inherit","system-ui","sans-serif","serif","monospace"],ir="custom";function Qi(){const e=document.createElementNS(en,"svg");return e.setAttribute("viewBox","0 0 15 15"),e.setAttribute("fill","none"),e.setAttribute("aria-hidden","true"),e.setAttribute("focusable","false"),e}function fu(e){const t=Qi(),n=document.createElementNS(en,"rect");n.setAttribute("x","2"),n.setAttribute("y","2"),n.setAttribute("width","11"),n.setAttribute("height","11"),n.setAttribute("rx","1.5"),n.setAttribute("stroke","currentColor"),n.setAttribute("stroke-width","1"),n.setAttribute("stroke-dasharray","2 1"),n.setAttribute("fill","none"),n.setAttribute("opacity","0.5");const r={left:[[3.5,8],[3.5,5],[3.5,6.5]],center:[[3.5,8],[5,5],[4.25,6.5]],right:[[3.5,8],[6.5,5],[5.5,6.5]],justify:[[3.5,8],[3.5,8],[3.5,8]]},o=[4.5,7.5,10.5];return r[e].forEach(([s,a],l)=>{const c=document.createElementNS(en,"rect");c.setAttribute("x",String(s)),c.setAttribute("y",String(o[l]-.5)),c.setAttribute("width",String(a)),c.setAttribute("height","1"),c.setAttribute("rx","0.5"),c.setAttribute("fill","currentColor"),t.append(c)}),t.prepend(n),t}function pu(e){const t=Qi(),n=document.createElementNS(en,"rect");n.setAttribute("x","2"),n.setAttribute("y","2"),n.setAttribute("width","11"),n.setAttribute("height","11"),n.setAttribute("rx","1.5"),n.setAttribute("stroke","currentColor"),n.setAttribute("stroke-width","1"),n.setAttribute("stroke-dasharray","2 1"),n.setAttribute("fill","none"),n.setAttribute("opacity","0.5");const r={top:3.5,middle:5.5,bottom:7.5,baseline:6.5},o=document.createElementNS(en,"rect");o.setAttribute("x","4"),o.setAttribute("y",String(r[e])),o.setAttribute("width","3"),o.setAttribute("height","4"),o.setAttribute("rx","0.5"),o.setAttribute("fill","currentColor");const i=document.createElementNS(en,"rect");if(i.setAttribute("x","8"),i.setAttribute("y",String(r[e])),i.setAttribute("width","3"),i.setAttribute("height","4"),i.setAttribute("rx","0.5"),i.setAttribute("fill","currentColor"),t.append(n,o,i),e==="baseline"){const s=document.createElementNS(en,"path");s.setAttribute("d","M3 10H12"),s.setAttribute("stroke","currentColor"),s.setAttribute("stroke-width","1"),s.setAttribute("stroke-dasharray","1.5 1"),t.append(s)}return t}function mu(e){return Ki.includes(e)}function hu(e){return qi.includes(e)}function uo(e){try{const t=e.getRootNode();return t instanceof ShadowRoot?t.activeElement===e:document.activeElement===e}catch(t){return!1}}function _t(e,t){var n,r,o;try{const i=e.style;return(o=(r=(n=i==null?void 0:i.getPropertyValue)==null?void 0:n.call(i,t))==null?void 0:r.trim())!=null?o:""}catch(i){return""}}function Rt(e,t){try{return window.getComputedStyle(e).getPropertyValue(t).trim()}catch(n){return""}}function Ji(e){return/\b(?:linear|radial|conic)-gradient\s*\(/i.test(e.trim())}function gu(e){const t=e.trim().toLowerCase();return t?!!(t==="transparent"||/^rgba\([^)]*,\s*0\s*\)$/.test(t)):!1}function es(e){const t=_t(e,"background-image")||Rt(e,"background-image"),n=_t(e,"-webkit-background-clip")||Rt(e,"-webkit-background-clip"),r=_t(e,"-webkit-text-fill-color")||Rt(e,"-webkit-text-fill-color"),o=t&&t.toLowerCase()!=="none"&&Ji(t),i=n.toLowerCase().includes("text"),s=gu(r);return o&&i&&s?"gradient":"solid"}function bu(e){const{container:t,transactionManager:n,tokensService:r}=e,o=new Pe;let i=null,s="solid";const a=document.createElement("div");a.className="we-field-group";const l=document.createElement("div");l.className="we-field";const c=document.createElement("span");c.className="we-field-label",c.textContent="Font";const u=document.createElement("div");u.className="we-field-content",u.style.display="flex",u.style.flexDirection="column",u.style.gap="4px";const f=document.createElement("select");f.className="we-select",f.setAttribute("aria-label","Font Family");for(const G of Zi){const K=document.createElement("option");K.value=G,K.textContent=G,f.append(K)}const m=document.createElement("option");m.value=ir,m.textContent="Custom…",f.append(m);const h=Xe({ariaLabel:"Custom Font Family",prefix:null,suffix:null,placeholder:"e.g. Inter, system-ui"});h.root.style.display="none",h.input.disabled=!0,u.append(f,h.root),l.append(c,u);const d=document.createElement("div");d.className="we-field";const b=document.createElement("span");b.className="we-field-label",b.textContent="Size";const S=Xe({ariaLabel:"Font Size",inputMode:"decimal",prefix:null,suffix:"px"});d.append(b,S.root);const g=document.createElement("div");g.className="we-field";const k=document.createElement("span");k.className="we-field-label",k.textContent="Weight";const v=document.createElement("select");v.className="we-select",v.setAttribute("aria-label","Font Weight");for(const G of uu){const K=document.createElement("option");K.value=G,K.textContent=G,v.append(K)}g.append(k,v);const L=document.createElement("div");L.className="we-field";const A=document.createElement("span");A.className="we-field-label",A.textContent="Line Height";const O=Xe({ariaLabel:"Line Height",inputMode:"decimal",prefix:null,suffix:null});L.append(A,O.root);const V=document.createElement("div");V.className="we-field";const F=document.createElement("span");F.className="we-field-label",F.textContent="Spacing";const T=Xe({ariaLabel:"Letter Spacing",inputMode:"decimal",prefix:null,suffix:"px"});V.append(F,T.root),Ye(o,S.input,{mode:"css-length"}),Ye(o,O.input,{mode:"css-length",step:.1,shiftStep:1,altStep:.01}),Ye(o,T.input,{mode:"css-length",step:.1,shiftStep:1,altStep:.01});const P=document.createElement("div");P.className="we-field";const j=document.createElement("span");j.className="we-field-label",j.textContent="Text Align";const E=document.createElement("div");E.className="we-field-content",P.append(j,E);const w=document.createElement("div");w.className="we-field";const D=document.createElement("span");D.className="we-field-label",D.textContent="Vertical Align";const $=document.createElement("div");$.className="we-field-content",w.append(D,$);const x=document.createElement("div");x.className="we-field";const I=document.createElement("span");I.className="we-field-label",I.textContent="Type";const N=document.createElement("select");N.className="we-select",N.setAttribute("aria-label","Text Color Type");for(const G of du){const K=document.createElement("option");K.value=G,K.textContent=G.charAt(0).toUpperCase()+G.slice(1),N.append(K)}x.append(I,N);const _=document.createElement("div");_.className="we-field";const M=document.createElement("span");M.className="we-field-label",M.textContent="Color";const W=document.createElement("div");W.style.minWidth="0",_.append(M,W);const C=document.createElement("div"),p=document.createElement("div");p.className="we-field-row",d.style.flex="1",d.style.minWidth="0",g.style.flex="1",g.style.minWidth="0",p.append(d,g);const y=document.createElement("div");y.className="we-field-row",L.style.flex="1",L.style.minWidth="0",V.style.flex="1",V.style.minWidth="0",y.append(L,V),a.append(l,p,y,P,w,x,_,C),t.append(a),o.add(()=>a.remove());const R=Ut({container:E,ariaLabel:"Text Align",columns:4,items:Ki.map(G=>({value:G,ariaLabel:`text-align: ${G}`,title:G.charAt(0).toUpperCase()+G.slice(1),icon:fu(G)})),onChange:G=>{const K=pe("text-align");K&&K.set(G),xe("text-align"),z()}});o.add(()=>R.dispose());const B=Ut({container:$,ariaLabel:"Vertical Align",columns:4,items:qi.map(G=>({value:G,ariaLabel:`vertical-align: ${G}`,title:G.charAt(0).toUpperCase()+G.slice(1),icon:pu(G)})),onChange:G=>{const K=pe("vertical-align");K&&K.set(G),xe("vertical-align"),z()}});o.add(()=>B.dispose());const Y=Mn({container:W,ariaLabel:"Text Color",tokensService:r,getTokenTarget:()=>i,onInput:G=>{const K=pe("color");K&&K.set(G)},onCommit:()=>{xe("color"),z()},onCancel:()=>{we("color"),me("color",!0)}});o.add(()=>Y.dispose());const Q=co({container:C,transactionManager:n,tokensService:r,property:"background-image",allowNone:!1});o.add(()=>Q.dispose());const te={"font-family":{kind:"font-family",property:"font-family",select:f,custom:h,controlsContainer:u,handle:null},"font-size":{kind:"standard",property:"font-size",element:S.input,container:S,handle:null},"font-weight":{kind:"standard",property:"font-weight",element:v,handle:null},"line-height":{kind:"standard",property:"line-height",element:O.input,container:O,handle:null},"letter-spacing":{kind:"standard",property:"letter-spacing",element:T.input,container:T,handle:null},"text-align":{kind:"text-align",property:"text-align",group:R,handle:null},"vertical-align":{kind:"vertical-align",property:"vertical-align",group:B,handle:null},color:{kind:"color",property:"color",field:Y,handle:null}},se=["font-family","font-size","font-weight","line-height","letter-spacing","text-align","vertical-align","color"];function pe(G){if(o.isDisposed)return null;const K=i;if(!K||!K.isConnected)return null;const q=te[G];if(q.handle)return q.handle;const de=n.beginStyle(K,G);return q.handle=de,de}function xe(G){const K=te[G],q=K.handle;K.handle=null,q&&q.commit({merge:!0})}function we(G){const K=te[G],q=K.handle;K.handle=null,q&&q.rollback()}function H(){for(const G of se)xe(G)}function ae(){_.hidden=s!=="solid",C.hidden=s!=="gradient"}function ne(G){const K=i;if(s=G,N.value=G,ae(),!K||!K.isConnected)return;xe("color");const q=n.beginMultiStyle(K,["background-image","-webkit-background-clip","-webkit-text-fill-color"]);if(q){if(G==="solid")q.set({"background-image":"","-webkit-background-clip":"","-webkit-text-fill-color":""});else{const de=_t(K,"background-image"),oe=Rt(K,"background-image"),he=de||oe,ie=he&&Ji(he)?he:"linear-gradient(90deg, #000000, #ffffff)";q.set({"background-image":ie,"-webkit-background-clip":"text","-webkit-text-fill-color":"transparent"})}q.commit({merge:!0})}}o.listen(N,"change",()=>{const G=N.value;ne(G),Q.refresh(),z()});function me(G,K=!1){var U,ie,ve;const q=te[G],de=i;if(q.kind==="font-family"){const ge=Zi;if(!de||!de.isConnected){q.select.disabled=!0,q.select.value=(U=ge[0])!=null?U:"inherit",q.custom.input.disabled=!0,q.custom.input.value="",q.custom.root.style.display="none";return}if(q.select.disabled=!1,(q.handle!==null||uo(q.select)||uo(q.custom.input))&&!K)return;const We=_t(de,G)||Rt(de,G),Re=We.trim().toLowerCase();ge.includes(Re)?(q.select.value=Re,q.custom.root.style.display="none",q.custom.input.disabled=!0):(q.select.value=ir,q.custom.root.style.display="",q.custom.input.disabled=!1,q.custom.input.value=We);return}if(q.kind==="text-align"){const ge=q.group;if(!de||!de.isConnected){ge.setDisabled(!0),ge.setValue(null);return}if(ge.setDisabled(!1),q.handle!==null&&!K)return;const ke=_t(de,G),We=Rt(de,G),Re=(ke||We).trim();ge.setValue(mu(Re)?Re:"left");return}if(q.kind==="vertical-align"){const ge=q.group;if(!de||!de.isConnected){ge.setDisabled(!0),ge.setValue(null);return}if(ge.setDisabled(!1),q.handle!==null&&!K)return;const ke=_t(de,G),We=Rt(de,G),Re=(ke||We).trim();ge.setValue(hu(Re)?Re:"baseline");return}if(q.kind==="color"){const ge=q.field;if(!de||!de.isConnected){ge.setDisabled(!0),ge.setValue(""),ge.setPlaceholder("");return}if(ge.setDisabled(!1),(q.handle!==null||ge.isFocused())&&!K)return;const ke=_t(de,G),We=Rt(de,G);ke?(ge.setValue(ke),ge.setPlaceholder(/\bvar\s*\(/i.test(ke)?We:"")):(ge.setValue(We),ge.setPlaceholder(""));return}const oe=q.element;if(!de||!de.isConnected){oe.disabled=!0,oe instanceof HTMLInputElement&&(oe.value="",oe.placeholder="",q.container&&(G==="font-size"||G==="letter-spacing"?q.container.setSuffix("px"):G==="line-height"&&q.container.setSuffix(null)));return}oe.disabled=!1;const he=q.handle!==null||uo(oe);if(oe instanceof HTMLInputElement){if(he&&!K)return;const ye=_t(de,G)||Rt(de,G);if(q.container)if(G==="font-size"||G==="letter-spacing"){const ke=bt(ye);oe.value=ke.value,q.container.setSuffix(ke.suffix)}else if(G==="line-height")if(Vl(ye)){const ke=bt(ye);oe.value=ke.value,q.container.setSuffix(ke.suffix)}else oe.value=ye,q.container.setSuffix(null);else oe.value=ye;else oe.value=ye;oe.placeholder=""}else{const ge=_t(de,G),ye=Rt(de,G);if(he&&!K)return;const ke=ge||ye,We=Array.from(oe.options).some(Re=>Re.value===ke);oe.value=We?ke:(ve=(ie=oe.options[0])==null?void 0:ie.value)!=null?ve:""}}function z(){for(const K of se)me(K);const G=!!(i&&i.isConnected);N.disabled=!G,ae()}function J(G){const K=te[G];if(K.kind!=="standard")return;const q=K.element,de=()=>{const oe=pe(G);oe&&oe.set(q.value)};o.listen(q,"input",de),o.listen(q,"change",de),o.listen(q,"blur",()=>{xe(G),z()}),o.listen(q,"keydown",oe=>{oe.key==="Enter"?(oe.preventDefault(),xe(G),z(),q.blur()):oe.key==="Escape"&&(oe.preventDefault(),we(G),me(G,!0))})}function le(G,K=q=>q.trim()){const q=te[G];if(q.kind!=="standard")return;const de=q.element;o.listen(de,"input",()=>{var U,ie;const oe=pe(G);if(!oe)return;const he=(ie=(U=q.container)==null?void 0:U.getSuffixText())!=null?ie:null;oe.set(K(de.value,he))}),o.listen(de,"blur",()=>{xe(G),z()}),o.listen(de,"keydown",oe=>{oe.key==="Enter"?(oe.preventDefault(),xe(G),z(),de.blur()):oe.key==="Escape"&&(oe.preventDefault(),we(G),me(G,!0))})}function be(){const G=te["font-family"];if(G.kind!=="font-family")return;const{select:K,custom:q,controlsContainer:de}=G,oe=()=>{const U=K.value===ir;q.root.style.display=U?"":"none",q.input.disabled=!U,U&&q.input.focus()},he=()=>{if(oe(),K.value===ir)return;const U=pe("font-family");U&&U.set(K.value)};o.listen(K,"input",he),o.listen(K,"change",he),o.listen(q.input,"input",()=>{const U=pe("font-family");U&&U.set(q.input.value.trim())}),o.listen(de,"focusout",U=>{const ie=U.relatedTarget;ie instanceof Node&&de.contains(ie)||(xe("font-family"),z())}),o.listen(K,"keydown",U=>{U.key==="Enter"?(U.preventDefault(),xe("font-family"),z(),K.blur()):U.key==="Escape"&&(U.preventDefault(),we("font-family"),me("font-family",!0))}),o.listen(q.input,"keydown",U=>{U.key==="Enter"?(U.preventDefault(),xe("font-family"),z(),q.input.blur()):U.key==="Escape"&&(U.preventDefault(),we("font-family"),me("font-family",!0))})}be(),le("font-size",wt),J("font-weight"),le("line-height",(G,K)=>{const q=G.trim();return q?/[a-zA-Z%]/.test(q)?q:K?`${q}${K}`:q:""}),le("letter-spacing",wt);function Te(G){o.isDisposed||(G!==i&&H(),i=G,G&&G.isConnected?s=es(G):s="solid",N.value=s,ae(),Q.setTarget(G),z())}function Ne(){if(o.isDisposed)return;const G=i;if(G&&G.isConnected){const K=es(G);K!==s&&(s=K,N.value=K)}Q.refresh(),z()}function Z(){H(),i=null,o.dispose()}return z(),{setTarget:Te,refresh:Ne,dispose:Z}}function wu(e){const{sliderAriaLabel:t,inputAriaLabel:n,min:r,max:o,step:i,inputMode:s="decimal",inputWidthPx:a=72}=e,l=document.createElement("div");l.className="we-slider-input";const c=document.createElement("input");c.type="range",c.className="we-slider-input__slider",c.min=String(r),c.max=String(o),c.step=String(i),c.value=String(r),c.setAttribute("aria-label",t);function u(){const S=parseFloat(c.value),g=parseFloat(c.min),k=parseFloat(c.max),v=(S-g)/(k-g)*100;c.style.setProperty("--progress",`${v}%`)}u(),c.addEventListener("input",u);const f=Xe({ariaLabel:n,inputMode:s,prefix:null,suffix:null,rootClassName:"we-slider-input__number"});f.root.style.width=`${a}px`,f.root.style.flex="0 0 auto",l.append(c,f.root);function m(S){c.disabled=S,f.input.disabled=S}function h(S){c.disabled=S}function d(S){const g=String(S);c.value=g,f.input.value=g,u()}function b(S){c.value=String(S),u()}return{root:l,slider:c,input:f.input,inputContainer:f,setDisabled:m,setSliderDisabled:h,setValue:d,setSliderValue:b}}const xu=["visible","hidden","scroll","auto"],yu=["content-box","border-box"];function fo(e){try{const t=e.getRootNode();return t instanceof ShadowRoot?t.activeElement===e:document.activeElement===e}catch(t){return!1}}function po(e){return e.trim()}const vu=/^-?(?:(?:\d+\.\d+)|(?:\d+\.)|(?:\d+)|(?:\.\d+))$/;function sr(e){if(!Number.isFinite(e))return 1;const t=Math.min(1,Math.max(0,e));return Object.is(t,-0)?0:t}function ar(e){const t=e.trim();if(!t||!vu.test(t))return null;const n=t.endsWith(".")?t.slice(0,-1):t,r=Number(n);return Number.isFinite(r)?r:null}function ts(e,t){var n,r,o;try{const i=e.style;return(o=(r=(n=i==null?void 0:i.getPropertyValue)==null?void 0:n.call(i,t))==null?void 0:r.trim())!=null?o:""}catch(i){return""}}function ns(e,t){try{return window.getComputedStyle(e).getPropertyValue(t).trim()}catch(n){return""}}function Eu(e){const{container:t,transactionManager:n}=e,r=new Pe;let o=null;const i=document.createElement("div");i.className="we-field-group";function s(E,w,D){const $=document.createElement("div");$.className="we-field";const x=document.createElement("span");x.className="we-field-label",x.textContent=E;const I=document.createElement("select");I.className="we-select",I.setAttribute("aria-label",w);for(const N of D){const _=document.createElement("option");_.value=N,_.textContent=N,I.appendChild(_)}return $.append(x,I),{row:$,select:I}}const{row:a,select:l}=s("Overflow","Overflow",xu),{row:c,select:u}=s("Box Sizing","Box Sizing",yu),f=document.createElement("div");f.className="we-field";const m=document.createElement("span");m.className="we-field-label",m.textContent="Opacity";const h=document.createElement("div");h.className="we-field-content",f.append(m,h);const d=wu({sliderAriaLabel:"Opacity slider",inputAriaLabel:"Opacity value",min:0,max:1,step:.01,inputMode:"decimal",inputWidthPx:72});h.append(d.root),Ye(r,d.input,{mode:"number",min:0,max:1,step:.01,shiftStep:.1,altStep:.001}),i.append(a,c,f),t.appendChild(i),r.add(()=>i.remove());const b={overflow:{kind:"select",property:"overflow",element:l,handle:null},"box-sizing":{kind:"select",property:"box-sizing",element:u,handle:null},opacity:{kind:"opacity",property:"opacity",control:d,handle:null}},S=["overflow","box-sizing","opacity"];function g(E){if(r.isDisposed)return null;const w=o;if(!w||!w.isConnected)return null;const D=b[E];if(D.handle)return D.handle;const $=n.beginStyle(w,E);return D.handle=$,$}function k(E){const w=b[E],D=w.handle;w.handle=null,D&&D.commit({merge:!0})}function v(E){const w=b[E],D=w.handle;w.handle=null,D&&D.rollback()}function L(){for(const E of S)k(E)}function A(E,w=!1){var x,I,N;const D=b[E],$=o;if(D.kind==="opacity"){const{slider:_,input:M}=D.control;if(!$||!$.isConnected){D.control.setDisabled(!0),_.value="0",M.value="",M.placeholder="";return}if(D.control.setDisabled(!1),(D.handle!==null||fo(_)||fo(M))&&!w)return;const C=ts($,E),p=ns($,E),y=C||p;M.value=y,M.placeholder="";const R=ar(y),B=ar(p);if(C&&R===null){D.control.setSliderDisabled(!0),B!==null&&D.control.setSliderValue(sr(B));return}const Y=(x=R!=null?R:B)!=null?x:1;D.control.setSliderDisabled(!1),D.control.setSliderValue(sr(Y))}else{const _=D.element;if(!$||!$.isConnected){_.disabled=!0;return}if(_.disabled=!1,(D.handle!==null||fo(_))&&!w)return;const W=ts($,E),C=ns($,E),p=W||C,y=Array.from(_.options).some(R=>R.value===p);_.value=y?p:(N=(I=_.options[0])==null?void 0:I.value)!=null?N:""}}function O(){for(const E of S)A(E)}function V(){const E=b.opacity;if(E.kind!=="opacity")return;const{slider:w,input:D}=E.control,$=()=>{const x=po(D.value),I=ar(x);if(I!==null){const N=sr(I),_=String(N);if(x!==_){D.value=_;const M=E.handle;M&&M.set(_)}}k("opacity"),O()};r.listen(w,"input",()=>{if(w.disabled)return;D.value=w.value;const x=g("opacity");x&&x.set(po(w.value))}),r.listen(w,"change",$),r.listen(w,"blur",$),r.listen(w,"keydown",x=>{x.key==="Enter"?(x.preventDefault(),k("opacity"),O(),w.blur()):x.key==="Escape"&&(x.preventDefault(),v("opacity"),A("opacity",!0))}),r.listen(D,"input",()=>{const x=po(D.value),I=g("opacity");I&&I.set(x);const N=ar(x);if(N===null){E.control.setSliderDisabled(x.length>0);return}E.control.setSliderDisabled(!1),E.control.setSliderValue(sr(N))}),r.listen(D,"blur",$),r.listen(D,"keydown",x=>{x.key==="Enter"?(x.preventDefault(),k("opacity"),O(),D.blur()):x.key==="Escape"&&(x.preventDefault(),v("opacity"),A("opacity",!0))})}function F(E){const w=b[E];if(w.kind!=="select")return;const D=w.element,$=()=>{const x=g(E);x&&x.set(D.value)};r.listen(D,"input",$),r.listen(D,"change",$),r.listen(D,"blur",()=>{k(E),O()}),r.listen(D,"keydown",x=>{x.key==="Enter"?(x.preventDefault(),k(E),O(),D.blur()):x.key==="Escape"&&(x.preventDefault(),v(E),A(E,!0))})}F("overflow"),F("box-sizing"),V();function T(E){r.isDisposed||(E!==o&&L(),o=E,O())}function P(){r.isDisposed||O()}function j(){L(),o=null,r.dispose()}return O(),{setTarget:T,refresh:P,dispose:j}}const tn="http://www.w3.org/2000/svg",Su=["solid","dashed","dotted","none"],ku=["solid","gradient"],Cu=["all","top","right","bottom","left"],nn=["top-left","top-right","bottom-right","bottom-left"],vn={"top-left":"border-top-left-radius","top-right":"border-top-right-radius","bottom-right":"border-bottom-right-radius","bottom-left":"border-bottom-left-radius"},Au=["border-radius","border-top-left-radius","border-top-right-radius","border-bottom-right-radius","border-bottom-left-radius"];function lr(e){try{const t=e.getRootNode();return t instanceof ShadowRoot?t.activeElement===e:document.activeElement===e}catch(t){return!1}}function xt(e,t){var n,r,o;try{const i=e.style;return(o=(r=(n=i==null?void 0:i.getPropertyValue)==null?void 0:n.call(i,t))==null?void 0:r.trim())!=null?o:""}catch(i){return""}}function lt(e,t){try{return window.getComputedStyle(e).getPropertyValue(t).trim()}catch(n){return""}}function rs(e){const t=e.trim().toLowerCase();return!t||t==="none"?"solid":/\b(?:linear|radial|conic)-gradient\s*\(/i.test(t)?"gradient":"solid"}function Tu(e){const t=document.createElementNS(tn,"svg");t.setAttribute("viewBox","0 0 15 15"),t.setAttribute("fill","none"),t.setAttribute("aria-hidden","true"),t.setAttribute("focusable","false");const n=document.createElementNS(tn,"rect");n.setAttribute("x","3.5"),n.setAttribute("y","3.5"),n.setAttribute("width","8"),n.setAttribute("height","8"),n.setAttribute("stroke","currentColor"),n.setAttribute("stroke-width","1"),n.setAttribute("opacity","0.4"),t.appendChild(n);const r=document.createElementNS(tn,"path");switch(r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","2"),r.setAttribute("stroke-linecap","round"),e){case"all":r.setAttribute("d","M3.5 3.5h8v8h-8z");break;case"top":r.setAttribute("d","M3.5 3.5h8");break;case"right":r.setAttribute("d","M11.5 3.5v8");break;case"bottom":r.setAttribute("d","M3.5 11.5h8");break;case"left":r.setAttribute("d","M3.5 3.5v8");break}return t.appendChild(r),t}function Nu(){const e=document.createElementNS(tn,"svg");e.setAttribute("viewBox","0 0 15 15"),e.setAttribute("fill","none"),e.setAttribute("aria-hidden","true"),e.setAttribute("focusable","false");const t=document.createElementNS(tn,"path");return t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1.5"),t.setAttribute("stroke-linecap","round"),t.setAttribute("stroke-linejoin","round"),t.setAttribute("d","M4 6V4H6 M9 4H11V6 M11 9V11H9 M6 11H4V9"),e.appendChild(t),e}function cr(e){const t=document.createElementNS(tn,"svg");t.setAttribute("viewBox","0 0 15 15"),t.setAttribute("fill","none"),t.setAttribute("aria-hidden","true"),t.setAttribute("focusable","false");const n=document.createElementNS(tn,"path");switch(n.setAttribute("stroke","currentColor"),n.setAttribute("stroke-width","1.5"),n.setAttribute("stroke-linecap","round"),n.setAttribute("stroke-linejoin","round"),e){case"top-left":n.setAttribute("d","M11 4H6Q4 4 4 6V11");break;case"top-right":n.setAttribute("d","M4 4H9Q11 4 11 6V11");break;case"bottom-right":n.setAttribute("d","M11 4V9Q11 11 9 11H4");break;case"bottom-left":n.setAttribute("d","M4 4V9Q4 11 6 11H11");break}return t.appendChild(n),t}function _u(e){const{container:t,transactionManager:n,tokensService:r}=e,o=new Pe;let i=null,s="all",a="solid";const l=document.createElement("div");l.className="we-field-group";function c(Z,G,K){const q=document.createElement("div");q.className="we-field";const de=document.createElement("span");de.className="we-field-label",de.textContent=Z;const oe=document.createElement("select");oe.className="we-select",oe.setAttribute("aria-label",G);for(const he of K){const U=document.createElement("option");U.value=he,U.textContent=he,oe.appendChild(U)}return q.append(de,oe),{row:q,select:oe}}function u(Z){const G=document.createElement("div");G.className="we-field";const K=document.createElement("span");K.className="we-field-label",K.textContent=Z;const q=document.createElement("div");return q.style.flex="1",q.style.minWidth="0",G.append(K,q),{row:G,colorFieldContainer:q}}const f=document.createElement("div");f.className="we-field";const m=document.createElement("span");m.className="we-field-label",m.textContent="Edge";const h=document.createElement("div");h.style.flex="1",f.append(m,h);const d=document.createElement("div");d.className="we-field";const b=document.createElement("span");b.className="we-field-label",b.textContent="Width";const S=Xe({ariaLabel:"Border Width",inputMode:"decimal",prefix:null,suffix:"px"});d.append(b,S.root);const g=S.input,{row:k,select:v}=c("Style","Border Style",Su),{row:L,select:A}=c("Type","Border Color Type",ku),{row:O,colorFieldContainer:V}=u("Color"),F=document.createElement("div"),T=document.createElement("div");T.className="we-field";const P=document.createElement("span");P.className="we-field-label",P.textContent="Radius";const j=document.createElement("div");j.className="we-radius-control";const E=document.createElement("div");E.className="we-field-row";const w=Xe({ariaLabel:"Border Radius",inputMode:"decimal",prefix:null,suffix:"px"});w.root.style.flex="1";const D=document.createElement("button");D.type="button",D.className="we-toggle-btn",D.setAttribute("aria-label","Edit corners"),D.setAttribute("aria-pressed","false"),D.dataset.tooltip="Edit corners",D.append(Nu()),E.append(w.root,D);const $=document.createElement("div");$.className="we-radius-corners-grid",$.hidden=!0;const x={"top-left":Xe({ariaLabel:"Top-left radius",inputMode:"decimal",prefix:cr("top-left"),suffix:"px"}),"top-right":Xe({ariaLabel:"Top-right radius",inputMode:"decimal",prefix:cr("top-right"),suffix:"px"}),"bottom-left":Xe({ariaLabel:"Bottom-left radius",inputMode:"decimal",prefix:cr("bottom-left"),suffix:"px"}),"bottom-right":Xe({ariaLabel:"Bottom-right radius",inputMode:"decimal",prefix:cr("bottom-right"),suffix:"px"})};$.append(x["top-left"].root,x["top-right"].root,x["bottom-left"].root,x["bottom-right"].root),j.append(E),T.append(P,j);const I={kind:"border-radius",property:"border-radius",root:T,unified:w,toggleButton:D,cornersGrid:$,corners:x,handle:null,expanded:!1,mode:null,cornersMaterialized:!1},N=document.createElement("div");N.className="we-field-row",d.style.flex="1",d.style.minWidth="0",T.style.flex="1",T.style.minWidth="0",N.append(d,T),Ye(o,g,{mode:"css-length"}),Ye(o,w.input,{mode:"css-length"});for(const Z of nn)Ye(o,x[Z].input,{mode:"css-length"});l.append(f,N,$,k,L,O,F),t.appendChild(l),o.add(()=>l.remove());const _=Ut({container:h,ariaLabel:"Border edge",columns:5,value:s,items:Cu.map(Z=>({value:Z,ariaLabel:Z,title:Z.charAt(0).toUpperCase()+Z.slice(1),icon:Tu(Z)})),onChange:Z=>{Z!==s&&(Y("border-width"),Y("border-style"),Y("border-color"),s=Z,me())}});o.add(()=>_.dispose());const M=Mn({container:V,ariaLabel:"Border Color",tokensService:r,getTokenTarget:()=>i,onInput:Z=>{const G=B("border-color");G&&G.set(Z)},onCommit:()=>{Y("border-color"),me()},onCancel:()=>{Q("border-color"),ne("border-color",!0)}});o.add(()=>M.dispose());const W=co({container:F,transactionManager:n,tokensService:r,property:"border-image-source",allowNone:!0});o.add(()=>W.dispose());const C={"border-width":{kind:"text",property:"border-width",element:g,handle:null},"border-style":{kind:"select",property:"border-style",element:v,handle:null},"border-color":{kind:"color",property:"border-color",field:M,handle:null},"border-radius":I},p=["border-width","border-style","border-color","border-radius"];function y(Z){return s==="all"?`border-${Z}`:`border-${s}-${Z}`}function R(Z){return Z==="border-width"?y("width"):Z==="border-style"?y("style"):Z==="border-color"?y("color"):Z}function B(Z){if(o.isDisposed)return null;const G=i;if(!G||!G.isConnected)return null;const K=C[Z];if(K.kind==="border-radius")return null;if(K.handle)return K.handle;const q=R(Z),de=n.beginStyle(G,q);return K.handle=de,de}function Y(Z){const G=C[Z];if(G.kind==="border-radius")return;const K=G.handle;G.handle=null,K&&K.commit({merge:!0})}function Q(Z){const G=C[Z];if(G.kind==="border-radius")return;const K=G.handle;G.handle=null,K&&K.rollback()}function te(){if(o.isDisposed)return null;const Z=C["border-radius"];if(Z.kind!=="border-radius")return null;const G=i;if(!G||!G.isConnected)return null;if(Z.handle)return Z.handle;const K=n.beginMultiStyle(G,[...Au]);return Z.handle=K,Z.mode=null,Z.cornersMaterialized=!1,K}function se(){const Z=C["border-radius"];if(Z.kind!=="border-radius")return;const G=Z.handle;Z.handle=null,Z.mode=null,Z.cornersMaterialized=!1,G&&G.commit({merge:!0})}function pe(){const Z=C["border-radius"];if(Z.kind!=="border-radius")return;const G=Z.handle;Z.handle=null,Z.mode=null,Z.cornersMaterialized=!1,G&&G.rollback()}function xe(){for(const Z of p)Y(Z);se()}function we(){O.hidden=a!=="solid",F.hidden=a!=="gradient"}function H(){const Z=!!(i&&i.isConnected);a==="gradient"&&(s!=="all"&&(Y("border-width"),Y("border-style"),Y("border-color"),s="all"),_.setValue("all")),_.setDisabled(!Z||a==="gradient")}function ae(Z){const G=i;if(a=Z,A.value=Z,we(),H(),!G||!G.isConnected)return;const K=n.beginMultiStyle(G,["border-image-source","border-image-slice"]);if(K){if(Z==="solid")K.set({"border-image-source":"none","border-image-slice":""});else{const q=xt(G,"border-image-source"),de=lt(G,"border-image-source"),oe=q||de,U=oe&&oe.trim()&&oe.trim().toLowerCase()!=="none"&&/\b(?:linear|radial|conic)-gradient\s*\(/i.test(oe)?oe:"linear-gradient(90deg, #000000, #ffffff)";K.set({"border-image-source":U,"border-image-slice":"1"})}K.commit({merge:!0})}}o.listen(A,"change",()=>{const Z=A.value;ae(Z),W.refresh(),me()});function ne(Z,G=!1){var oe,he;const K=C[Z],q=i,de=R(Z);if(K.kind==="border-radius"){const U=!!(q&&q.isConnected);K.unified.input.disabled=!U,K.toggleButton.disabled=!U;for(const ye of nn)K.corners[ye].input.disabled=!U;if(!U||!q){K.unified.input.value="",K.unified.input.placeholder="",K.unified.setSuffix("px");for(const ye of nn)K.corners[ye].input.value="",K.corners[ye].input.placeholder="",K.corners[ye].setSuffix("px");return}const ie=nn.some(ye=>lr(K.corners[ye].input));if((K.handle!==null||lr(K.unified.input)||ie)&&!G)return;const ge=xt(q,"border-radius");if(ge){const ye=bt(ge);K.unified.input.value=ye.value,K.unified.setSuffix(ye.suffix)}else{const ye=lt(q,vn["top-left"]),ke=lt(q,vn["top-right"]),We=lt(q,vn["bottom-right"]),Re=lt(q,vn["bottom-left"]),gt=ye===ke&&ye===We&&ye===Re?ye:lt(q,"border-radius"),ee=bt(gt);K.unified.input.value=ee.value,K.unified.setSuffix(ee.suffix)}K.unified.input.placeholder="";for(const ye of nn){const ke=vn[ye],We=xt(q,ke),Re=lt(q,ke),ee=bt(We||Re);K.corners[ye].input.value=ee.value,K.corners[ye].input.placeholder="",K.corners[ye].setSuffix(ee.suffix)}return}if(K.kind==="text"){const U=K.element;if(!q||!q.isConnected){U.disabled=!0,U.value="",U.placeholder="",Z==="border-width"&&S.setSuffix("px");return}if(U.disabled=!1,(K.handle!==null||lr(U))&&!G)return;const ve=xt(q,de),ge=lt(q,de);if(Z==="border-width"){const ye=bt(ve||ge);U.value=ye.value,S.setSuffix(ye.suffix)}else U.value=ve||ge;U.placeholder=""}else if(K.kind==="select"){const U=K.element;if(!q||!q.isConnected){U.disabled=!0;return}if(U.disabled=!1,(K.handle!==null||lr(U))&&!G)return;const ve=xt(q,de),ge=lt(q,de),ye=ve||ge,ke=Array.from(U.options).some(We=>We.value===ye);U.value=ke?ye:(he=(oe=U.options[0])==null?void 0:oe.value)!=null?he:""}else{const U=K.field;if(!q||!q.isConnected){U.setDisabled(!0),U.setValue(""),U.setPlaceholder("");return}if(U.setDisabled(!1),(K.handle!==null||U.isFocused())&&!G)return;const ve=xt(q,de),ge=lt(q,de);ve?(U.setValue(ve),U.setPlaceholder(/\bvar\s*\(/i.test(ve)?ge:"")):(U.setValue(ge),U.setPlaceholder(""))}}function me(){for(const G of p)ne(G);const Z=!!(i&&i.isConnected);A.disabled=!Z,we(),H()}function z(Z){const G=C[Z];if(G.kind!=="text")return;const K=G.element,q=()=>wt(K.value,S.getSuffixText());o.listen(K,"input",()=>{const de=B(Z);de&&de.set(q())}),o.listen(K,"blur",()=>{Y(Z),me()}),o.listen(K,"keydown",de=>{de.key==="Enter"?(de.preventDefault(),Y(Z),me(),K.blur()):de.key==="Escape"&&(de.preventDefault(),Q(Z),ne(Z,!0))})}function J(Z){const G=C[Z];if(G.kind!=="select")return;const K=G.element,q=()=>{const de=B(Z);de&&de.set(K.value)};o.listen(K,"input",q),o.listen(K,"change",q),o.listen(K,"blur",()=>{Y(Z),me()}),o.listen(K,"keydown",de=>{de.key==="Enter"?(de.preventDefault(),Y(Z),me(),K.blur()):de.key==="Escape"&&(de.preventDefault(),Q(Z),ne(Z,!0))})}function le(){const Z=C["border-radius"];if(Z.kind!=="border-radius")return;const G=oe=>{Z.expanded=oe,Z.cornersGrid.hidden=!oe,Z.toggleButton.setAttribute("aria-pressed",oe?"true":"false")};G(!1),o.listen(Z.toggleButton,"click",()=>{G(!Z.expanded)});const K=()=>{const oe=te();if(!oe)return;Z.mode="unified",Z.cornersMaterialized=!1;const he=wt(Z.unified.input.value,Z.unified.getSuffixText());oe.set({"border-top-left-radius":"","border-top-right-radius":"","border-bottom-right-radius":"","border-bottom-left-radius":"","border-radius":""}),oe.set({"border-radius":he})},q=oe=>{const he=i;if(!he||!he.isConnected)return;const U=te();if(!U)return;const ie=vn[oe],ve=Z.corners[oe],ge=wt(ve.input.value,ve.getSuffixText());if(Z.mode!=="corners"||!Z.cornersMaterialized){const ye={"border-radius":"","border-top-left-radius":xt(he,"border-top-left-radius")||lt(he,"border-top-left-radius"),"border-top-right-radius":xt(he,"border-top-right-radius")||lt(he,"border-top-right-radius"),"border-bottom-right-radius":xt(he,"border-bottom-right-radius")||lt(he,"border-bottom-right-radius"),"border-bottom-left-radius":xt(he,"border-bottom-left-radius")||lt(he,"border-bottom-left-radius")};ye[ie]=ge,U.set(ye),Z.mode="corners",Z.cornersMaterialized=!0;return}U.set({"border-radius":"",[ie]:ge})};o.listen(Z.unified.input,"input",K);for(const oe of nn)o.listen(Z.corners[oe].input,"input",()=>q(oe));o.listen(Z.root,"focusout",oe=>{const he=oe.relatedTarget;he instanceof Node&&Z.root.contains(he)||(se(),me())});const de=oe=>{o.listen(oe,"keydown",he=>{he.key==="Enter"?(he.preventDefault(),se(),me(),oe.blur()):he.key==="Escape"&&(he.preventDefault(),pe(),ne("border-radius",!0))})};de(Z.unified.input);for(const oe of nn)de(Z.corners[oe].input)}z("border-width"),J("border-style"),le();function be(Z){if(!o.isDisposed){if(Z!==i&&xe(),i=Z,Z&&Z.isConnected){const G=xt(Z,"border-image-source")||lt(Z,"border-image-source");a=rs(G)}else a="solid";A.value=a,a==="gradient"&&(s="all",_.setValue("all")),W.setTarget(Z),me()}}function Te(){if(o.isDisposed)return;const Z=i;if(Z&&Z.isConnected){const G=xt(Z,"border-image-source")||lt(Z,"border-image-source"),K=rs(G);K!==a&&(a=K,A.value=K,K==="gradient"&&(s="all",_.setValue("all")))}W.refresh(),me()}function Ne(){xe(),i=null,o.dispose()}return me(),{setTarget:be,refresh:Te,dispose:Ne}}const Ru=["solid","gradient","image"];function Iu(e){try{const t=e.getRootNode();return t instanceof ShadowRoot?t.activeElement===e:document.activeElement===e}catch(t){return!1}}function mo(e,t){var n,r,o;try{const i=e.style;return(o=(r=(n=i==null?void 0:i.getPropertyValue)==null?void 0:n.call(i,t))==null?void 0:r.trim())!=null?o:""}catch(i){return""}}function ho(e,t){try{return window.getComputedStyle(e).getPropertyValue(t).trim()}catch(n){return""}}function Lu(e){const t=e.trim().toLowerCase();return!t||t==="none"?"solid":/\b(?:linear|radial|conic)-gradient\s*\(/i.test(t)?"gradient":/\burl\s*\(/i.test(t)?"image":"solid"}function Mu(e){var n,r;const t=e.trim().match(/\burl\(\s*(['"]?)(.*?)\1\s*\)/i);return(r=(n=t==null?void 0:t[2])==null?void 0:n.trim())!=null?r:""}function Du(e){const t=e.trim();return t?/^none$/i.test(t)?"none":/^url\s*\(/i.test(t)?t:`url("${t.replace(/\\/g,"\\\\").replace(/"/g,'\\"')}")`:""}function Pu(e){const{container:t,transactionManager:n,tokensService:r}=e,o=new Pe;let i=null,s="solid";const a=document.createElement("div");a.className="we-field-group";function l(N,_){const M=document.createElement("div");M.className="we-field";const W=document.createElement("span");W.className="we-field-label",W.textContent=N;const C=document.createElement("input");return C.type="text",C.className="we-input",C.autocomplete="off",C.setAttribute("aria-label",_),M.append(W,C),{row:M,input:C}}function c(N){const _=document.createElement("div");_.className="we-field";const M=document.createElement("span");M.className="we-field-label",M.textContent=N;const W=document.createElement("div");return W.style.flex="1",W.style.minWidth="0",_.append(M,W),{row:_,colorFieldContainer:W}}const u=document.createElement("div");u.className="we-field";const f=document.createElement("span");f.className="we-field-label",f.textContent="Type";const m=document.createElement("select");m.className="we-select",m.setAttribute("aria-label","Background Type");for(const N of Ru){const _=document.createElement("option");_.value=N,_.textContent=N.charAt(0).toUpperCase()+N.slice(1),m.appendChild(_)}u.append(f,m);const{row:h,colorFieldContainer:d}=c("Color"),b=document.createElement("div"),{row:S,input:g}=l("URL","Background Image URL");g.placeholder="https://...",g.spellcheck=!1,a.append(u,h,b,S),t.appendChild(a),o.add(()=>a.remove());const k=co({container:b,transactionManager:n,tokensService:r});o.add(()=>k.dispose());const v=Mn({container:d,ariaLabel:"Background Color",tokensService:r,getTokenTarget:()=>i,onInput:N=>{const _=O("background-color");_&&_.set(N)},onCommit:()=>{V("background-color"),w()},onCancel:()=>{F("background-color"),E("background-color",!0)}});o.add(()=>v.dispose());const L={"background-color":{kind:"color",property:"background-color",field:v,handle:null},"background-image":{kind:"text",property:"background-image",element:g,handle:null}},A=["background-color","background-image"];function O(N){if(o.isDisposed)return null;const _=i;if(!_||!_.isConnected)return null;const M=L[N];if(M.handle)return M.handle;const W=n.beginStyle(_,N);return M.handle=W,W}function V(N){const _=L[N],M=_.handle;_.handle=null,M&&M.commit({merge:!0})}function F(N){const _=L[N],M=_.handle;_.handle=null,M&&M.rollback()}function T(){for(const N of A)V(N)}function P(){h.hidden=s!=="solid",b.hidden=s!=="gradient",S.hidden=s!=="image"}function j(N){const _=i;if(s=N,m.value=N,P(),!(!_||!_.isConnected)&&N==="solid"){V("background-image");const M=n.beginStyle(_,"background-image");M&&(M.set("none"),M.commit({merge:!0}))}}o.listen(m,"change",()=>{const N=m.value;j(N),k.refresh(),w()});function E(N,_=!1){const M=L[N],W=i;if(M.kind==="text"){const C=M.element;if(!W||!W.isConnected){C.disabled=!0,C.value="",C.placeholder="";return}if(C.disabled=!1,(M.handle!==null||Iu(C))&&!_)return;const y=mo(W,N),R=ho(W,N),B=y||R;N==="background-image"?C.value=Mu(B):C.value=B,C.placeholder=""}else{const C=M.field;if(!W||!W.isConnected){C.setDisabled(!0),C.setValue(""),C.setPlaceholder("");return}if(C.setDisabled(!1),(M.handle!==null||C.isFocused())&&!_)return;const y=mo(W,N),R=ho(W,N);y?(C.setValue(y),C.setPlaceholder(/\bvar\s*\(/i.test(y)?R:"")):(C.setValue(R),C.setPlaceholder(""))}}function w(){for(const _ of A)E(_);const N=!!(i&&i.isConnected);m.disabled=!N,P()}function D(N){const _=L[N];if(_.kind!=="text")return;const M=_.element,W=Du;o.listen(M,"input",()=>{const C=O(N);C&&C.set(W(M.value))}),o.listen(M,"blur",()=>{V(N),w()}),o.listen(M,"keydown",C=>{C.key==="Enter"?(C.preventDefault(),V(N),w(),M.blur()):C.key==="Escape"&&(C.preventDefault(),F(N),E(N,!0))})}D("background-image");function $(N){if(!o.isDisposed){if(N!==i&&T(),i=N,N&&N.isConnected){const _=mo(N,"background-image")||ho(N,"background-image");s=Lu(_),m.value=s}else s="solid",m.value="solid";k.setTarget(N),P(),w()}}function x(){o.isDisposed||(k.refresh(),w())}function I(){T(),i=null,o.dispose()}return P(),w(),{setTarget:$,refresh:x,dispose:I}}const Ou=/^-?(?:\d+\.?\d*|\.\d+)(?:[a-zA-Z%]+)?$/;function Fu(e){return/^[a-zA-Z_-]+\s*\(/.test(e)}function On(e){const t=e.trim();return!t||t.toLowerCase()==="none"?"":/^-?(?:\d+|\d*\.\d+)$/.test(t)?`${t}px`:/^-?\d+\.$/.test(t)?`${t.slice(0,-1)}px`:t}function rn(e,t){var n,r,o;try{const i=e.style;return(o=(r=(n=i==null?void 0:i.getPropertyValue)==null?void 0:n.call(i,t))==null?void 0:r.trim())!=null?o:""}catch(i){return""}}function os(e,t){const n=[];let r=0,o=null,i=!1,s=0;for(let a=0;a<e.length;a++){const l=e[a];if(i){i=!1;continue}if(l==="\\"){i=!0;continue}if(o){l===o&&(o=null);continue}if(l==='"'||l==="'"){o=l;continue}if(l==="("){r++;continue}if(l===")"){r=Math.max(0,r-1);continue}r===0&&l===t&&(n.push(e.slice(s,a)),s=a+1)}return n.push(e.slice(s)),n}function Bu(e){const t=[];let n=0,r=null,o=!1,i="";const s=()=>{const a=i.trim();a&&t.push(a),i=""};for(let a=0;a<e.length;a++){const l=e[a];if(o){i+=l,o=!1;continue}if(l==="\\"){i+=l,o=!0;continue}if(r){i+=l,l===r&&(r=null);continue}if(l==='"'||l==="'"){i+=l,r=l;continue}if(l==="("){n++,i+=l;continue}if(l===")"){n=Math.max(0,n-1),i+=l;continue}if(n===0&&/\s/.test(l)){s();continue}i+=l}return s(),t}function Vu(e){var a,l,c,u,f,m;const t=e.trim();if(!t||t.toLowerCase()==="none")return null;const n=(l=(a=os(t,",")[0])==null?void 0:a.trim())!=null?l:"";if(!n||n.toLowerCase()==="none")return null;const r=Bu(n);if(r.length===0)return null;let o=!1;const i=[],s=[];for(const h of r){if(/^inset$/i.test(h)){o=!0;continue}Ou.test(h)||Fu(h)&&i.length<4?i.push(h):s.push(h)}return i.length<2?null:{inset:o,offsetX:(c=i[0])!=null?c:"",offsetY:(u=i[1])!=null?u:"",blurRadius:(f=i[2])!=null?f:"",spreadRadius:(m=i[3])!=null?m:"",color:s.join(" ").trim()}}function is(e){const t=On(e.offsetX),n=On(e.offsetY),r=On(e.blurRadius),o=On(e.spreadRadius),i=e.color.trim();if(!t&&!n&&!r&&!o&&!i)return"";const s=[];return e.inset&&s.push("inset"),s.push(t||"0px",n||"0px"),(r||o)&&s.push(r||"0px"),o&&s.push(o),i&&s.push(i),s.join(" ")}function ss(e,t){const n=e,r=n.toLowerCase(),o=t.toLowerCase();let i=0;for(;i<n.length;){const s=r.indexOf(o,i);if(s<0)return null;if(s>0){const m=n[s-1];if(/[a-zA-Z0-9_-]/.test(m)){i=s+o.length;continue}}let a=s+o.length;for(;a<n.length&&/\s/.test(n[a]);)a++;if(n[a]!=="("){i=s+o.length;continue}const l=a;let c=0,u=null,f=!1;for(let m=l;m<n.length;m++){const h=n[m];if(f){f=!1;continue}if(h==="\\"){f=!0;continue}if(u){h===u&&(u=null);continue}if(h==='"'||h==="'"){u=h;continue}if(h==="("){c++;continue}if(h===")"){if(c--,c===0)return{start:s,end:m+1,args:n.slice(l+1,m)};continue}}return null}return null}function $u(e){const t=e.trim();if(!t||t.toLowerCase()==="none")return"";const n=ss(t,"blur");return n?n.args.trim():""}function ur(e,t){const n=e.trim().toLowerCase()==="none"?"":e.trim(),r=n?ss(n,"blur"):null,o=On(t);if(!o){if(!r)return n;const c=n.slice(0,r.start).trimEnd(),u=n.slice(r.end).trimStart();return c&&u?`${c} ${u}`.trim():(c||u).trim()}const i=`blur(${o})`;if(!r)return n?`${n} ${i}`.trim():i;const s=n.slice(0,r.start).trimEnd(),a=n.slice(r.end).trimStart(),l=[];return s&&l.push(s),l.push(i),a&&l.push(a),l.join(" ")}const Gt="http://www.w3.org/2000/svg",go="box-shadow",bo=[{value:"drop-shadow",label:"Drop Shadow",category:"shadow"},{value:"inner-shadow",label:"Inner Shadow",category:"shadow"},{value:"layer-blur",label:"Layer Blur",category:"blur"},{value:"backdrop-blur",label:"Backdrop Blur",category:"blur"}];let as=0;function Fn(){try{if(typeof crypto!="undefined"&&typeof crypto.randomUUID=="function")return crypto.randomUUID()}catch(e){}return as+=1,`shadow_${as}_${Date.now()}`}function Vt(e){return e.type==="drop-shadow"||e.type==="inner-shadow"}function on(e){return e.type==="layer-blur"||e.type==="backdrop-blur"}function ls(){return{id:Fn(),enabled:!0,type:"drop-shadow",kind:"parsed",inset:!1,offsetX:"0px",offsetY:"4px",blurRadius:"12px",spreadRadius:"0px",color:"rgba(0, 0, 0, 0.15)"}}function Hu(e){return{id:Fn(),enabled:!0,type:e,kind:"parsed",radius:"8px"}}function wo(e){const t=bo.find(n=>n.value===e.type);return t?t.label:e.kind==="raw"?"Custom Effect":"Unknown Effect"}function cs(e){if(e.kind==="raw")return`raw:${e.property}:${e.rawText.trim()}`;if(Vt(e)){const t=is({inset:e.inset,offsetX:e.offsetX,offsetY:e.offsetY,blurRadius:e.blurRadius,spreadRadius:e.spreadRadius,color:e.color});return`shadow:${e.type}:${t.toLowerCase()}`}return`blur:${e.type}:${e.radius}`}function zu(e){const t=e.trim();if(!t||t.toLowerCase()==="none")return[];const n=os(t,",").map(o=>o.trim()).filter(Boolean),r=[];for(const o of n){const i=Vu(o);i?r.push({id:Fn(),enabled:!0,type:i.inset?"inner-shadow":"drop-shadow",kind:"parsed",inset:i.inset,offsetX:i.offsetX,offsetY:i.offsetY,blurRadius:i.blurRadius,spreadRadius:i.spreadRadius,color:i.color}):r.push({id:Fn(),enabled:!0,type:"raw",kind:"raw",property:"box-shadow",rawText:o})}return r}function us(e,t){const n=$u(e);return n?{id:Fn(),enabled:!0,type:t,kind:"parsed",radius:n}:null}function ds(e){return e.filter(n=>n.enabled&&(Vt(n)||n.kind==="raw"&&n.property==="box-shadow")).map(n=>n.kind==="raw"?n.rawText.trim():Vt(n)?is({inset:n.inset,offsetX:n.offsetX,offsetY:n.offsetY,blurRadius:n.blurRadius,spreadRadius:n.spreadRadius,color:n.color}):"").map(n=>n.trim()).filter(Boolean).join(", ")}function dr(e,t){const n=e.find(r=>r.type===t&&r.enabled);return n&&on(n)?n:null}function Uu(e,t){var s;const n=new Set,r=new Map;for(const a of e){const l=cs(a),c=(s=r.get(l))!=null?s:[];c.push(a),r.set(l,c)}const o=t.map(a=>{const l=cs(a),c=r.get(l),u=c==null?void 0:c.shift();return u?(n.add(u.id),mt(je({},a),{id:u.id,enabled:!0})):a}),i=e.filter(a=>!a.enabled&&!n.has(a.id));return[...o,...i]}function xo(e,t="0 0 24 24"){const n=document.createElementNS(Gt,"svg");n.setAttribute("viewBox",t),n.setAttribute("fill","none"),n.setAttribute("aria-hidden","true");const r=document.createElementNS(Gt,"path");return r.setAttribute("d",e),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","2"),r.setAttribute("stroke-linecap","round"),r.setAttribute("stroke-linejoin","round"),n.append(r),n}function Gu(){return xo("M12 5v14M5 12h14")}function Wu(){return xo("M9 6h6M10 6l.5-1.5h3L14 6M7 6l1 14h8l1-14")}function Xu(){const e=document.createElementNS(Gt,"svg");e.setAttribute("viewBox","0 0 20 20"),e.setAttribute("fill","none"),e.setAttribute("aria-hidden","true");const t=document.createElementNS(Gt,"path");t.setAttribute("d","M4 5H16 M4 10H16 M4 15H16"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","2"),t.setAttribute("stroke-linecap","round"),t.setAttribute("stroke-linejoin","round"),e.append(t);const n=[[7,5],[13,10],[9,15]];for(const[r,o]of n){const i=document.createElementNS(Gt,"circle");i.setAttribute("cx",String(r)),i.setAttribute("cy",String(o)),i.setAttribute("r","1.6"),i.setAttribute("fill","none"),i.setAttribute("stroke","currentColor"),i.setAttribute("stroke-width","2"),e.append(i)}return e}function fr(e){if(e){const t=document.createElementNS(Gt,"svg");t.setAttribute("viewBox","0 0 24 24"),t.setAttribute("fill","none"),t.setAttribute("aria-hidden","true");const n=document.createElementNS(Gt,"path");n.setAttribute("d","M2.5 12s3.5-7 9.5-7 9.5 7 9.5 7-3.5 7-9.5 7-9.5-7-9.5-7z"),n.setAttribute("stroke","currentColor"),n.setAttribute("stroke-width","2"),n.setAttribute("stroke-linecap","round"),n.setAttribute("stroke-linejoin","round");const r=document.createElementNS(Gt,"circle");return r.setAttribute("cx","12"),r.setAttribute("cy","12"),r.setAttribute("r","3"),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","2"),t.append(n,r),t}return xo("M3 3l18 18M10.6 10.6A3 3 0 0012 15a3 3 0 002.4-4.4M9.5 5.8A10.7 10.7 0 0112 5c6 0 9.5 7 9.5 7a17.4 17.4 0 01-3.1 4.1M6.2 6.2A17.8 17.8 0 002.5 12s3.5 7 9.5 7c1 0 1.9-.2 2.8-.5")}function yo(e){const t=document.createElement("button");return t.type="button",t.className="we-effects-icon-btn",t.setAttribute("aria-label",e),t}function Yu(e){return e.kind==="raw"?"raw":Vt(e)?"shadow":on(e)?"blur":"raw"}function ju(e){const{container:t,transactionManager:n,tokensService:r,headerActionsContainer:o}=e,i=new Pe,s=new WeakMap;let a=null,l=[],c=new Map,u=null,f=null,m=null;const h=document.createElement("div");h.className="we-field-group we-effects",t.append(h),i.add(()=>h.remove());const d=document.createElement("button");if(d.type="button",d.className="we-effects-icon-btn",d.setAttribute("aria-label","Add effect"),d.append(Gu()),o)o.insertBefore(d,o.firstChild),i.add(()=>d.remove());else{const p=document.createElement("div");p.className="we-effects-toolbar",p.append(d),h.append(p)}const b=document.createElement("div");b.className="we-effects-list",h.append(b);const S=new Map;function g(p){l=p,c=new Map(p.map(R=>[R.id,R]));const y=a;y&&s.set(y,p)}function k(p){var y;return(y=c.get(p))!=null?y:null}function v(p){if(i.isDisposed)return null;const y=a;return!y||!y.isConnected?null:(f&&m===p||(f&&f.commit({merge:!0}),f=n.beginStyle(y,p),m=p),f)}function L(){const p=f;f=null,m=null,p&&p.commit({merge:!0})}function A(){const p=f;f=null,m=null,p&&p.rollback()}function O(){return f!==null||u!==null}function V(){const p=a;if(!p||!p.isConnected)return;const y=v(go);y&&y.set(ds(l));const R=dr(l,"layer-blur");if(R){const Y=v("filter");if(Y){const Q=rn(p,"filter");Y.set(ur(Q,R.radius))}}const B=dr(l,"backdrop-blur");if(B){const Y=v("backdrop-filter");if(Y){const Q=rn(p,"backdrop-filter");Y.set(ur(Q,B.radius))}}}function F(){var Q,te;const p=a;if(!p||!p.isConnected)return;L(),n.applyStyle(p,go,ds(l),{merge:!1});const y=dr(l,"layer-blur"),R=rn(p,"filter");n.applyStyle(p,"filter",ur(R,(Q=y==null?void 0:y.radius)!=null?Q:""),{merge:!1});const B=dr(l,"backdrop-blur"),Y=rn(p,"backdrop-filter");n.applyStyle(p,"backdrop-filter",ur(Y,(te=B==null?void 0:B.radius)!=null?te:""),{merge:!1})}function T(p){var Y,Q;const y=(Y=p==null?void 0:p.commit)!=null?Y:!1,R=(Q=p==null?void 0:p.rollback)!=null?Q:!1;R?A():y&&L();const B=u!==null;u=null;for(const te of S.values())te.setOpen(!1);B&&!R&&x(!0)}function P(p){if(p===u){T({commit:!0});return}if(T({commit:!0}),!p)return;const y=S.get(p);if(y){u=p;for(const[R,B]of S)B.setOpen(R===p);y.focusFirst()}}function j(p,y){const R=bt(y);p.input.value=R.value,p.setSuffix(R.suffix)}function E(p,y){var te,se,pe,xe,we,H;if(p.kind==="raw")return null;if(y==="layer-blur"||y==="backdrop-blur"){const ae=Hu(y),ne=on(p)?p.radius:Vt(p)?p.blurRadius:ae.radius;return mt(je({},ae),{id:p.id,enabled:p.enabled,radius:ne||ae.radius})}const R=ls(),B=Vt(p)?p:null,Y=on(p)?p:null,Q=(se=(te=B==null?void 0:B.blurRadius)!=null?te:Y==null?void 0:Y.radius)!=null?se:R.blurRadius;return mt(je({},R),{id:p.id,enabled:p.enabled,type:y,inset:y==="inner-shadow",offsetX:(pe=B==null?void 0:B.offsetX)!=null?pe:R.offsetX,offsetY:(xe=B==null?void 0:B.offsetY)!=null?xe:R.offsetY,blurRadius:Q||R.blurRadius,spreadRadius:(we=B==null?void 0:B.spreadRadius)!=null?we:R.spreadRadius,color:(H=B==null?void 0:B.color)!=null?H:R.color})}function w(p,y){var Q;const R=k(p);if(!R||R.kind==="raw"||R.type===y)return;const B=E(R,y);if(!B)return;let Y=l.map(te=>te.id===p?B:te);(B.type==="layer-blur"||B.type==="backdrop-blur")&&(Y=Y.filter(te=>te.id===p||te.type!==B.type)),g(Y),$(),F(),u===p&&((Q=S.get(p))==null||Q.focusFirst())}function D(p){const y=new Pe,R=document.createElement("div");R.className="we-effects-item-wrap";const B=document.createElement("div");B.className="we-effects-item",B.dataset.enabled=p.enabled?"true":"false",B.dataset.open="false";const Y=yo("Adjust effect");Y.append(Xu());const Q=document.createElement("button");Q.type="button",Q.className="we-effects-name";const te=yo("Toggle visibility"),se=yo("Remove effect");se.append(Wu()),B.append(Y,Q,te,se);const pe=document.createElement("div");if(pe.className="we-effects-popover",pe.hidden=!0,R.append(B,pe),y.listen(Y,"click",oe=>{oe.preventDefault(),oe.stopPropagation(),P(p.id)}),y.listen(Q,"click",oe=>{oe.preventDefault(),oe.stopPropagation(),P(p.id)}),y.listen(te,"click",oe=>{oe.preventDefault(),oe.stopPropagation();const he=k(p.id);he&&(he.enabled=!he.enabled,B.dataset.enabled=he.enabled?"true":"false",te.replaceChildren(fr(he.enabled)),F())}),y.listen(se,"click",oe=>{var he;oe.preventDefault(),oe.stopPropagation(),u===p.id&&T({commit:!0}),g(l.filter(U=>U.id!==p.id)),(he=S.get(p.id))==null||he.dispose(),S.delete(p.id),$(),F()}),p.kind==="raw"){const oe=document.createElement("div");oe.className="we-effects-popover-content";const he=document.createElement("div");he.className="we-field";const U=document.createElement("span");U.className="we-field-label",U.textContent="Value";const ie=document.createElement("input");return ie.type="text",ie.className="we-input",ie.autocomplete="off",ie.spellcheck=!1,ie.setAttribute("aria-label","Shadow value"),he.append(U,ie),oe.append(he),pe.append(oe),y.listen(ie,"input",()=>{const ge=k(p.id);!ge||ge.kind!=="raw"||(ge.rawText=ie.value,V())}),y.listen(ie,"blur",()=>{L()}),y.listen(ie,"keydown",ge=>{ge.key==="Enter"?(ge.preventDefault(),L(),ie.blur()):ge.key==="Escape"&&(ge.preventDefault(),T({rollback:!0}),x(!0))}),{id:p.id,viewType:"raw",root:R,row:B,adjustBtn:Y,nameBtn:Q,eyeBtn:te,deleteBtn:se,popover:pe,rawInput:ie,disposer:y,setOpen(ge){B.dataset.open=ge?"true":"false",pe.hidden=!ge},focusFirst(){ie.focus(),ie.select()},sync(ge){B.dataset.enabled=ge.enabled?"true":"false",Q.textContent=wo(ge),te.replaceChildren(fr(ge.enabled)),ge.kind==="raw"&&(ie.value=ge.rawText)},dispose(){y.dispose(),R.remove()}}}if(on(p)){const oe=document.createElement("div");oe.className="we-effects-popover-content";const he=document.createElement("div");he.className="we-field";const U=document.createElement("span");U.className="we-field-label",U.textContent="Type";const ie=document.createElement("select");ie.className="we-select",ie.setAttribute("aria-label","Effect type");for(const Re of bo){const gt=document.createElement("option");gt.value=Re.value,gt.textContent=Re.label,ie.append(gt)}he.append(U,ie);const ve=document.createElement("div");ve.className="we-field";const ge=document.createElement("span");ge.className="we-field-label",ge.textContent="Blur";const ye=Xe({ariaLabel:"Blur radius",inputMode:"decimal",suffix:"px"});ve.append(ge,ye.root),oe.append(he,ve),pe.append(oe),Ye(y,ye.input,{mode:"css-length",min:0,step:1,shiftStep:10,altStep:.1}),y.listen(ye.input,"input",()=>{const Re=k(p.id);!Re||!on(Re)||(Re.radius=wt(ye.input.value,ye.getSuffixText()),V())}),y.listen(ye.input,"blur",()=>{L(),x(!0)}),y.listen(ye.input,"keydown",Re=>{Re.key==="Enter"?(Re.preventDefault(),L(),x(!0),ye.input.blur()):Re.key==="Escape"&&(Re.preventDefault(),T({rollback:!0}),x(!0))});const ke=()=>{w(p.id,ie.value)};return y.listen(ie,"input",ke),y.listen(ie,"change",ke),{id:p.id,viewType:"blur",root:R,row:B,adjustBtn:Y,nameBtn:Q,eyeBtn:te,deleteBtn:se,popover:pe,disposer:y,typeSelect:ie,radiusInput:ye,setOpen(Re){B.dataset.open=Re?"true":"false",pe.hidden=!Re},focusFirst(){ye.input.focus(),ye.input.select()},sync(Re){B.dataset.enabled=Re.enabled?"true":"false",Q.textContent=wo(Re),te.replaceChildren(fr(Re.enabled)),on(Re)&&(ie.value=Re.type,j(ye,Re.radius))},dispose(){y.dispose(),R.remove()}}}const xe=document.createElement("div");xe.className="we-effects-popover-content";const we=document.createElement("div");we.className="we-field";const H=document.createElement("span");H.className="we-field-label",H.textContent="Type";const ae=document.createElement("select");ae.className="we-select",ae.setAttribute("aria-label","Effect type");for(const oe of bo){const he=document.createElement("option");he.value=oe.value,he.textContent=oe.label,ae.append(he)}we.append(H,ae);const ne=document.createElement("div");ne.className="we-field-row";const me=Xe({ariaLabel:"Shadow offset X",inputMode:"decimal",prefix:"X",suffix:"px"}),z=Xe({ariaLabel:"Shadow offset Y",inputMode:"decimal",prefix:"Y",suffix:"px"});ne.append(me.root,z.root);const J=document.createElement("div");J.className="we-field-row";const le=Xe({ariaLabel:"Shadow blur radius",inputMode:"decimal",prefix:"B",suffix:"px"}),be=Xe({ariaLabel:"Shadow spread radius",inputMode:"decimal",prefix:"S",suffix:"px"});J.append(le.root,be.root);const Te=document.createElement("div");Te.className="we-field";const Ne=document.createElement("span");Ne.className="we-field-label",Ne.textContent="Color";const Z=document.createElement("div");Z.style.minWidth="0",Te.append(Ne,Z),xe.append(we,ne,J,Te),pe.append(xe),Ye(y,me.input,{mode:"css-length"}),Ye(y,z.input,{mode:"css-length"}),Ye(y,le.input,{mode:"css-length",min:0,step:1,shiftStep:10,altStep:.1}),Ye(y,be.input,{mode:"css-length",step:1,shiftStep:10,altStep:.1});const G=Mn({container:Z,ariaLabel:"Shadow color",tokensService:r,getTokenTarget:()=>a,onInput:oe=>{const he=k(p.id);!he||!Vt(he)||(he.color=oe,V())},onCommit:()=>{L()},onCancel:()=>{A(),x(!0)}});y.add(()=>G.dispose());const K=(oe,he)=>{y.listen(oe.input,"input",()=>{const U=k(p.id);if(!U||!Vt(U))return;const ie=wt(oe.input.value,oe.getSuffixText());U[he]=ie,V()}),y.listen(oe.input,"blur",()=>{L(),x(!0)}),y.listen(oe.input,"keydown",U=>{U.key==="Enter"?(U.preventDefault(),L(),x(!0),oe.input.blur()):U.key==="Escape"&&(U.preventDefault(),A(),x(!0))})};K(me,"offsetX"),K(z,"offsetY"),K(le,"blurRadius"),K(be,"spreadRadius");const q=()=>{w(p.id,ae.value)};return y.listen(ae,"input",q),y.listen(ae,"change",q),{id:p.id,viewType:"shadow",root:R,row:B,adjustBtn:Y,nameBtn:Q,eyeBtn:te,deleteBtn:se,popover:pe,disposer:y,typeSelect:ae,offsetX:me,offsetY:z,blur:le,spread:be,colorField:G,setOpen(oe){B.dataset.open=oe?"true":"false",pe.hidden=!oe},focusFirst(){ae.focus()},sync(oe){B.dataset.enabled=oe.enabled?"true":"false",Q.textContent=wo(oe),te.replaceChildren(fr(oe.enabled)),Vt(oe)&&(ae.value=oe.type,j(me,oe.offsetX),j(z,oe.offsetY),j(le,oe.blurRadius),j(be,oe.spreadRadius),G.setValue(oe.color))},dispose(){y.dispose(),R.remove()}}}function $(){const p=new Set(l.map(y=>y.id));for(const[y,R]of Array.from(S.entries()))p.has(y)||(u===y&&(u=null),R.dispose(),S.delete(y));for(const y of l){const R=S.get(y.id),B=Yu(y);(!R||R.viewType!==B)&&(R==null||R.dispose(),S.set(y.id,D(y)));const Y=S.get(y.id);Y.sync(y),Y.setOpen(u===y.id),b.append(Y.root)}}function x(p=!1){var we;const y=a;if(!y||!y.isConnected){d.disabled=!0,g([]),T({commit:!0}),$();return}if(d.disabled=!1,!p&&O())return;const R=rn(y,go),B=zu(R),Y=rn(y,"filter"),Q=us(Y,"layer-blur"),te=rn(y,"backdrop-filter"),se=us(te,"backdrop-blur"),pe=[...B,...Q?[Q]:[],...se?[se]:[]],xe=(we=s.get(y))!=null?we:[];g(Uu(xe,pe)),$()}i.listen(d,"click",p=>{p.preventDefault(),p.stopPropagation();const y=a;if(!y||!y.isConnected)return;T({commit:!0});const R=ls(),B=[...l,R];g(B),$(),F(),P(R.id)});const I=p=>{const y=u;if(!y)return;const R=S.get(y);if(!R)return;const B=typeof p.composedPath=="function"?p.composedPath():[];(B.length>0?B.includes(R.root):(()=>{const Q=p.target;return!!(Q&&R.root.contains(Q))})())||T({commit:!0})},N=h.ownerDocument;N.addEventListener("click",I,!0),i.add(()=>N.removeEventListener("click",I,!0));const _=p=>{p.key==="Escape"&&u&&(p.preventDefault(),p.stopPropagation(),T({rollback:!0}),x(!0))};h.addEventListener("keydown",_,!0),i.add(()=>h.removeEventListener("keydown",_,!0));function M(p){var y;i.isDisposed||(p!==a&&(L(),T({commit:!0})),a=p,p&&p.isConnected?g((y=s.get(p))!=null?y:[]):g([]),x(!0))}function W(){i.isDisposed||x(!1)}function C(){L(),a=null;for(const p of S.values())p.dispose();S.clear(),i.dispose()}return x(!0),{setTarget:M,refresh:W,dispose:C}}const Ku=10,qu=20,Zu=2,vo=20;function Eo(e){var s,a,l,c;const t=e.tagName.toLowerCase(),n=e;let r=t;const o=(s=n.id)==null?void 0:s.trim();o&&(r+=`#${o}`);const i=Array.from((a=e.classList)!=null?a:[]).slice(0,Zu).filter(Boolean);if(i.length>0&&(r+=`.${i.join(".")}`),!e.children.length){const u=(c=(l=e.textContent)==null?void 0:l.trim())!=null?c:"";u.length>0&&u.length<=vo?r+=` "${u}"`:u.length>vo&&(r+=` "${u.slice(0,vo-3)}..."`)}return r}function Qu(e){const t=[];let n=e.parentElement;for(;n&&t.length<Ku;){if(n===document.body||n===document.documentElement){t.unshift(n);break}if(n.shadowRoot)break;t.unshift(n),n=n.parentElement}return t}function Ju(e){return Array.from(e.children).slice(0,qu)}function ed(e){if(!e||!e.isConnected)return[];const t=[],n=Qu(e);for(let i=0;i<n.length;i++)t.push({element:n[i],label:Eo(n[i]),depth:i,isSelected:!1,isAncestor:!0,isChild:!1});const r=n.length;t.push({element:e,label:Eo(e),depth:r,isSelected:!0,isAncestor:!1,isChild:!1});const o=Ju(e);for(const i of o)t.push({element:i,label:Eo(i),depth:r+1,isSelected:!1,isAncestor:!1,isChild:!0});return t}function td(e){const{container:t,onSelect:n}=e,r=new Pe;let o=null;const i=document.createElement("div");i.className="we-tree";const s=document.createElement("div");s.className="we-tree-empty",s.textContent="Select an element to view its DOM hierarchy.";const a=document.createElement("div");a.className="we-tree-list",a.setAttribute("role","tree"),i.append(s,a),t.append(i),r.add(()=>i.remove());function l(){const m=ed(o),h=m.length>0;if(s.hidden=h,a.hidden=!h,!h){a.innerHTML="";return}a.innerHTML="";for(const d of m){const b=document.createElement("div");if(b.className="we-tree-item",b.setAttribute("role","treeitem"),b.style.paddingLeft=`${8+d.depth*16}px`,d.isSelected&&(b.classList.add("we-tree-item--selected"),b.setAttribute("aria-selected","true")),d.isAncestor&&b.classList.add("we-tree-item--ancestor"),d.isChild&&b.classList.add("we-tree-item--child"),d.depth>0){const k=document.createElement("span");k.className="we-tree-indent",k.textContent=d.isChild?"└":"├",b.append(k)}const S=document.createElement("span");S.className="we-tree-icon",S.textContent="◇",b.append(S);const g=document.createElement("span");g.className="we-tree-label",g.textContent=d.label,b.append(g),r.listen(b,"click",k=>{k.preventDefault(),k.stopPropagation(),d.element.isConnected&&n&&n(d.element)}),r.listen(b,"mouseenter",()=>{d.element.isConnected&&d.element.classList.add("we-tree-hover-highlight")}),r.listen(b,"mouseleave",()=>{d.element.classList.remove("we-tree-hover-highlight")}),a.append(b)}}function c(m){r.isDisposed||(o=m,l())}function u(){r.isDisposed||l()}function f(){o=null,r.dispose()}return l(),{setTarget:c,refresh:u,dispose:f}}const nd=8,rd=400;function fs(e){const t=[],n=new Set;for(const r of e!=null?e:[]){const o=String(r!=null?r:"").trim();o&&(n.has(o)||(n.add(o),t.push(o)))}return t}function od(e,t){if(e.length!==t.length)return!1;for(let n=0;n<e.length;n++)if(e[n]!==t[n])return!1;return!0}function ps(e){return String(e!=null?e:"").split(/\s+/).map(t=>t.trim()).filter(Boolean)}function ms(e){var t;try{const n=e.classList;if(n&&typeof n[Symbol.iterator]=="function")return Array.from(n).filter(Boolean)}catch(n){}try{return((t=e.getAttribute("class"))!=null?t:"").split(/\s+/).map(r=>r.trim()).filter(Boolean)}catch(n){return[]}}function id(e){const{container:t,onClassChange:n,getSuggestions:r}=e,o=new Pe;let i=null,s=[],a=!1;const l=document.createElement("div");l.className="we-class-editor",l.setAttribute("role","group"),l.setAttribute("aria-label","Class editor");const c=document.createElement("div");c.className="we-class-chips";const u=document.createElement("input");u.type="text",u.className="we-input we-class-input",u.autocomplete="off",u.spellcheck=!1,u.placeholder="Add class",u.setAttribute("aria-label","Add class");const f=document.createElement("div");f.className="we-class-suggestions",f.hidden=!0,l.append(c,u,f),t.append(l),o.add(()=>l.remove());function m(){c.innerHTML="";for(const T of s){const P=document.createElement("span");P.className="we-class-chip";const j=document.createElement("span");j.className="we-class-chip-text",j.textContent=T;const E=document.createElement("button");E.type="button",E.className="we-class-chip-remove",E.textContent="×",E.dataset.action="remove",E.dataset.value=T,E.setAttribute("aria-label",`Remove class ${T}`),P.append(j,E),c.append(P)}}function h(){f.hidden=!0,f.innerHTML=""}function d(){var D;if(u.disabled){h();return}const T=u.value.trim();if(!T){h();return}const P=(D=r==null?void 0:r())!=null?D:[];if(!Array.isArray(P)||P.length===0){h();return}const j=new Set(s),E=new Set,w=[];for(const $ of P){const x=String($!=null?$:"").trim();if(x&&!j.has(x)&&x.startsWith(T)&&!E.has(x)&&(E.add(x),w.push(x),w.length>=nd))break}if(w.length===0){h();return}f.hidden=!1,f.innerHTML="";for(const $ of w){const x=document.createElement("button");x.type="button",x.className="we-class-suggestion",x.textContent=$,x.dataset.action="suggestion",x.dataset.value=$,f.append(x)}}function b(T){s=fs(T),m(),d()}function S(T){if(!i||!i.isConnected)return;const P=fs(T);if(od(P,s)){d();return}s=P,m(),d(),n(s.slice())}function g(T){if(!T.length)return;const P=s.slice(),j=new Set(P);for(const E of T){const w=String(E!=null?E:"").trim();w&&(j.has(w)||(j.add(w),P.push(w)))}S(P)}function k(T){const P=String(T!=null?T:"").trim();if(!P)return;const j=s.filter(E=>E!==P);S(j)}function v(){s.length!==0&&S(s.slice(0,-1))}function L(){const T=ps(u.value);T.length!==0&&(g(T),u.value="",d())}o.listen(f,"mousedown",T=>{T.preventDefault()}),o.listen(c,"click",T=>{var w,D;const P=T.target,j=(w=P==null?void 0:P.closest)==null?void 0:w.call(P,'button[data-action="remove"]'),E=(D=j==null?void 0:j.dataset)==null?void 0:D.value;!j||!E||(T.preventDefault(),k(E))}),o.listen(f,"click",T=>{var w,D;const P=T.target,j=(w=P==null?void 0:P.closest)==null?void 0:w.call(P,'button[data-action="suggestion"]'),E=(D=j==null?void 0:j.dataset)==null?void 0:D.value;!j||!E||(T.preventDefault(),g([E]),u.value="",d(),u.focus())}),o.listen(u,"compositionstart",()=>{a=!0}),o.listen(u,"compositionend",()=>{a=!1,d()}),o.listen(u,"input",()=>{d()}),o.listen(u,"blur",()=>{h()}),o.listen(u,"paste",()=>{window.setTimeout(()=>{if(o.isDisposed)return;ps(u.value).length>1?L():d()},0)}),o.listen(u,"keydown",T=>{if(!u.disabled){if(T.key==="Enter"){if(a)return;T.preventDefault(),L();return}if(T.key===" "){if(a)return;u.value.trim()&&(T.preventDefault(),L());return}if(T.key==="Backspace"){!u.value&&s.length>0&&(T.preventDefault(),v());return}T.key==="Escape"&&(f.hidden?u.value&&(T.preventDefault(),u.value="",d()):(T.preventDefault(),h()))}});function A(T){if(!o.isDisposed){if(i=T&&T.isConnected?T:null,u.value="",h(),u.disabled=!i,!i){b([]);return}b(ms(i))}}function O(T){o.isDisposed||b(T)}function V(){if(o.isDisposed)return;const T=i;if(!T||!T.isConnected){A(null);return}b(ms(T))}function F(){i=null,s=[],o.dispose()}return A(null),{setTarget:A,setClasses:O,refresh:V,dispose:F}}function So(e){return String(e!=null?e:"").trim().toLowerCase()}function hs(e){return String(e!=null?e:"").trim()}function sd(){let e=!1,t=null;const n=new Map,r=new Map;function o(){var h,d;if(e||typeof document=="undefined")return null;if((h=t==null?void 0:t.host)!=null&&h.isConnected)return t;const c=(d=document.documentElement)!=null?d:document.body;if(!c)return null;const u=document.createElement("div");u.setAttribute("aria-hidden","true"),u.style.cssText="all: initial;display: block;position: fixed;left: -100000px;top: 0;width: 100px;height: 100px;overflow: hidden;pointer-events: none;contain: layout style paint;z-index: -1;visibility: hidden;";const f=u.attachShadow({mode:"open"}),m=document.createElement("div");return m.style.cssText="all: initial; display: block;",f.append(m),c.append(u),t={host:u,shadow:f,container:m},t}function i(c){const u=So(c);if(!u)return null;const f=n.get(u);if(f!=null&&f.isConnected)return f;const m=o();if(!m)return null;let h;try{h=document.createElement(u)}catch(d){h=document.createElement("div")}return m.container.append(h),n.set(u,h),h}function s(c,u){var g,k;const f=So(c);if(!f)return;const m=(u!=null?u:[]).map(v=>hs(v)).filter(Boolean);if(m.length===0)return;const h=(g=r.get(f))!=null?g:new Map;r.has(f)||r.set(f,h);const d=[];for(const v of m)h.has(v)||d.push(v);if(d.length===0)return;const b=i(f);if(!b)return;let S=null;try{S=window.getComputedStyle(b)}catch(v){S=null}if(!S){for(const v of d)h.set(v,"");return}for(const v of d){let L="";try{L=String((k=S.getPropertyValue(v))!=null?k:"").trim()}catch(A){L=""}h.set(v,L)}}function a(c,u){var h,d;const f=So(c),m=hs(u);return!f||!m?"":(s(f,[m]),(d=(h=r.get(f))==null?void 0:h.get(m))!=null?d:"")}function l(){var c;e=!0;try{(c=t==null?void 0:t.host)==null||c.remove()}catch(u){}t=null,n.clear(),r.clear()}return{ensureBaselineValues:s,getBaselineValue:a,dispose:l}}const pr=[0,0,0,0];function mr(e,t){for(let n=0;n<4;n++)if(e[n]!==t[n])return e[n]>t[n]?1:-1;return 0}function hr(e){const t=[];let n=0,r=0,o=0,i=null;for(let a=0;a<e.length;a++){const l=e[a];if(i){if(l==="\\"){a+=1;continue}l===i&&(i=null);continue}if(l==='"'||l==="'"){i=l;continue}if(l==="\\"){a+=1;continue}if(l==="["?o+=1:l==="]"&&o>0?o-=1:l==="("?r+=1:l===")"&&r>0&&(r-=1),l===","&&r===0&&o===0){const c=e.slice(n,a).trim();c&&t.push(c),n=a+1}}const s=e.slice(n).trim();return s&&t.push(s),t}function ko(e){let t=pr;for(const n of e)mr(n,t)>0&&(t=n);return t}function gr(e){let t=0,n=0,r=0,o=!0;for(let i=0;i<e.length;i++){const s=e[i];if(s==="\\"){i+=1;continue}if(s==="["){n+=1,i=gs(e,i),o=!1;continue}if(ud(e,i)){i=dd(e,i),o=!0;continue}if(s==="#"){t+=1,i=Bn(e,i+1)-1,o=!1;continue}if(s==="."){n+=1,i=Bn(e,i+1)-1,o=!1;continue}if(s===":"){if(e[i+1]===":"){r+=1;const f=i+2,m=Bn(e,f),h=e.slice(f,m).toLowerCase();if(i=m-1,e[i+1]==="("&&h==="slotted"){const{content:d,endIndex:b}=bs(e,i+1),S=ko(hr(d).map(gr));t+=S[1],n+=S[2],r+=S[3],i=b}o=!1;continue}const l=i+1,c=Bn(e,l),u=e.slice(l,c).toLowerCase();if(ld.has(u)){r+=1,i=c-1,o=!1;continue}if(e[c]==="("){const{content:f,endIndex:m}=bs(e,c);if(i=m,u==="where"){o=!1;continue}if(u==="is"||u==="not"||u==="has"){const h=ko(hr(f).map(gr));t+=h[1],n+=h[2],r+=h[3],o=!1;continue}if(u==="nth-child"||u==="nth-last-child"){n+=1;const h=fd(f);if(h){const d=ko(hr(h).map(gr));t+=d[1],n+=d[2],r+=d[3]}o=!1;continue}n+=1,o=!1;continue}n+=1,i=c-1,o=!1;continue}if(o){if(s==="*"){o=!1;continue}if(cd(s)){r+=1,i=Bn(e,i+1)-1,o=!1;continue}}}return[0,t,n,r]}function ad(e,t){const n=hr(t);let r=null,o=pr;for(const i of n)try{if(!e.matches(i))continue;const s=gr(i);(!r||mr(s,o)>0)&&(r=i,o=s)}catch(s){}return r?{matchedSelector:r,specificity:o}:null}const ld=new Set(["before","after","first-line","first-letter","selection","backdrop","placeholder"]);function cd(e){return/[a-zA-Z_]/.test(e)||e.charCodeAt(0)>=128}function Bn(e,t){let n=t;for(;n<e.length;n++){const r=e[n];if(r==="\\"){n+=1;continue}if(!(/[a-zA-Z0-9_-]/.test(r)||r.charCodeAt(0)>=128))break}return n}function gs(e,t){let n=1,r=null;for(let o=t+1;o<e.length;o++){const i=e[o];if(r){if(i==="\\"){o+=1;continue}i===r&&(r=null);continue}if(i==='"'||i==="'"){r=i;continue}if(i==="\\"){o+=1;continue}if(i==="[")n+=1;else if(i==="]"&&(n-=1,n===0))return o}return e.length-1}function bs(e,t){let n=1,r=null;for(let o=t+1;o<e.length;o++){const i=e[o];if(r){if(i==="\\"){o+=1;continue}i===r&&(r=null);continue}if(i==='"'||i==="'"){r=i;continue}if(i==="\\"){o+=1;continue}if(i==="[")o=gs(e,o);else if(i==="(")n+=1;else if(i===")"&&(n-=1,n===0))return{content:e.slice(t+1,o),endIndex:o}}return{content:e.slice(t+1),endIndex:e.length-1}}function ud(e,t){const n=e[t];return/\s/.test(n)||n===">"||n==="+"||n==="~"||n==="|"}function dd(e,t){let n=t;for(;n<e.length&&/\s/.test(e[n]);)n++;return e[n]==="|"&&e[n+1]==="|"?n+1:e[n]===">"||e[n]==="+"||e[n]==="~"||e[n]==="|"?n:n-1}function fd(e){let t=0,n=0,r=null;for(let o=0;o<e.length;o++){const i=e[o];if(r){if(i==="\\"){o+=1;continue}i===r&&(r=null);continue}if(i==='"'||i==="'"){r=i;continue}if(i==="\\"){o+=1;continue}if(i==="["?n+=1:i==="]"&&n>0?n-=1:i==="("?t+=1:i===")"&&t>0&&(t-=1),t===0&&n===0&&pd(e,o))return e.slice(o+2).trimStart()}return null}function pd(e,t){if(e[t]!=="o"||e[t+1]!=="f")return!1;const n=e[t-1],r=e[t+2],o=n===void 0||/\s/.test(n),i=r===void 0||/\s/.test(r);return o&&i}const md=new Set(["color","color-scheme","caret-color","accent-color","font","font-family","font-feature-settings","font-kerning","font-language-override","font-optical-sizing","font-palette","font-size","font-size-adjust","font-stretch","font-style","font-synthesis","font-synthesis-small-caps","font-synthesis-style","font-synthesis-weight","font-variant","font-variant-alternates","font-variant-caps","font-variant-east-asian","font-variant-emoji","font-variant-ligatures","font-variant-numeric","font-variant-position","font-variation-settings","font-weight","letter-spacing","line-height","text-rendering","text-size-adjust","text-transform","text-indent","text-align","text-align-last","text-justify","text-shadow","text-emphasis-color","text-emphasis-position","text-emphasis-style","text-underline-position","tab-size","white-space","word-break","overflow-wrap","word-spacing","hyphens","line-break","direction","unicode-bidi","writing-mode","text-orientation","text-combine-upright","list-style","list-style-image","list-style-position","list-style-type","border-collapse","border-spacing","caption-side","empty-cells","cursor","visibility","pointer-events","user-select","quotes","orphans","widows","fill","fill-opacity","fill-rule","stroke","stroke-width","stroke-linecap","stroke-linejoin","stroke-miterlimit","stroke-dasharray","stroke-dashoffset","stroke-opacity","paint-order","shape-rendering","image-rendering","color-interpolation","color-interpolation-filters","color-rendering","dominant-baseline","alignment-baseline","baseline-shift","text-anchor","stop-color","stop-opacity","flood-color","flood-opacity","lighting-color","marker","marker-start","marker-mid","marker-end"]);function Vn(e){const t=String(e||"").trim();return t?t.startsWith("--")?!0:md.has(t.toLowerCase()):!1}const hd={margin:["margin-top","margin-right","margin-bottom","margin-left"],padding:["padding-top","padding-right","padding-bottom","padding-left"],inset:["top","right","bottom","left"],border:["border-top-width","border-right-width","border-bottom-width","border-left-width","border-top-style","border-right-style","border-bottom-style","border-left-style","border-top-color","border-right-color","border-bottom-color","border-left-color"],"border-width":["border-top-width","border-right-width","border-bottom-width","border-left-width"],"border-style":["border-top-style","border-right-style","border-bottom-style","border-left-style"],"border-color":["border-top-color","border-right-color","border-bottom-color","border-left-color"],"border-top":["border-top-width","border-top-style","border-top-color"],"border-right":["border-right-width","border-right-style","border-right-color"],"border-bottom":["border-bottom-width","border-bottom-style","border-bottom-color"],"border-left":["border-left-width","border-left-style","border-left-color"],"border-radius":["border-top-left-radius","border-top-right-radius","border-bottom-right-radius","border-bottom-left-radius"],outline:["outline-color","outline-style","outline-width"],background:["background-attachment","background-clip","background-color","background-image","background-origin","background-position","background-repeat","background-size"],font:["font-style","font-variant","font-weight","font-stretch","font-size","line-height","font-family"],flex:["flex-grow","flex-shrink","flex-basis"],"flex-flow":["flex-direction","flex-wrap"],"place-content":["align-content","justify-content"],"place-items":["align-items","justify-items"],"place-self":["align-self","justify-self"],gap:["row-gap","column-gap"],"grid-gap":["row-gap","column-gap"],overflow:["overflow-x","overflow-y"],"grid-area":["grid-row-start","grid-column-start","grid-row-end","grid-column-end"],"grid-row":["grid-row-start","grid-row-end"],"grid-column":["grid-column-start","grid-column-end"],"grid-template":["grid-template-rows","grid-template-columns","grid-template-areas"],"text-emphasis":["text-emphasis-style","text-emphasis-color"],"text-decoration":["text-decoration-line","text-decoration-style","text-decoration-color","text-decoration-thickness"],transition:["transition-property","transition-duration","transition-timing-function","transition-delay"],animation:["animation-name","animation-duration","animation-timing-function","animation-delay","animation-iteration-count","animation-direction","animation-fill-mode","animation-play-state"],columns:["column-width","column-count"],"column-rule":["column-rule-width","column-rule-style","column-rule-color"],"list-style":["list-style-position","list-style-image","list-style-type"]};function ws(e){var r;const t=String(e||"").trim();if(!t)return[];if(t.startsWith("--"))return[t];const n=t.toLowerCase();return(r=hd[n])!=null?r:[n]}function gd(e){const t=String(e||"").trim();return t?t.startsWith("--")?t:t.toLowerCase():""}function bd(e,t){return e[0]!==t[0]?e[0]>t[0]?1:-1:e[1]!==t[1]?e[1]>t[1]?1:-1:e[2]!==t[2]?e[2]>t[2]?1:-1:0}function wd(e,t){if(e.important!==t.important)return e.important?1:-1;const n=mr(e.specificity,t.specificity);return n!==0?n:bd(e.sourceOrder,t.sourceOrder)}function xs(e){const t=new Map;for(const r of e)for(const o of r.affects){const i=t.get(o);(!i||wd(r,i)>0)&&t.set(o,r)}const n=new Map;for(const r of e)n.set(r.id,"overridden");for(const[,r]of t)n.set(r.id,"active");return{winners:t,declStatus:n}}const ys=(za=globalThis.CSSRule)==null?void 0:za.CONTAINER_RULE,vs=(Ua=globalThis.CSSRule)==null?void 0:Ua.SCOPE_RULE;function Es(e){var t,n,r;if(e.disabled)return!1;try{const o=(r=(n=(t=e.media)==null?void 0:t.mediaText)==null?void 0:n.trim())!=null?r:"";return!o||o.toLowerCase()==="all"?!0:window.matchMedia(o).matches}catch(o){return!0}}function Co(e,t){var o,i;const n=typeof e.href=="string"?e.href:void 0;if(n){const s=(i=(o=n.split("/").pop())==null?void 0:o.split("?")[0])!=null?i:n;return{url:n,label:s}}const r=e.ownerNode;if(r&&r.nodeType===Node.ELEMENT_NODE){const s=r;if(s.tagName==="STYLE")return{label:`<style #${t}>`};if(s.tagName==="LINK")return{label:`<link #${t}>`}}return{label:`<constructed #${t}>`}}function Ss(e){try{return e.cssRules}catch(t){return null}}function xd(e,t){var n,r,o;try{const i=(o=(r=(n=e.media)==null?void 0:n.mediaText)==null?void 0:r.trim())!=null?o:"";return!i||i.toLowerCase()==="all"?!0:window.matchMedia(i).matches}catch(i){return t.push(`Failed to evaluate @media rule: ${String(i)}`),!1}}function yd(e,t){var n,r;try{const o=(r=(n=e.conditionText)==null?void 0:n.trim())!=null?r:"";return!o||typeof(CSS==null?void 0:CSS.supports)!="function"?!0:CSS.supports(o)}catch(o){return t.push(`Failed to evaluate @supports rule: ${String(o)}`),!1}}function vd(e,t){var c,u,f;const n=[],r=[];let o=0;const i=e,s=[];try{for(const m of Array.from((c=i.styleSheets)!=null?c:[]))m&&m instanceof CSSStyleSheet&&s.push(m)}catch(m){}try{const m=Array.from((u=i.adoptedStyleSheets)!=null?u:[]);for(const h of m)h&&h instanceof CSSStyleSheet&&s.push(h)}catch(m){}let a=0;function l(m,h){var d,b,S,g,k,v;for(const L of Array.from(m)){if(o+=1,ys&&L.type===ys){n.push("Skipped @container rules (not evaluated in CSSOM collector)");continue}if(vs&&L.type===vs){n.push("Skipped @scope rules (not evaluated in CSSOM collector)");continue}if(L.type===CSSRule.IMPORT_RULE){const O=L;try{const F=(S=(b=(d=O.media)==null?void 0:d.mediaText)==null?void 0:b.trim())!=null?S:"";if(F&&F.toLowerCase()!=="all"&&!window.matchMedia(F).matches)continue}catch(F){}const V=O.styleSheet;if(V){if(h.stack.has(V)){const F=Co(V,h.sheetIndex);n.push(`Detected @import cycle, skipping: ${(g=F.url)!=null?g:F.label}`);continue}h.stack.add(V);try{if(!Es(V))continue;const F=Ss(V),T=Co(V,h.sheetIndex);if(!F){n.push(`Skipped @import stylesheet (cannot access cssRules, likely cross-origin): ${(k=T.url)!=null?k:T.label}`);continue}l(F,{sheetIndex:h.sheetIndex,sourceForRules:T,topSheet:V,stack:h.stack})}finally{h.stack.delete(V)}}continue}if(L.type===CSSRule.MEDIA_RULE){xd(L,n)&&l(L.cssRules,h);continue}if(L.type===CSSRule.SUPPORTS_RULE){yd(L,n)&&l(L.cssRules,h);continue}if(L.type===CSSRule.STYLE_RULE){const O=L;r.push({sheetIndex:h.sheetIndex,order:a++,selectorText:(v=O.selectorText)!=null?v:"",style:O.style,source:h.sourceForRules});continue}const A=L;if(A.cssRules&&typeof A.cssRules.length=="number")try{l(A.cssRules,h)}catch(O){}}}for(let m=0;m<s.length;m++){const h=s[m];if(!Es(h))continue;const d=Co(h,m),b=Ss(h);if(!b){n.push(`Skipped stylesheet (cannot access cssRules, likely cross-origin): ${(f=d.url)!=null?f:d.label}`);continue}const S=new Set;S.add(h),l(b,{sheetIndex:m,sourceForRules:d,topSheet:h,stack:S})}return{root:e,rootId:t,flatRules:r,warnings:n,stats:{styleSheets:s.length,rulesScanned:o}}}function ks(e){var r,o,i;const t=[],n=Number((r=e==null?void 0:e.length)!=null?r:0);for(let s=0;s<n;s++){let a="";try{a=e.item(s)}catch(u){a=""}if(a=gd(a),!a)continue;let l="",c=!1;try{l=(o=e.getPropertyValue(a))!=null?o:"",c=String((i=e.getPropertyPriority(a))!=null?i:"")==="important"}catch(u){l="",c=!1}t.push({property:a,value:String(l).trim(),important:c,declIndex:s})}return t}function Ed(e){const t=e;return!!t.style&&typeof t.style.getPropertyValue=="function"&&typeof t.style.getPropertyPriority=="function"}function Ao(e,t=2){var i,s;const n=e.tagName.toLowerCase(),r=(i=e.id)==null?void 0:i.trim();if(r)return`${n}#${r}`;const o=Array.from((s=e.classList)!=null?s:[]).slice(0,t).filter(Boolean);return o.length?`${n}.${o.join(".")}`:n}function Cs(e){var t,n,r;try{const o=(t=e.getRootNode)==null?void 0:t.call(e);return o instanceof ShadowRoot?o:(n=e.ownerDocument)!=null?n:document}catch(o){return(r=e.ownerDocument)!=null?r:document}}function As(e){var t;if(e.parentElement)return e.parentElement;try{const n=(t=e.getRootNode)==null?void 0:t.call(e);if(n instanceof ShadowRoot)return n.host}catch(n){}return null}function Ts(e,t,n,r){const o=[],i=[],s=[],a=t.root instanceof ShadowRoot?"shadow":"document";let l=null;if(r.includeInline&&Ed(e)){const c=ks(e.style),u=[];for(const f of c){const m=ws(f.property);if(!r.declFilter({property:f.property,affects:m}))continue;const h=`inline:${n}:${f.declIndex}`;u.push({id:h,name:f.property,value:f.value,important:f.important,affects:m,status:"overridden"}),s.push({id:h,important:f.important,specificity:[1,0,0,0],sourceOrder:[Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER,f.declIndex],property:f.property,value:f.value,affects:m,ownerRuleId:`inline:${n}`,ownerElementId:n})}l={id:`inline:${n}`,origin:"inline",selector:"element.style",matchedSelector:"element.style",specificity:[1,0,0,0],source:{label:"element.style"},order:Number.MAX_SAFE_INTEGER,decls:u}}for(const c of t.flatRules){const u=ad(e,c.selectorText);if(!u)continue;const f=ks(c.style),m=[],h=`rule:${t.rootId}:${c.sheetIndex}:${c.order}`;for(const d of f){const b=ws(d.property);if(!r.declFilter({property:d.property,affects:b}))continue;const S=`${h}:${d.declIndex}`;m.push({id:S,name:d.property,value:d.value,important:d.important,affects:b,status:"overridden"}),s.push({id:S,important:d.important,specificity:u.specificity,sourceOrder:[c.sheetIndex,c.order,d.declIndex],property:d.property,value:d.value,affects:b,ownerRuleId:h,ownerElementId:n})}m.length!==0&&i.push({id:h,origin:"rule",selector:c.selectorText,matchedSelector:u.matchedSelector,specificity:u.specificity,source:c.source,order:c.order,decls:m})}return i.sort((c,u)=>{var d,b;const f=(d=c.specificity)!=null?d:pr,m=(b=u.specificity)!=null?b:pr,h=mr(m,f);return h!==0?h:u.order-c.order}),{element:e,elementId:n,root:t.root,rootType:a,inlineRule:l,matchedRules:i,candidates:s,warnings:o,stats:{matchedRules:i.length}}}function Sd(e,t={}){var j,E;const n=[],r=Number.isFinite(t.maxInheritanceDepth)?Math.max(0,t.maxInheritanceDepth):10,o=new WeakMap;let i=1;const s=new WeakMap;let a=1;const l=new WeakMap,c=[];function u(w){const D=o.get(w);if(D)return D;const $=i++;return o.set(w,$),$}function f(w){var I;const D=l.get(w);if(D)return D;const $=(I=s.get(w))!=null?I:(()=>{const N=a++;return s.set(w,N),N})(),x=vd(w,$);return l.set(w,x),c.push(x),x}if(!e||!e.isConnected)return{target:{label:Ao(e),root:"document"},warnings:["Target element is not connected; snapshot may be incomplete."],stats:{roots:0,styleSheets:0,rulesScanned:0,matchedRules:0},sections:[]};const m=Cs(e),h=f(m);n.push(...h.warnings);const d=Ts(e,h,u(e),{includeInline:!0,declFilter:()=>!0}),b=xs(d.candidates),S=b.declStatus;if(d.inlineRule)for(const w of d.inlineRule.decls)w.status=(j=S.get(w.id))!=null?j:"overridden";for(const w of d.matchedRules)for(const D of w.decls)D.status=(E=S.get(D.id))!=null?E:"overridden";const g=[];let k=As(e);for(;k&&g.length<r;)g.push(k),k=As(k);const v=new Set;for(const w of d.candidates)for(const D of w.affects)Vn(D)&&v.add(D);const L=[];for(const w of g){const D=Cs(w),$=f(D);n.push(...$.warnings);const x=Ts(w,$,u(w),{includeInline:!0,declFilter:({affects:_})=>_.some(Vn)}),I=[];for(const _ of x.candidates){const M=_.affects.filter(Vn);if(M.length===0)continue;const W=mt(je({},_),{affects:M});I.push(W);for(const C of M)v.add(C)}const N=xs(I);x.inlineRule&&(x.inlineRule.decls=x.inlineRule.decls.map(_=>mt(je({},_),{affects:_.affects.filter(Vn)})).filter(_=>_.affects.length>0),x.inlineRule.decls.length===0&&(x.inlineRule=null)),x.matchedRules=x.matchedRules.map(_=>mt(je({},_),{decls:_.decls.map(M=>mt(je({},M),{affects:M.affects.filter(Vn)})).filter(M=>M.affects.length>0)})).filter(_=>_.decls.length>0),!(!x.inlineRule&&x.matchedRules.length===0)&&L.push({ancestor:w,label:Ao(w),collected:mt(je({},x),{candidates:I}),overrides:N})}const A=new Set;for(const w of v)if(!b.winners.has(w))for(const D of L){const $=D.overrides.winners.get(w);if($){A.add($.id);break}}for(const w of L){if(w.collected.inlineRule)for(const D of w.collected.inlineRule.decls)D.status=A.has(D.id)?"active":"overridden";for(const D of w.collected.matchedRules)for(const $ of D.decls)$.status=A.has($.id)?"active":"overridden"}const O=[];O.push({kind:"inline",title:"element.style",rules:d.inlineRule?[d.inlineRule]:[]}),O.push({kind:"matched",title:"Matched CSS Rules",rules:d.matchedRules});for(const w of L){const D=[];w.collected.inlineRule&&D.push(w.collected.inlineRule),D.push(...w.collected.matchedRules),O.push({kind:"inherited",title:`Inherited from ${w.label}`,inheritedFrom:{label:w.label},rules:D})}let V=0,F=0;const T=new Set;for(const w of c)T.add(w.rootId),V+=w.stats.styleSheets,F+=w.stats.rulesScanned;const P=Array.from(new Set([...n,...d.warnings]));return{target:{label:Ao(e),root:m instanceof ShadowRoot?"shadow":"document"},warnings:P,stats:{roots:T.size,styleSheets:V,rulesScanned:F,matchedRules:d.stats.matchedRules},sections:O}}function kd(e){return e?`(${e[0]}, ${e[1]}, ${e[2]}, ${e[3]})`:""}function Ns(e){var t;try{const n=e.classList;if(n&&typeof n[Symbol.iterator]=="function")return Array.from(n).filter(Boolean)}catch(n){}try{return((t=e.getAttribute("class"))!=null?t:"").split(/\s+/).map(r=>r.trim()).filter(Boolean)}catch(n){return[]}}function Cd(e,t){const n=new Set,r=[];for(const i of t!=null?t:[]){const s=String(i!=null?i:"").trim();s&&(n.has(s)||(n.add(s),r.push(s)))}const o=r.join(" ").trim();try{o?e.setAttribute("class",o):e.removeAttribute("class")}catch(i){}}function Ad(e){var r;const t=String(e!=null?e:"");let n="";for(let o=0;o<t.length;o++){const i=t[o];if(i!=="\\"){n+=i;continue}if(o>=t.length-1)break;let s=o+1,a="";for(;s<t.length&&a.length<6&&/[0-9a-fA-F]/.test(t[s]);)a+=t[s],s+=1;if(a.length>0){const l=Number.parseInt(a,16);if(Number.isFinite(l)&&l>=0&&l<=1114111){n+=String.fromCodePoint(l),s<t.length&&/\s/.test(t[s])&&(s+=1),o=s-1;continue}}n+=(r=t[s])!=null?r:"",o=s}return n}function Td(e,t){for(let n=t;n<e.length;n++){const r=e[n];if(r==="\\"){const o=n+1;if(o>=e.length)return e.length;if(/[0-9a-fA-F]/.test(e[o])){let i=o,s=0;for(;i<e.length&&s<6&&/[0-9a-fA-F]/.test(e[i]);)i+=1,s+=1;i<e.length&&/\s/.test(e[i])&&(i+=1),n=i-1}else n=o;continue}if(/\s/.test(r)||r==="."||r==="#"||r===":"||r==="["||r==="]"||r==="("||r===")"||r===","||r===">"||r==="+"||r==="~"||r==="|")return n}return e.length}function Nd(e){const t=[],n=String(e!=null?e:"");let r=0,o=null;for(let i=0;i<n.length;i++){const s=n[i];if(o){if(s==="\\"){i+=1;continue}s===o&&(o=null);continue}if(s==='"'||s==="'"){o=s;continue}if(s==="["){r+=1;continue}if(s==="]"){r=Math.max(0,r-1);continue}if(r>0||s!==".")continue;const a=i+1;if(a>=n.length)continue;const l=Td(n,a),c=n.slice(a,l),u=Ad(c).trim();u&&t.push(u),i=l-1}return t}function _d(e){var r;const t=[],n=new Set;for(const o of e.sections)for(const i of o.rules){const s=(r=i.matchedSelector)!=null?r:i.selector;for(const a of Nd(s))if(a&&!n.has(a)&&(n.add(a),t.push(a),t.length>=rd))return t}return t}function _s(e){return e.trim().startsWith("--")}const Rs=new Set(["*","html","body",":root",":where(*)",":is(*)"]);function Rd(e){const t=e.trim().toLowerCase();return Rs.has(t)?!0:t.split(/\s*,\s*/).every(r=>r.split(/\s+/).filter(Boolean).every(i=>Rs.has(i)||i===">"||i==="+"||i==="~"))}function Is(e){if(Array.isArray(e.affects)){const t=e.affects;if(t&&t.length>0)return t}return[e.name]}function Id(e){const t=new Set;for(const n of e.sections)for(const r of n.rules)for(const o of r.decls)if(o.status==="active"&&!_s(o.name))for(const i of Is(o)){const s=String(i!=null?i:"").trim();s&&t.add(s)}return Array.from(t)}function Ld(e,t){var o;if(e.status!=="active"||!t.computedStyle)return!1;const n=Is(e);let r=!1;for(const i of n){const s=String(i!=null?i:"").trim();if(!s)continue;let a="";try{a=String((o=t.computedStyle.getPropertyValue(s))!=null?o:"").trim()}catch(c){a=""}const l=t.defaults.getBaselineValue(t.tagName,s);if((a||l)&&(r=!0),a!==l)return!1}return r}function Ls(e,t){return!(_s(e.name)||Ld(e,t))}function Ms(e,t){if(!Rd(e))return!1;const n=t.toLowerCase();return!(n==="html"||n==="body")}function Md(e,t,n){var c,u;const r=(c=e.matchedSelector)!=null?c:e.selector;if(e.origin==="rule"&&Ms(r,n.tagName))return null;const o=e.decls.filter(f=>Ls(f,n));if(o.length===0)return null;const i=document.createElement("div");i.className="we-css-rule",i.dataset.ruleId=e.id,i.dataset.origin=e.origin;const s=document.createElement("div");s.className="we-css-rule-header";const a=document.createElement("span");if(a.className="we-css-rule-selector",a.textContent=(u=e.matchedSelector)!=null?u:e.selector,a.title=e.selector,s.append(a),e.source){const f=document.createElement("span");f.className="we-css-rule-source",f.textContent=e.source.label,e.source.url&&(f.title=e.source.url),s.append(f)}if(e.origin==="rule"&&e.specificity){const f=document.createElement("span");f.className="we-css-rule-spec",f.textContent=kd(e.specificity),f.title="Specificity (inline, id, class, type)",s.append(f)}i.append(s);const l=document.createElement("div");l.className="we-css-decls";for(const f of o){const m=Dd(f);l.append(m)}return i.append(l),i}function Dd(e){const t=document.createElement("div");t.className="we-css-decl",t.dataset.status=e.status;const n=document.createElement("span");n.className="we-css-decl-name",n.textContent=e.name;const r=document.createElement("span");r.className="we-css-decl-colon",r.textContent=": ";const o=document.createElement("span");o.className="we-css-decl-value-container";const i=document.createElement("span");if(i.className="we-css-decl-value",i.textContent=e.value,o.append(i),e.important){const a=document.createElement("span");a.className="we-css-decl-important",a.textContent="!important",o.append(a)}const s=document.createElement("span");return s.className="we-css-decl-semi",s.textContent=";",t.append(n,r,o,s),t}function Pd(e,t){var r;const n=(r=e.matchedSelector)!=null?r:e.selector;return e.origin==="rule"&&Ms(n,t.tagName)?!1:e.decls.some(o=>Ls(o,t))}function Ds(e,t){return e.rules.some(n=>Pd(n,t))}function Od(e,t,n){if(!Ds(e,n))return null;const r=document.createElement("div");if(r.className="we-css-section",r.dataset.kind=e.kind,e.kind==="inherited"){const i=document.createElement("div");i.className="we-css-section-header";const s=document.createElement("span");s.className="we-css-section-title",s.textContent=e.title,i.append(s),r.append(i)}const o=document.createElement("div");o.className="we-css-section-rules";for(const i of e.rules){const s=Md(i,t,n);s&&o.append(s)}return o.childElementCount===0?null:(r.append(o),r)}function Fd(e){const{container:t,transactionManager:n,onClassChange:r}=e,o=new Pe,i=sd();o.add(()=>i.dispose());let s=null,a=null,l=[],c=null,u=!1,f=!1;const m=document.createElement("div");m.className="we-css-panel";const h=document.createElement("div");h.className="we-css-class-editor-mount";const d=document.createElement("div");d.className="we-css-info",d.hidden=!0;const b=document.createElement("div");b.className="we-css-empty",b.textContent="No styles";const S=document.createElement("div");S.className="we-css-warnings",S.hidden=!0;const g=document.createElement("div");g.className="we-css-sections",c=id({container:h,onClassChange:F=>{const T=s;if(!T||!T.isConnected)return;const P=Ns(T);n?n.recordClass(T,P,F):Cd(T,F),c==null||c.setClasses(Ns(T)),r==null||r(),v()},getSuggestions:()=>l}),m.append(h,d,S,b,g),t.append(m),o.add(()=>m.remove());function k(){if(g.innerHTML="",S.innerHTML="",!a){b.hidden=!1,b.textContent="Select an element to view styles",d.hidden=!0,S.hidden=!0;return}const F=s?s.tagName.toLowerCase():"";let T=null;try{s!=null&&s.isConnected&&(T=window.getComputedStyle(s))}catch(E){T=null}const P={defaults:i,tagName:F,computedStyle:T};if(T&&F&&i.ensureBaselineValues(F,Id(a)),!a.sections.some(E=>Ds(E,P)))b.hidden=!1,b.textContent="No CSS rules matched",d.hidden=!0;else{b.hidden=!0;const{stats:E}=a;d.textContent=`${E.matchedRules} rules matched (${E.styleSheets} stylesheets, ${E.rulesScanned} rules scanned)`,d.hidden=!1}if(a.warnings.length>0){S.hidden=!1;for(const E of a.warnings.slice(0,5)){const w=document.createElement("div");w.className="we-css-warning",w.textContent=E,S.append(w)}if(a.warnings.length>5){const E=document.createElement("div");E.className="we-css-warning-more",E.textContent=`...and ${a.warnings.length-5} more warnings`,S.append(E)}}else S.hidden=!0;for(const E of a.sections){const w=Od(E,o,P);w&&g.append(w)}}function v(){if(!u){f=!0;return}if(!s||!s.isConnected){a=null,l=[],c==null||c.setTarget(null),k();return}a=Sd(s,{maxInheritanceDepth:0}),l=a?_d(a):[],k(),f=!1}function L(F){o.isDisposed||(s=F,c==null||c.setTarget(F),v())}function A(){o.isDisposed||(c==null||c.refresh(),v())}function O(F){o.isDisposed||(u=F,F&&f&&v())}function V(){s=null,a=null,c==null||c.dispose(),c=null,l=[],u=!1,f=!1,o.dispose()}return k(),{setTarget:L,refresh:A,setVisible:O,dispose:V}}const br=15,Bd=40;function $t(e){return e&&typeof e=="object"?e:null}function Ht(e){if(typeof e=="string")return e.trim()||void 0}function wr(e){if(typeof e=="number"&&Number.isFinite(e))return e;const t=Number.parseInt(String(e),10);return Number.isFinite(t)?t:void 0}function xr(e){var n,r;if(!e)return;if(typeof e=="function"){const o=e;return(n=Ht(o.displayName))!=null?n:Ht(o.name)}const t=$t(e);if(t)return(r=Ht(t.displayName))!=null?r:Ht(t.name)}function Vd(e){var n,r;let t=e;for(let o=0;o<Bd&&t;o++){const i=$t(t);if(!i)break;const s=$t(i._debugSource),a=Ht(s==null?void 0:s.fileName);if(a){const f=(n=xr(i.elementType))!=null?n:xr(i.type);return{file:a,line:wr(s==null?void 0:s.lineNumber),column:wr(s==null?void 0:s.columnNumber),componentName:f}}const l=$t(i._debugOwner),c=$t(l==null?void 0:l._debugSource),u=Ht(c==null?void 0:c.fileName);if(u){const f=(r=xr(l==null?void 0:l.elementType))!=null?r:xr(l==null?void 0:l.type);return{file:u,line:wr(c==null?void 0:c.lineNumber),column:wr(c==null?void 0:c.columnNumber),componentName:f}}t=i.return}return null}function $d(e){try{let t=e;for(let n=0;n<br&&t;n++){const r=t;for(const o of Object.keys(r))if(o.startsWith("__reactFiber$")||o.startsWith("__reactInternalInstance$")){const i=Vd(r[o]);if(i)return i}t=t.parentElement}}catch(t){}return null}function Hd(e){if(typeof e!="string")return null;const t=e.trim();if(!t)return null;const n=t.match(/:(\d+)(?::(\d+))?$/);if(!n)return{file:t};const r=t.slice(0,n.index).trim();if(!r)return null;const o=Number.parseInt(n[1],10),i=n[2]?Number.parseInt(n[2],10):void 0;return{file:r,line:Number.isFinite(o)&&o>0?o:void 0,column:i!==void 0&&Number.isFinite(i)&&i>0?i:void 0}}function zd(e){try{let t=e;for(let n=0;n<br&&t;n++){if(typeof t.getAttribute=="function"){const r=t.getAttribute("data-v-inspector");if(r){const o=Hd(r);if(o!=null&&o.file)return o}}t=t.parentElement}}catch(t){}return null}function Ud(e){try{const t=zd(e);if(t!=null&&t.file){let r,o=e;for(let i=0;i<br&&o;i++){const a=$t(o.__vueParentComponent),l=$t(a==null?void 0:a.type);if(r=Ht(l==null?void 0:l.name),r)break;o=o.parentElement}return mt(je({},t),{componentName:r})}let n=e;for(let r=0;r<br&&n;r++){const i=$t(n.__vueParentComponent),s=$t(i==null?void 0:i.type),a=Ht(s==null?void 0:s.__file);if(a)return{file:a,componentName:Ht(s==null?void 0:s.name)};n=n.parentElement}}catch(t){}return null}function Gd(e){const t=$d(e);if(t)return t;const n=Ud(e);return n||null}const To=5,Wd=32,Xd=8,Yd=["data-testid","data-test-id","data-test","data-qa","data-cy","name","title","alt","aria-label"],jd=3,Kd=["data-testid","data-test-id","data-test","data-qa","data-cy"],qd=24,Ps=20;function It(e){if(typeof CSS!="undefined"&&typeof CSS.escape=="function")return CSS.escape(e);const t=String(e),n=t.length;if(n===0)return"";let r="";const o=t.charCodeAt(0);for(let i=0;i<n;i++){const s=t.charCodeAt(i);if(s===0){r+="�";continue}if(s>=1&&s<=31||s===127||i===0&&s>=48&&s<=57||i===1&&s>=48&&s<=57&&o===45){r+=`\\${s.toString(16)} `;continue}if(i===0&&n===1&&s===45){r+=`\\${t.charAt(i)}`;continue}s>=48&&s<=57||s>=65&&s<=90||s>=97&&s<=122||s===45||s===95?r+=t.charAt(i):r+=`\\${t.charAt(i)}`}return r}function No(e){var n;const t=(n=e.getRootNode)==null?void 0:n.call(e);return t instanceof ShadowRoot?t:document}function yr(e,t){try{return e.querySelector(t)}catch(n){return null}}function yt(e,t){try{return e.querySelectorAll(t).length===1}catch(n){return!1}}function Os(e,t){var o;const n=(o=e.id)==null?void 0:o.trim();if(!n)return null;const r=`#${It(n)}`;return yt(t,r)?r:null}function Zd(e,t,n){var i;const r=[];if(n<=0)return r;const o=e.tagName.toLowerCase();for(const s of Yd){if(r.length>=n)break;const a=(i=e.getAttribute(s))==null?void 0:i.trim();if(!a)continue;const l=`[${s}="${It(a)}"]`;if(yt(t,l)){r.push(l);continue}const c=`${o}${l}`;yt(t,c)&&r.push(c)}return r}function Qd(e,t,n){const r=[];if(n<=0)return r;const o=e.tagName.toLowerCase(),i=Array.from(e.classList).filter(l=>l&&/^[a-zA-Z_][a-zA-Z0-9_-]*$/.test(l)).slice(0,qd);if(i.length===0)return r;const s=new Map;for(const l of i){if(r.length>=n)return r;const c=`.${It(l)}`,u=yt(t,c);s.set(l,u),u&&r.push(c)}for(const l of i){if(r.length>=n)return r;if(s.get(l)===!0)continue;const c=`${o}.${It(l)}`;yt(t,c)&&r.push(c)}const a=Math.min(i.length,jd);for(let l=0;l<a;l++)for(let c=l+1;c<a;c++){if(r.length>=n)return r;const u=i[l],f=i[c],m=`.${It(u)}.${It(f)}`;if(yt(t,m)){r.push(m);continue}const h=`${o}${m}`;yt(t,h)&&r.push(h)}if(a>=3&&r.length<n){const l=`.${It(i[0])}.${It(i[1])}.${It(i[2])}`;if(yt(t,l))r.push(l);else{const c=`${o}${l}`;r.length<n&&yt(t,c)&&r.push(c)}}return r}function Jd(e,t){const n=[];let r=e;const o=t instanceof Document;for(;r&&r.nodeType===Node.ELEMENT_NODE;){const s=r.tagName.toLowerCase();if(o&&s==="body")break;let a=s;const l=r.parentElement,c=r.parentNode;let u;l?u=Array.from(l.children):c instanceof ShadowRoot||c instanceof Document?u=Array.from(c.children):u=[];const f=u.filter(m=>m.tagName===r.tagName);if(f.length>1){const m=f.indexOf(r)+1;a+=`:nth-of-type(${m})`}if(n.unshift(a),r=l,!l&&c===t)break}const i=n.join(" > ");return o?`body > ${i}`:i||"*"}function ef(e,t,n){const r=[];let o=t;for(let i=0;o&&o!==e&&i<Ps;i++){let a=o.tagName.toLowerCase();const l=o.parentElement,c=o.parentNode;let u;l?u=Array.from(l.children):c instanceof ShadowRoot||c instanceof Document?u=Array.from(c.children):u=[];const f=u.filter(m=>m.tagName===o.tagName);if(f.length>1){const m=f.indexOf(o)+1;a+=`:nth-of-type(${m})`}if(r.unshift(a),!l){if(c===n)break;break}o=l}return o!==e?null:r.join(" > ")||null}function tf(e,t){var o;const n=Os(e,t);if(n)return n;const r=e.tagName.toLowerCase();for(const i of Kd){const s=(o=e.getAttribute(i))==null?void 0:o.trim();if(!s)continue;const a=`[${i}="${It(s)}"]`;if(yt(t,a))return a;const l=`${r}${a}`;if(yt(t,l))return l}return null}function nf(e,t){let n=e.parentElement;for(let r=0;n&&r<Ps;r++){const o=n.tagName.toUpperCase();if(o==="HTML"||o==="BODY")break;const i=tf(n,t);if(i){const s=ef(n,e,t);if(!s){n=n.parentElement;continue}const a=`${i} ${s}`;if(!yt(t,a)){n=n.parentElement;continue}if(yr(t,a)===e)return a}n=n.parentElement}return null}function rf(e){var r;const t=[];let n=e;for(;;){const o=(r=n.getRootNode)==null?void 0:r.call(n);if(!(o instanceof ShadowRoot))break;const i=o.host;if(!(i instanceof Element))break;const s=No(i),a=sf(i,{root:s});if(!a)break;t.unshift(a),n=i}return t.length>0?t:void 0}function of(e,t){return e.replace(/\s+/g," ").trim().slice(0,t)}function _o(e){var s,a,l,c;const t=[],n=(a=(s=e.tagName)==null?void 0:s.toLowerCase())!=null?a:"unknown";t.push(n);const r=(l=e.id)==null?void 0:l.trim();r&&t.push(`id=${r}`);const o=Array.from(e.classList).slice(0,Xd);o.length>0&&t.push(`class=${o.join(".")}`);const i=of((c=e.textContent)!=null?c:"",Wd);return i&&t.push(`text=${i}`),t.join("|")}function Fs(e){const t=[];let n=e;for(;n;){const r=n.parentElement;if(r){const s=Array.from(r.children).indexOf(n);s>=0&&t.unshift(s),n=r;continue}const o=n.parentNode;if(o instanceof ShadowRoot||o instanceof Document){const s=Array.from(o.children).indexOf(n);s>=0&&t.unshift(s)}break}return t}function Bs(e,t={}){var c,u;const n=(c=t.root)!=null?c:No(e),r=Math.max(1,(u=t.maxCandidates)!=null?u:To),o=[],i=(f,m=r)=>{if(!f||o.length>=m)return;const h=f.trim();!h||o.includes(h)||o.push(h)},s=r>=To?nf(e,n):null,a=1+(s?1:0),l=Math.max(1,r-a);i(Os(e,n),l);for(const f of Zd(e,n,l-o.length))i(f,l);for(const f of Qd(e,n,l-o.length))i(f,l);return i(Jd(e,n)),i(s),o.slice(0,r)}function sf(e,t={}){var n;return(n=Bs(e,t)[0])!=null?n:""}function Ge(e){var r;const t=No(e),n=(r=Gd(e))!=null?r:void 0;return{selectors:Bs(e,{root:t,maxCandidates:To}),fingerprint:_o(e),path:Fs(e),shadowHostChain:rf(e),debugSource:n}}function Vs(e,t){try{return e.querySelectorAll(t).length===1}catch(n){return!1}}function af(e,t){const n=_o(e),r=t.split("|"),o=n.split("|");if(r[0]!==o[0])return!1;const i=r.find(a=>a.startsWith("id=")),s=o.find(a=>a.startsWith("id="));return!(i&&i!==s)}function He(e,t=document){var o,i;let n=t;if((o=e.frameChain)!=null&&o.length)for(const s of e.frameChain){const a=yr(n,s);if(!(a instanceof HTMLIFrameElement))return null;const l=a.contentDocument;if(!l)return null;n=l}let r=n;if((i=e.shadowHostChain)!=null&&i.length)for(const s of e.shadowHostChain){if(!Vs(r,s))return null;const a=yr(r,s);if(!a)return null;const l=a.shadowRoot;if(!l)return null;r=l}for(const s of e.selectors){if(!Vs(r,s))continue;const a=yr(r,s);if(a&&!(e.fingerprint&&!af(a,e.fingerprint)))return a}return null}function sn(e){var o,i,s,a;const t=e.selectors.join("|"),n=(i=(o=e.shadowHostChain)==null?void 0:o.join(">"))!=null?i:"";return`frame:${(a=(s=e.frameChain)==null?void 0:s.join(">"))!=null?a:""}|shadow:${n}|sel:${t}`}const lf=250,cf=new Set(["__proto__","constructor","prototype","__defineGetter__","__defineSetter__","__lookupGetter__","__lookupSetter__"]);function $n(e){return cf.has(String(e!=null?e:"").trim())}function uf(e,t){if(e==="react"){const n=t==null?void 0:t.trim();return n?`React ${n}`:"React"}if(e==="vue"){const n=t==null?void 0:t.trim();return n?`Vue ${n}`:"Vue"}return"Unknown"}function df(e){return e?String(e):""}function $s(e){if(!e||typeof e!="object")return"";const t=e,n=typeof t.file=="string"?t.file.trim():"";if(!n)return"";const r=Number(t.line),o=Number(t.column),i=Number.isFinite(r)&&r>0?r:void 0,s=Number.isFinite(o)&&o>0?o:void 0;return i?s?`${n}:${i}:${s}`:`${n}:${i}`:n}function Hs(e){var t,n,r,o;switch(e.kind){case"null":return"null";case"undefined":return"undefined";case"boolean":return e.value?"true":"false";case"number":return e.special?e.special:typeof e.value=="number"?String(e.value):"NaN";case"string":return e.truncated?`"${e.value}…"`:JSON.stringify(e.value);case"bigint":return`${e.value}n`;case"symbol":return`Symbol(${e.description})`;case"function":return`ƒ ${(t=e.name)!=null?t:"(anonymous)"}`;case"react_element":return e.display;case"dom_element":{const i=String((n=e.tagName)!=null?n:"").toLowerCase()||"element",s=e.id?`#${e.id}`:"",a=e.className?`.${String(e.className).split(/\s+/).filter(Boolean).slice(0,2).join(".")}`:"";return`<${i}${s}${a}>`}case"date":return e.value;case"regexp":return`/${e.source}/${e.flags}`;case"error":return`${e.name}: ${e.message}`;case"circular":return`[Circular #${e.refId}]`;case"max_depth":return e.preview;case"array":return`Array(${e.length})`;case"object":return`${(r=e.name)!=null?r:"Object"} {…}`;case"map":return`Map(${e.size})`;case"set":return`Set(${e.size})`;case"unknown":return e.preview;default:return String((o=e.kind)!=null?o:"unknown")}}function ff(e){return e.special||typeof e.value!="number"?!1:Number.isFinite(e.value)}function zs(e){const t=e.trim();if(!t)return{ok:!1};if(/^-?\d+\.$/.test(t)){const n=Number(t.slice(0,-1));return Number.isFinite(n)?{ok:!0,value:n}:{ok:!1}}if(/^-?(?:\d+|\d*\.\d+)$/.test(t)){const n=Number(t);return Number.isFinite(n)?{ok:!0,value:n}:{ok:!1}}return{ok:!1}}function vr(e,t){var n,r,o,i;return t?e?mt(je(je({},e),t),{capabilities:(n=t.capabilities)!=null?n:e.capabilities,props:(r=t.props)!=null?r:e.props,meta:je(je({},(o=e.meta)!=null?o:{}),(i=t.meta)!=null?i:{})}):t:e}function pf(e,t,n){if(e)return"Loading…";if(!t)return n?`Error • ${n}`:"Waiting for selection…";const r=[],o=t.capabilities;o?(r.push(`read: ${o.canRead?"yes":"no"}`),r.push(`write: ${o.canWrite?"yes":"no"}`)):(r.push("read: unknown"),r.push("write: unknown"));const i=df(t.hookStatus);return i&&r.push(`hook: ${i}`),t.needsRefresh&&r.push("needs refresh"),n&&r.push("error"),r.join(" • ")}function Ro(e){var t;return!!((t=e==null?void 0:e.capabilities)!=null&&t.canWrite)&&!(e!=null&&e.needsRefresh)}function mf(e){var t;return!!((t=e==null?void 0:e.capabilities)!=null&&t.canRead)}function Us(e,t){var r;const n=e==null?void 0:e.props;return!n||!Array.isArray(n.entries)?null:(r=n.entries.find(o=>o.key===t))!=null?r:null}function Gs(e,t){var n;if(t.classList.remove("we-props-input--invalid"),e.value.kind==="string"){t.value=(n=e.value.value)!=null?n:"";return}if(e.value.kind==="number"){typeof e.value.value=="number"&&Number.isFinite(e.value.value)?t.value=String(e.value.value):e.value.special?t.value=e.value.special:t.value="";return}e.value.kind==="boolean"&&(t.checked=!!e.value.value)}function hf(e,t,n){var o;if(!((o=e==null?void 0:e.props)!=null&&o.entries))return;const r=e.props.entries.find(i=>i.key===t);if(r){if(typeof n=="string"){r.value={kind:"string",value:n},r.editable=!0;return}if(typeof n=="number"){r.value={kind:"number",value:n},r.editable=!0;return}r.value={kind:"boolean",value:n},r.editable=!0}}function gf(e){const{container:t,propsBridge:n}=e,r=new Pe,o=document.createElement("div");o.className="we-tooltip",o.hidden=!0;const i=t.getRootNode();i instanceof ShadowRoot?i.appendChild(o):document.body.appendChild(o),r.add(()=>o.remove());function s(z){const J=z.getAttribute("data-tip");if(!J){o.hidden=!0;return}const le=z.getBoundingClientRect();o.textContent=J,o.style.left=`${le.left+le.width/2}px`,o.style.top=`${le.bottom+4}px`,o.hidden=!1}function a(){o.hidden=!0}let l=null,c=null,u=!1,f=!1,m=!1,h=0,d=null,b=null;const S=new Map,g=document.createElement("div");g.className="we-props-panel";const k=document.createElement("div");k.className="we-props-meta";const v=document.createElement("div");v.className="we-props-meta-title";const L=document.createElement("div");L.className="we-props-title-left";const A=document.createElement("div");A.className="we-props-component",A.textContent="Props";const O=document.createElement("span");O.className="we-props-badge",O.textContent="Unknown",L.append(A,O);const V=document.createElement("div");V.className="we-props-title-actions";const F=document.createElement("button");F.type="button",F.className="we-props-action-btn",F.dataset.tip="Refresh",F.setAttribute("aria-label","Refresh props"),F.innerHTML=`<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M11.5 7C11.5 9.48528 9.48528 11.5 7 11.5C4.51472 11.5 2.5 9.48528 2.5 7C2.5 4.51472 4.51472 2.5 7 2.5C8.5 2.5 9.83 3.25 10.6 4.4M10.6 2V4.4H8.2" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;const T=document.createElement("button");T.type="button",T.className="we-props-action-btn",T.dataset.tip="Reset",T.setAttribute("aria-label","Reset props changes"),T.innerHTML=`<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M3 5.5H8.5C10.1569 5.5 11.5 6.84315 11.5 8.5C11.5 10.1569 10.1569 11.5 8.5 11.5H7M3 5.5L5.5 3M3 5.5L5.5 8" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`,V.append(F,T),v.append(L,V);const P=document.createElement("div");P.className="we-props-status";const j=document.createElement("div");j.className="we-props-warning",j.hidden=!0;const E=document.createElement("div");E.className="we-props-error",E.hidden=!0;const w=document.createElement("div");w.className="we-props-source",w.hidden=!0;const D=document.createElement("span");D.className="we-props-source-label",D.textContent="Source";const $=document.createElement("span");$.className="we-props-source-path",$.title="";const x=document.createElement("button");x.type="button",x.className="we-props-source-btn",x.dataset.tip="Open in VSCode",x.setAttribute("aria-label","Open in VSCode"),x.innerHTML=`<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M3.5 2.5H9.5V8.5M9 3L3 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`,w.append(D,$,x),k.append(v,P,j,E,w);const I=document.createElement("div");I.className="we-props-list";const N=document.createElement("div");N.className="we-props-empty",N.textContent="Select an element to view props.";const _=document.createElement("div");_.className="we-props-rows",I.append(N,_),g.append(k,I),t.append(g),r.add(()=>g.remove());function M(){for(const[,z]of S)clearTimeout(z.timeoutId);S.clear()}function W(){if(S.size===0)return;const z=[...S.keys()];for(const J of z){const le=S.get(J);le&&(clearTimeout(le.timeoutId),S.delete(J),te(J,le.value))}}r.add(M);function C(z){const J=S.get(z);J&&(clearTimeout(J.timeoutId),S.delete(z))}function p(z){const J=S.get(z);J&&(clearTimeout(J.timeoutId),S.delete(z),te(z,J.value))}function y(z,J){C(z);const le=window.setTimeout(()=>{S.delete(z),te(z,J)},lf);S.set(z,{timeoutId:le,value:J})}function R(){var K;const z=!!(l&&l.isConnected),J=d==null?void 0:d.framework,le=d==null?void 0:d.frameworkVersion,be=d==null?void 0:d.componentName;A.textContent=be||"Props",O.textContent=uf(J,le),P.textContent=z?pf(m,d,b):"Select an element to view props.",j.hidden=!0,j.textContent="",z&&(d!=null&&d.needsRefresh?(j.hidden=!1,j.textContent="A page refresh is required for full props inspection/editing."):(d==null?void 0:d.hookStatus)==="RENDERERS_NO_EDITING"?(j.hidden=!1,j.textContent="Editing is unavailable (likely a production build without overrideProps)."):(K=d==null?void 0:d.props)!=null&&K.truncated&&(j.hidden=!1,j.textContent="Props list is truncated.")),E.hidden=!b,E.textContent=b!=null?b:"";const Te=z?$s(d==null?void 0:d.debugSource):"";w.hidden=!Te,$.textContent=Te,$.title=Te,x.disabled=!Te||m;const Ne=d==null?void 0:d.hookStatus,Z=Ne==="HOOK_MISSING"||Ne==="HOOK_PRESENT_NO_RENDERERS",G=(d==null?void 0:d.needsRefresh)&&Z;F.dataset.tip=G?"Enable & Reload":"Refresh",F.disabled=!z||m,T.disabled=!z||m||!Ro(d)}function B(){var de,oe;_.innerHTML="";const z=!!(l&&l.isConnected),J=d;if(!z){N.hidden=!1,N.classList.remove("we-loading"),N.textContent="Select an element to view props.";return}if(m){N.hidden=!1,N.classList.add("we-loading"),N.innerHTML=`<svg width="14" height="14" viewBox="0 0 14 14" fill="none" style="animation: we-spin 0.8s linear infinite;">
        <circle cx="7" cy="7" r="5.5" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-dasharray="20 14" />
      </svg><span>Loading props…</span>`;return}if(N.classList.remove("we-loading"),!mf(J)){N.hidden=!1;const he=J==null?void 0:J.hookStatus;J!=null&&J.needsRefresh||he==="HOOK_MISSING"||he==="HOOK_PRESENT_NO_RENDERERS"?N.textContent="Props inspection is not ready. Refresh the page in development mode.":he==="RENDERERS_NO_EDITING"?N.textContent="Props inspection/editing is unavailable in this build.":N.textContent="Props inspection is not available for this element.";return}const be=J==null?void 0:J.props;if(!be||!Array.isArray(be.entries)||be.entries.length===0){N.hidden=!1,N.textContent=(J==null?void 0:J.framework)==="vue"?"No props or attrs found.":"No props found.";return}N.hidden=!0;const Ne=!Ro(J)||m,Z=(J==null?void 0:J.framework)==="vue",G=be.entries,q=Z&&G.some(he=>he.source==="attrs")?[{title:"Props",entries:G.filter(he=>he.source!=="attrs")},{title:"Attrs",entries:G.filter(he=>he.source==="attrs")}].filter(he=>he.entries.length>0):[{title:"",entries:G}];for(const he of q){if(he.title){const U=document.createElement("div");U.className="we-props-group",U.textContent=he.title,_.append(U)}for(const U of he.entries){const ie=document.createElement("div");ie.className="we-props-row";const ve=document.createElement("div");ve.className="we-props-key",ve.textContent=U.key;const ge=document.createElement("div");ge.className="we-props-value";const ye=$n(U.key),ke=!!U.editable&&!ye,Re=(Array.isArray(U.enumValues)?U.enumValues:[]).filter(ee=>typeof ee=="string"&&ee.trim().length>0);if(ke&&U.value.kind==="string"&&Re.length>0){const ee=document.createElement("select");ee.className="we-select we-props-input",ee.disabled=Ne,ee.dataset.propKey=U.key,ee.dataset.propKind="enum",ee.setAttribute("aria-label",`Select prop ${U.key}`);const ce=(de=U.value.value)!=null?de:"",ue=new Set;if(ce&&!Re.includes(ce)){const Se=document.createElement("option");Se.value=ce,Se.textContent=`${ce} (current)`,ee.append(Se),ue.add(ce)}for(const Se of Re){if(ue.has(Se))continue;ue.add(Se);const De=document.createElement("option");De.value=Se,De.textContent=Se,ee.append(De)}ce&&ue.has(ce)&&(ee.value=ce),ge.append(ee)}else if(ke&&U.value.kind==="boolean"){const ee=document.createElement("label");ee.className="we-props-bool";const ce=document.createElement("input");ce.type="checkbox",ce.className="we-props-checkbox",ce.checked=!!U.value.value,ce.disabled=Ne,ce.dataset.propKey=U.key,ce.dataset.propKind="boolean",ce.setAttribute("aria-label",`Toggle prop ${U.key}`);const ue=document.createElement("span");ue.textContent=ce.checked?"true":"false",ue.dataset.weBoolText="1",ee.append(ce,ue),ge.append(ee)}else if(ke&&U.value.kind==="string"){const ee=document.createElement("input");ee.type="text",ee.className="we-input we-props-input",ee.autocomplete="off",ee.spellcheck=!1,ee.value=(oe=U.value.value)!=null?oe:"",ee.disabled=Ne,ee.dataset.propKey=U.key,ee.dataset.propKind="string",ee.setAttribute("aria-label",`Edit prop ${U.key}`),ge.append(ee)}else if(ke&&U.value.kind==="number"&&ff(U.value)){const ee=document.createElement("input");ee.type="text",ee.inputMode="decimal",ee.className="we-input we-props-input",ee.autocomplete="off",ee.spellcheck=!1,ee.value=String(U.value.value),ee.disabled=Ne,ee.dataset.propKey=U.key,ee.dataset.propKind="number",ee.setAttribute("aria-label",`Edit prop ${U.key}`),ge.append(ee)}else ge.classList.add("we-props-value--readonly"),ge.textContent=ye?`${Hs(U.value)} (blocked)`:Hs(U.value);ie.append(ve,ge),_.append(ie)}}}function Y(){R(),B()}function Q(){return Qe(this,null,function*(){var be,Te,Ne,Z;if(r.isDisposed)return;if(!u){f=!0;return}const z=l,J=c;if(!z||!z.isConnected||!J){d=null,b=null,m=!1,f=!1,Y();return}const le=h;m=!0,b=null,Y();try{const G=yield n.probe(J);if(r.isDisposed||le!==h)return;if(d=vr(d,G.data),G.ok||(b=(be=G.error)!=null?be:"Props probe failed"),!!((Ne=(Te=G.data)==null?void 0:Te.capabilities)!=null&&Ne.canRead)){const q=yield n.read(J);if(r.isDisposed||le!==h)return;d=vr(d,q.data),q.ok||(b=(Z=q.error)!=null?Z:"Props read failed")}}catch(G){if(r.isDisposed||le!==h)return;b=G instanceof Error?G.message:String(G)}finally{!r.isDisposed&&le===h&&(m=!1,f=!1,Y())}})}function te(z,J){return Qe(this,null,function*(){var Z;if(r.isDisposed)return;const le=l,be=c;if(!le||!le.isConnected||!be)return;if($n(z)){b="Blocked prop key (security)",R();return}const Te=h;if(!Ro(d)){b="Props editing is not available for this element.",R();return}try{const G=yield n.write(be,[z],J);if(r.isDisposed||Te!==h)return;if(d=vr(d,G.data),!G.ok){b=(Z=G.error)!=null?Z:"Props write failed",R();return}b=null,hf(d,z,J),R()}catch(G){if(r.isDisposed||Te!==h)return;b=G instanceof Error?G.message:String(G),R()}})}function se(){return Qe(this,null,function*(){var be;if(r.isDisposed)return;const z=l,J=c;if(!z||!z.isConnected||!J)return;const le=h;M(),m=!0,b=null,Y();try{const Te=yield n.reset(J);if(r.isDisposed||le!==h)return;d=vr(d,Te.data),Te.ok||(b=(be=Te.error)!=null?be:"Props reset failed")}catch(Te){if(r.isDisposed||le!==h)return;b=Te instanceof Error?Te.message:String(Te)}finally{!r.isDisposed&&le===h&&(m=!1,R(),Q())}})}function pe(){return Qe(this,null,function*(){var J,le;if(r.isDisposed)return;if(typeof chrome=="undefined"||!((J=chrome.runtime)!=null&&J.sendMessage)){b="Chrome runtime API not available",R();return}if(window.confirm(`Props editing requires early injection to capture React renderers before they initialize.

This will:
• Register a content script for this site
• Reload the page immediately

After reload, enable the editor again to access full Props functionality.

Continue?`))try{const be=yield chrome.runtime.sendMessage({type:Ot.WEB_EDITOR_PROPS_REGISTER_EARLY_INJECTION});be!=null&&be.success||(b=(le=be==null?void 0:be.error)!=null?le:"Failed to register early injection",R())}catch(be){b=be instanceof Error?be.message:String(be),R()}})}function xe(){return Qe(this,null,function*(){var J,le;if(r.isDisposed)return;const z=d==null?void 0:d.debugSource;if(!(!z||!$s(z))){if(typeof chrome=="undefined"||!((J=chrome.runtime)!=null&&J.sendMessage)){b="Chrome runtime API not available",R();return}try{const be=yield chrome.runtime.sendMessage({type:Ot.WEB_EDITOR_OPEN_SOURCE,payload:{debugSource:z}});(be==null?void 0:be.success)===!1&&(b=(le=be==null?void 0:be.error)!=null?le:"Failed to open source in VSCode",R())}catch(be){b=be instanceof Error?be.message:String(be),R()}}})}const we=z=>{r.listen(z,"mouseenter",()=>s(z)),r.listen(z,"mouseleave",a)};we(F),we(T),we(x),r.listen(F,"click",z=>{z.preventDefault(),M();const J=d==null?void 0:d.hookStatus,le=J==="HOOK_MISSING"||J==="HOOK_PRESENT_NO_RENDERERS";if(d!=null&&d.needsRefresh&&le){pe();return}Q()}),r.listen(T,"click",z=>{z.preventDefault(),se()}),r.listen(x,"click",z=>{z.preventDefault(),xe()}),r.listen(_,"input",z=>{var Ne,Z;const J=z.target;if(!(J instanceof HTMLInputElement)||J.disabled||J.type==="checkbox")return;const le=(Ne=J.dataset.propKey)!=null?Ne:"",be=(Z=J.dataset.propKind)!=null?Z:"";if(!(!le||!be||$n(le)||z.isComposing)){if(be==="string"){y(le,J.value);return}if(be==="number"){const G=zs(J.value);if(!J.value.trim()){C(le),J.classList.remove("we-props-input--invalid");return}if(!G.ok){C(le),J.classList.add("we-props-input--invalid");return}J.classList.remove("we-props-input--invalid"),y(le,G.value)}}}),r.listen(_,"change",z=>{var Z,G,K,q,de;const J=z.target;if(!J)return;if(J instanceof HTMLSelectElement){if(J.disabled)return;const oe=(Z=J.dataset.propKey)!=null?Z:"",he=(G=J.dataset.propKind)!=null?G:"";if(!oe||he!=="enum"||$n(oe))return;te(oe,J.value);return}if(!(J instanceof HTMLInputElement)||J.disabled||J.type!=="checkbox")return;const le=(K=J.dataset.propKey)!=null?K:"",be=(q=J.dataset.propKind)!=null?q:"";if(!le||be!=="boolean"||$n(le))return;const Te=J.closest(".we-props-bool"),Ne=(de=Te==null?void 0:Te.querySelector)==null?void 0:de.call(Te,'span[data-we-bool-text="1"]');Ne&&(Ne.textContent=J.checked?"true":"false"),te(le,J.checked)}),r.listen(_,"keydown",z=>{var Te,Ne;const J=z.target;if(!(J instanceof HTMLInputElement)||J.disabled)return;const le=(Te=J.dataset.propKey)!=null?Te:"",be=(Ne=J.dataset.propKind)!=null?Ne:"";if(!(!le||!be)){if(z.key==="Enter"){if(z.isComposing)return;z.preventDefault(),p(le);try{J.blur()}catch(Z){}return}if(z.key==="Escape"){z.preventDefault(),C(le);const Z=Us(d,le);if(!Z)return;Gs(Z,J)}}}),r.listen(_,"focusout",z=>{var Te,Ne;const J=z.target;if(!(J instanceof HTMLInputElement)||J.disabled)return;const le=(Te=J.dataset.propKey)!=null?Te:"",be=(Ne=J.dataset.propKind)!=null?Ne:"";if(le){if(be==="number"){const Z=zs(J.value);if(!J.value.trim()||!Z.ok){C(le),J.classList.remove("we-props-input--invalid");const G=Us(d,le);G&&Gs(G,J);return}}p(le)}});function H(z){r.isDisposed||(W(),h+=1,l=z&&z.isConnected?z:null,c=l?Ge(l):null,d=null,b=null,m=!1,f=!1,Y(),u?Q():f=!0)}function ae(){r.isDisposed||(M(),Q())}function ne(z){r.isDisposed||(u=z,z&&f&&Q())}function me(){l=null,c=null,d=null,b=null,m=!1,f=!1,r.dispose()}return Y(),{setTarget:H,refresh:ae,setVisible:ne,dispose:me}}const bf=[{id:"position",label:"Position",collapsible:!0},{id:"layout",label:"Layout",collapsible:!0},{id:"size",label:"Size",collapsible:!0},{id:"spacing",label:"Spacing",collapsible:!0},{id:"typography",label:"Typography",collapsible:!0},{id:"appearance",label:"Appearance",collapsible:!0},{id:"border",label:"Border",collapsible:!0},{id:"background",label:"Background",collapsible:!0},{id:"effects",label:"Effects",collapsible:!1}];let wf=0;function Io(e){var i,s;const t=e.tagName.toLowerCase(),r=(i=e.id)==null?void 0:i.trim();if(r)return`${t}#${r}`;const o=Array.from((s=e.classList)!=null?s:[]).slice(0,2);return o.length>0?`${t}.${o.join(".")}`:t}function xf(e,t,n,r){var S;const o=`we_group_${e}_${++wf}`,i=(S=r==null?void 0:r.collapsible)!=null?S:!0;let s=!1;const a=document.createElement("section");a.className="we-group",a.dataset.group=e,a.dataset.collapsed="false";const l=document.createElement("div");l.className="we-group-header";const c=document.createElement("span");c.textContent=t;let u;if(i){const g=document.createElement("button");g.type="button",g.className="we-group-toggle",g.setAttribute("aria-expanded","true"),g.setAttribute("aria-controls",o),g.append(c,hl()),n.listen(g,"click",k=>{k.preventDefault(),b()}),u=g}else{const g=document.createElement("div");g.className="we-group-toggle we-group-toggle--static",g.append(c),u=g}const f=document.createElement("div");f.className="we-group-header-actions",l.append(u,f);const m=document.createElement("div");m.className="we-group-body",m.id=o,a.append(l,m);function h(g){i&&(s=g,a.dataset.collapsed=s?"true":"false",u.setAttribute("aria-expanded",s?"false":"true"))}function d(){return s}function b(){i&&h(!s)}return{root:a,body:m,headerActions:f,setCollapsed:h,isCollapsed:d,toggle:b}}function yf(e){var ne,me;const t=new Pe;let n=null,r=(ne=e.defaultTab)!=null?ne:"design",o=!1,i=(me=e.initialPosition)!=null?me:null;const s=new Map,a=[];let l=null,c=null,u=null,f=null,m=null,h=null,d=null,b=null,S=null;const g=document.createElement("aside");g.className="we-panel we-prop-panel",g.setAttribute("role","complementary"),g.setAttribute("aria-label","Properties"),g.dataset.tab=r,g.dataset.empty="true",g.dataset.minimized="false",g.dataset.dragged=i?"true":"false";const k=document.createElement("header");k.className="we-header";const v=document.createElement("button");v.type="button",v.className="we-drag-handle",v.setAttribute("aria-label","Drag property panel"),v.dataset.tooltip="Drag",v.append(fi());const L=document.createElement("div");L.className="we-prop-target",L.hidden=!0;const A=document.createElement("div");A.className="we-prop-tabs",A.setAttribute("role","tablist"),A.setAttribute("aria-label","Property tabs");const O=document.createElement("button");O.type="button",O.className="we-tab",O.setAttribute("role","tab"),O.dataset.tab="design",O.textContent="Design";const V=document.createElement("button");V.type="button",V.className="we-tab",V.setAttribute("role","tab"),V.dataset.tab="css",V.textContent="CSS";const F=document.createElement("button");F.type="button",F.className="we-tab",F.setAttribute("role","tab"),F.dataset.tab="props",F.textContent="Props";const T=document.createElement("button");T.type="button",T.className="we-tab",T.setAttribute("role","tab"),T.dataset.tab="dom",T.textContent="DOM",A.append(O,V,F,T);const P=document.createElement("button");P.type="button",P.className="we-icon-btn we-minimize-btn",P.setAttribute("aria-label","Minimize property panel"),P.dataset.tooltip="Minimize",P.append(wl()),k.append(v,A,P,L);const j=document.createElement("div");j.className="we-prop-body";const E=document.createElement("div");E.className="we-prop-empty",E.textContent="Select an element to view and edit its properties.";const w=document.createElement("div");w.className="we-prop-tab-content",w.dataset.tabContent="design";for(const{id:z,label:J,collapsible:le}of bf){const be=xf(z,J,t,{collapsible:le});s.set(z,be),w.append(be.root)}const D=document.createElement("div");D.className="we-prop-tab-content",D.dataset.tabContent="css";const $=document.createElement("div");$.className="we-prop-tab-content",$.dataset.tabContent="props";const x=document.createElement("div");x.className="we-prop-tab-content",x.dataset.tabContent="dom",j.append(E,w,D,$,x),g.append(k,j),e.container.append(g),t.add(()=>g.remove());const I=16;function N(z){const J=g.getBoundingClientRect(),le=window.innerWidth,be=window.innerHeight,Te=I,Ne=Math.max(Te,le-Te-J.width),Z=Math.max(Te,be-Te-J.height),G=Number.isFinite(z.left)?z.left:0,K=Number.isFinite(z.top)?z.top:0;return{left:Math.round(Math.min(Ne,Math.max(Te,G))),top:Math.round(Math.min(Z,Math.max(Te,K)))}}function _(){if(g.dataset.dragged=i?"true":"false",!i||o){g.style.left="",g.style.top="",g.style.right="",g.style.bottom="";return}g.style.left=`${i.left}px`,g.style.top=`${i.top}px`,g.style.right="auto",g.style.bottom="auto"}function M(z){var J;i=z?N(z):null,_(),(J=e.onPositionChange)==null||J.call(e,i)}function W(){return i}t.add(ui({handleEl:v,targetEl:g,clampMargin:I,onPositionChange:z=>M(z)})),i!==null?M(i):_();function C(){const z=s.get("size");z&&(f=nc({container:z.body,transactionManager:e.transactionManager}),a.push(f));const J=s.get("spacing");J&&(h=cc({container:J.body,transactionManager:e.transactionManager}),a.push(h));const le=s.get("position");le&&(m=Tc({container:le.body,transactionManager:e.transactionManager}),a.push(m));const be=s.get("layout");if(be){const q=Fc({container:be.body,transactionManager:e.transactionManager});a.push(q)}const Te=s.get("typography");if(Te){const q=bu({container:Te.body,transactionManager:e.transactionManager,tokensService:e.tokensService});a.push(q)}const Ne=s.get("appearance");if(Ne){const q=Eu({container:Ne.body,transactionManager:e.transactionManager});a.push(q)}const Z=s.get("border");if(Z){const q=_u({container:Z.body,transactionManager:e.transactionManager,tokensService:e.tokensService});a.push(q)}const G=s.get("background");if(G){const q=Pu({container:G.body,transactionManager:e.transactionManager,tokensService:e.tokensService});a.push(q)}const K=s.get("effects");if(K){const q=ju({container:K.body,transactionManager:e.transactionManager,tokensService:e.tokensService,headerActionsContainer:K.headerActions});a.push(q)}}C(),l=td({container:x,onSelect:z=>{e.onSelectElement(z)}}),c=Fd({container:D,transactionManager:e.transactionManager,onClassChange:()=>{n&&(L.textContent=Io(n))}}),u=gf({container:$,propsBridge:e.propsBridge}),t.listen(O,"click",z=>{z.preventDefault(),xe("design")}),t.listen(V,"click",z=>{z.preventDefault(),xe("css")}),t.listen(F,"click",z=>{z.preventDefault(),xe("props")}),t.listen(T,"click",z=>{z.preventDefault(),xe("dom")}),t.listen(P,"click",z=>{z.preventDefault(),p(!o)});function p(z){o=z,g.dataset.minimized=o?"true":"false",j.hidden=o,A.hidden=o,P.setAttribute("aria-label",o?"Expand property panel":"Minimize property panel"),P.dataset.tooltip=o?"Expand":"Minimize",!o&&i?M(i):_()}function y(){g.dataset.tab=r,O.setAttribute("aria-selected",r==="design"?"true":"false"),V.setAttribute("aria-selected",r==="css"?"true":"false"),F.setAttribute("aria-selected",r==="props"?"true":"false"),T.setAttribute("aria-selected",r==="dom"?"true":"false");const z=n!==null;w.hidden=!z||r!=="design",D.hidden=!z||r!=="css",$.hidden=!z||r!=="props",x.hidden=!z||r!=="dom",c==null||c.setVisible(z&&r==="css"),u==null||u.setVisible(z&&r==="props")}function R(){const z=n!==null;g.dataset.empty=z?"false":"true",E.hidden=z,z||(L.textContent=""),y()}function B(){for(const z of a)z.setTarget(n);l==null||l.setTarget(n),c==null||c.setTarget(n),u==null||u.setTarget(n)}function Y(){S!==null&&(cancelAnimationFrame(S),S=null)}function Q(){t.isDisposed||S===null&&(S=requestAnimationFrame(()=>{S=null,!t.isDisposed&&(!n||!n.isConnected||(f==null||f.refresh(),m==null||m.refresh(),h==null||h.refresh()))}))}function te(){if(Y(),d)try{d.disconnect()}catch(z){}d=null,b=null}function se(z){if(te(),!(!z||!z.isConnected)&&typeof MutationObserver!="undefined"){b=z,d=new MutationObserver(()=>{t.isDisposed||b===n&&Q()});try{d.observe(z,{attributes:!0,attributeFilter:["style"]})}catch(J){te()}}}t.add(te);function pe(z){t.isDisposed||(n=z,z&&(L.textContent=Io(z)),R(),B(),se(n))}function xe(z){t.isDisposed||(r=z,y())}function we(){return r}function H(){if(!t.isDisposed){n&&(L.textContent=Io(n));for(const z of a)z.refresh();l==null||l.refresh(),c==null||c.refresh(),u==null||u.refresh()}}function ae(){l==null||l.dispose(),l=null,c==null||c.dispose(),c=null,u==null||u.dispose(),u=null;for(const z of a)z.dispose();a.length=0,s.clear(),n=null,t.dispose()}return R(),{setTarget:pe,setTab:xe,getTab:we,refresh:H,getPosition:W,setPosition:M,dispose:ae}}class vf extends Error{constructor(n,r){super(n);Dt(this,"data");this.name="PropsError",this.data=r}}const Er={REQUEST:"web-editor-props:request",RESPONSE:"web-editor-props:response",CLEANUP:"web-editor-props:cleanup"},En=1,Ef=2500,Sn=200;function Hn(){try{if(typeof crypto!="undefined"&&typeof crypto.randomUUID=="function")return crypto.randomUUID()}catch(e){}return`req-${Date.now()}-${Math.random().toString(16).slice(2)}`}function Sf(e){return e===void 0?{$we:"undefined"}:e}function kf(e){return e!==null&&typeof e=="object"}function Cf(e){return e instanceof Error&&e.message||String(e)}function Af(e){if(e==null)return!0;const t=typeof e;return t==="string"||t==="boolean"?!0:t==="number"?Number.isFinite(e):!1}const Tf=new Set(["__proto__","constructor","prototype","__defineGetter__","__defineSetter__","__lookupGetter__","__lookupSetter__"]);function Nf(e){return e.some(t=>typeof t=="string"&&Tf.has(t))}function _f(e={}){var b;const t=Math.max(Sn,(b=e.defaultTimeoutMs)!=null?b:Ef),n=new Map;let r=!1;function o(){if(r)throw new vf("PropsBridge is disposed")}function i(S){for(const[g,k]of n)clearTimeout(k.timeoutId),k.resolve({ok:!1,error:S}),n.delete(g)}function s(S){var V;if(r)return;const g=S.detail;if(!kf(g)||g.v!==En)return;const k=typeof g.requestId=="string"?g.requestId:"";if(!k)return;const v=n.get(k);if(!v)return;n.delete(k),clearTimeout(v.timeoutId);const L=!!g.success,A=(V=g.data)!=null?V:void 0,O=typeof g.error=="string"?g.error:void 0;v.resolve({ok:L,data:A,error:L?void 0:O||"Props agent error"})}window.addEventListener(Er.RESPONSE,s);function a(S,g){o();const{requestId:k}=S;return k?n.has(k)?Promise.resolve({ok:!1,error:`Duplicate requestId: ${k}`}):new Promise(v=>{const L=window.setTimeout(()=>{n.delete(k),v({ok:!1,error:`Props agent timeout after ${g}ms (op=${S.op})`})},g);n.set(k,{resolve:v,timeoutId:L});try{window.dispatchEvent(new CustomEvent(Er.REQUEST,{detail:S}))}catch(A){clearTimeout(L),n.delete(k),v({ok:!1,error:`Failed to dispatch props request: ${Cf(A)}`})}}):Promise.resolve({ok:!1,error:"requestId is required"})}function l(S,g){return Qe(this,null,function*(){const k={v:En,requestId:Hn(),op:"probe",locator:S};return a(k,Math.max(Sn,g!=null?g:t))})}function c(S,g){return Qe(this,null,function*(){const k={v:En,requestId:Hn(),op:"read",locator:S};return a(k,Math.max(Sn,g!=null?g:t))})}function u(S,g,k,v){return Qe(this,null,function*(){if(!Array.isArray(g)||g.length===0)return{ok:!1,error:"prop path is required"};if(Nf(g))return{ok:!1,error:"Invalid prop path: contains dangerous key"};if(!Af(k))return{ok:!1,error:"Only primitive prop values are supported"};const L={v:En,requestId:Hn(),op:"write",locator:S,payload:{propPath:g,propValue:Sf(k)}};return a(L,Math.max(Sn,v!=null?v:t))})}function f(S,g){return Qe(this,null,function*(){const k={v:En,requestId:Hn(),op:"reset",locator:S};return a(k,Math.max(Sn,g!=null?g:t))})}function m(S){return Qe(this,null,function*(){if(r)return;const g=Math.max(Sn,S!=null?S:800);try{const k={v:En,requestId:Hn(),op:"cleanup"};yield a(k,g)}catch(k){}finally{try{window.dispatchEvent(new CustomEvent(Er.CLEANUP))}catch(k){}h()}})}function h(){if(!r){r=!0;try{window.removeEventListener(Er.RESPONSE,s)}catch(S){}i("PropsBridge disposed")}}function d(){return r}return{probe:l,read:c,write:u,reset:f,cleanup:m,dispose:h,isDisposed:d}}const Ws="data-mcp-canvas",Xs="overlay",Rf=100,Lo={hover:{strokeColor:Je.hover,fillColor:`${Je.hover}15`,lineWidth:2,dashPattern:[6,4]},selection:{strokeColor:Je.selected,fillColor:`${Je.selected}20`,lineWidth:2,dashPattern:[]},dragGhost:{strokeColor:Je.selectionBorder,fillColor:Je.dragGhost,lineWidth:2,dashPattern:[8,6]}};function Ys(e){return Number.isFinite(e)&&e>0}function Mo(e){return e?Number.isFinite(e.left)&&Number.isFinite(e.top)&&Ys(e.width)&&Ys(e.height):!1}function Sr(e){return e?Number.isFinite(e.x1)&&Number.isFinite(e.y1)&&Number.isFinite(e.x2)&&Number.isFinite(e.y2):!1}function kr(e,t,n){return Number.isFinite(e)?Math.min(n,Math.max(t,e)):t}function js(e){return 1-Math.pow(1-e,3)}function Cr(e,t,n){return e+(t-e)*n}function Ks(e,t,n){return{left:Cr(e.left,t.left,n),top:Cr(e.top,t.top,n),width:Cr(e.width,t.width,n),height:Cr(e.height,t.height,n)}}function If(e,t,n,r,o,i){const s=Math.max(0,Math.min(i,Math.min(r,o)/2));e.moveTo(t+s,n),e.arcTo(t+r,n,t+r,n+o,s),e.arcTo(t+r,n+o,t,n+o,s),e.arcTo(t,n+o,t,n,s),e.arcTo(t,n,t+r,n,s),e.closePath()}function Lf(e){const{container:t}=e,n=new Pe,r=t.querySelector(`canvas[${Ws}="${Xs}"]`);r&&r.remove();const o=document.createElement("canvas");o.setAttribute(Ws,Xs),o.setAttribute("aria-hidden","true"),Object.assign(o.style,{position:"absolute",inset:"0",width:"100%",height:"100%",pointerEvents:"none",display:"block"}),t.append(o),n.add(()=>o.remove());const i=o.getContext("2d",{alpha:!0,desynchronized:!0});if(!i)throw n.dispose(),new Error(`${_e} Failed to get canvas 2D context`);const s=i;let a=null,l=null,c=null,u=null,f=null,m=null,h=null,d=1,b=1,S=1,g=!0,k=null;function v(){k!==null&&(cancelAnimationFrame(k),k=null)}n.add(v);function L(){k!==null||n.isDisposed||(k=requestAnimationFrame(()=>{k=null,E()}))}function A(){const M=Math.max(1,window.devicePixelRatio||1),W=Math.max(1,d),C=Math.max(1,b),p=Math.round(W*M),y=Math.round(C*M);return o.width!==p||o.height!==y||Math.abs(S-M)>.001?(S=M,o.width=p,o.height=y,s.setTransform(S,0,0,S,0,0),s.lineJoin="round",s.lineCap="round",!0):!1}function O(){A(),s.clearRect(0,0,d,b)}function V(M,W){if(!Mo(M))return;const C=Math.round(M.width),p=Math.round(M.height);if(C<=0||p<=0)return;const y=Math.round(M.left)+.5,R=Math.round(M.top)+.5;s.save(),s.lineWidth=W.lineWidth,s.strokeStyle=W.strokeColor,s.fillStyle=W.fillColor,s.setLineDash(W.dashPattern),s.beginPath(),s.rect(y,R,C,p),s.fill(),s.stroke(),s.restore()}function F(M){if(!Sr(M))return;s.save(),s.lineWidth=Qa,s.strokeStyle=Je.insertionLine,s.setLineDash([]),s.lineCap="round";const W=Math.round(M.x1)+.5,C=Math.round(M.y1)+.5,p=Math.round(M.x2)+.5,y=Math.round(M.y2)+.5;s.beginPath(),s.moveTo(W,C),s.lineTo(p,y),s.stroke(),s.restore()}function T(M){if(!(!M||M.length===0)){s.save(),s.lineWidth=nl,s.strokeStyle=Je.guideLine,s.setLineDash([]),s.lineCap="round",s.beginPath();for(const W of M){if(!Sr(W))continue;const C=Math.round(W.x1)+.5,p=Math.round(W.y1)+.5,y=Math.round(W.x2)+.5,R=Math.round(W.y2)+.5;s.moveTo(C,p),s.lineTo(y,R)}s.stroke(),s.restore()}}function P(M){if(!M||M.length===0)return;s.save(),s.lineWidth=ol,s.strokeStyle=Je.guideLine,s.setLineDash([]),s.lineCap="round";const W=il;s.beginPath();for(const C of M){const p=C.line;if(!Sr(p))continue;const y=Math.round(p.x1)+.5,R=Math.round(p.y1)+.5,B=Math.round(p.x2)+.5,Y=Math.round(p.y2)+.5;s.moveTo(y,R),s.lineTo(B,Y),C.axis==="x"?(s.moveTo(y,R-W),s.lineTo(y,R+W),s.moveTo(B,Y-W),s.lineTo(B,Y+W)):(s.moveTo(y-W,R),s.lineTo(y+W,R),s.moveTo(B-W,Y),s.lineTo(B+W,Y))}s.stroke(),s.font=sl,s.textAlign="center",s.textBaseline="middle";for(const C of M){const p=C.line;if(!Sr(p))continue;const y=s.measureText(C.text),R=y.width,B=Number.isFinite(y.actualBoundingBoxAscent)?y.actualBoundingBoxAscent:8,Y=Number.isFinite(y.actualBoundingBoxDescent)?y.actualBoundingBoxDescent:3,Q=B+Y,te=Math.ceil(R+al*2),se=Math.ceil(Q+ll*2),pe=(p.x1+p.x2)/2,xe=(p.y1+p.y2)/2,we=ul;let H=pe-te/2,ae=xe-se/2;C.axis==="x"?(ae=xe-se/2-we,ae<0&&(ae=xe+we-se/2)):(H=pe+we-te/2,H+te>d&&(H=pe-we-te/2));const ne=Math.max(2,d-te-2),me=Math.max(2,b-se-2);H=kr(H,2,ne),ae=kr(ae,2,me),s.save(),s.fillStyle=Je.distanceLabelBg,s.strokeStyle=Je.distanceLabelBorder,s.lineWidth=1,s.beginPath(),If(s,H,ae,te,se,cl),s.fill(),s.stroke(),s.fillStyle=Je.distanceLabelText,s.fillText(C.text,H+te/2,ae+se/2),s.restore()}s.restore()}function j(){n.isDisposed||(g=!0,L())}function E(){if(n.isDisposed||!g)return;v(),g=!1;const M=performance.now();let W=a;if(l){const C=M-l.startTime,p=kr(C/l.durationMs,0,1),y=js(p);W=Ks(l.start,l.end,y),p>=1?l=null:g=!0}O(),V(W,Lo.hover),V(c,Lo.selection),V(u,Lo.dragGhost),F(f),T(m),P(h),g&&L()}function w(M,W){if(!((W==null?void 0:W.animate)===!0)){l=null,a=M,j();return}const p=performance.now();let y=a;if(l){const R=p-l.startTime,B=kr(R/l.durationMs,0,1),Y=js(B);y=Ks(l.start,l.end,Y)}if(!Mo(y)||!Mo(M)){l=null,a=M,j();return}l={start:je({},y),end:je({},M),startTime:p,durationMs:Rf},a=M,j()}function D(M){c=M,j()}function $(M){u=M,j()}function x(M){f=M,j()}function I(M){m=M&&M.length>0?M:null,j()}function N(M){h=M&&M.length>0?M:null,j()}function _(){a=null,l=null,c=null,u=null,f=null,m=null,h=null,j()}try{const M=t.getBoundingClientRect();d=Math.max(1,M.width),b=Math.max(1,M.height)}catch(M){console.warn(`${_e} Initial size measurement failed:`,M)}return n.observeResize(t,M=>{const W=M[0],C=W==null?void 0:W.contentRect;if(!C)return;const p=Math.max(1,C.width),y=Math.max(1,C.height);Math.abs(p-d)<.5&&Math.abs(y-b)<.5||(d=p,b=y,j())}),j(),{canvas:o,markDirty:j,render:E,clear:_,setHoverRect:w,setSelectionRect:D,setDragGhostRect:$,setInsertionLine:x,setGuideLines:I,setDistanceLabels:N,dispose:()=>n.dispose()}}function ct(e){return typeof e=="number"&&Number.isFinite(e)}function Do(e){return e?ct(e.left)&&ct(e.top)&&ct(e.width)&&ct(e.height)&&e.width>.5&&e.height>.5:!1}function Po(e){try{const t=e.getBoundingClientRect(),n={left:t.left,top:t.top,width:t.width,height:t.height};return Do(n)?n:null}catch(t){return null}}function Et(e){return e.left+e.width}function St(e){return e.top+e.height}function kn(e){return e.left+e.width/2}function Cn(e){return e.top+e.height/2}function qs(e,t){switch(t){case"left":return e.left;case"center":return kn(e);case"right":return Et(e)}}function Zs(e,t){switch(t){case"top":return e.top;case"middle":return Cn(e);case"bottom":return St(e)}}function Qs(){return{x:[],y:[]}}function Mf(e){const t=e.parentElement;if(!t)return Qs();const n=Po(e),r=n?kn(n):0,o=n?Cn(n):0,i=t.children,s=i.length;let a=-1;for(let b=0;b<s;b++)if(i[b]===e){a=b;break}if(a===-1)return Qs();const l=[];let c=0,u=1,f=1;for(;c<ai;){const b=a-u,S=a+f,g=b>=0,k=S<s;if(!g&&!k)break;if(g){const v=i[b],L=Po(v);if(L){const A=kn(L)-r,O=Cn(L)-o;l.push({rect:L,distanceSquared:A*A+O*O})}c++,u++}if(k&&c<ai){const v=i[S],L=Po(v);if(L){const A=kn(L)-r,O=Cn(L)-o;l.push({rect:L,distanceSquared:A*A+O*O})}c++,f++}}l.sort((b,S)=>b.distanceSquared-S.distanceSquared);const m=l.slice(0,tl),h=[],d=[];for(const{rect:b}of m)h.push({type:"left",value:b.left,source:"sibling",sourceRect:b}),h.push({type:"center",value:kn(b),source:"sibling",sourceRect:b}),h.push({type:"right",value:Et(b),source:"sibling",sourceRect:b}),d.push({type:"top",value:b.top,source:"sibling",sourceRect:b}),d.push({type:"middle",value:Cn(b),source:"sibling",sourceRect:b}),d.push({type:"bottom",value:St(b),source:"sibling",sourceRect:b});return{x:h,y:d}}function Df(){const e=Math.max(1,window.innerWidth||1),t=Math.max(1,window.innerHeight||1);return{x:[{type:"left",value:0,source:"viewport"},{type:"center",value:e/2,source:"viewport"},{type:"right",value:e,source:"viewport"}],y:[{type:"top",value:0,source:"viewport"},{type:"middle",value:t/2,source:"viewport"},{type:"bottom",value:t,source:"viewport"}]}}function Pf(...e){const t=[],n=[];for(const r of e)t.push(...r.x),n.push(...r.y);return{x:t,y:n}}function Oo(e,t,n,r,o){const i=e.left,s=Et(e);if(t==="left"){if(n==="right"){const a=r-i;return!ct(a)||a<o?null:{left:i,top:e.top,width:a,height:e.height}}if(n==="center"){const a=(r-i)*2;return!ct(a)||a<o?null:{left:i,top:e.top,width:a,height:e.height}}return e}if(t==="right"){if(n==="left"){const a=s-r;return!ct(a)||a<o?null:{left:r,top:e.top,width:a,height:e.height}}if(n==="center"){const a=2*r-s,l=s-a;return!ct(l)||l<o?null:{left:a,top:e.top,width:l,height:e.height}}return e}return e}function Fo(e,t,n,r,o){const i=e.top,s=St(e);if(t==="top"){if(n==="bottom"){const a=r-i;return!ct(a)||a<o?null:{left:e.left,top:i,width:e.width,height:a}}if(n==="middle"){const a=(r-i)*2;return!ct(a)||a<o?null:{left:e.left,top:i,width:e.width,height:a}}return e}if(t==="bottom"){if(n==="top"){const a=s-r;return!ct(a)||a<o?null:{left:e.left,top:r,width:e.width,height:a}}if(n==="middle"){const a=2*r-s,l=s-a;return!ct(l)||l<o?null:{left:e.left,top:a,width:e.width,height:l}}return e}return e}function Of(e,t,n,r,o,i){let s=null;for(const a of n){if(!r.includes(a.type))continue;const l=qs(e,a.type),c=Math.abs(a.value-l);if(c>o)continue;const u=Oo(e,t,a.type,a.value,i);if(!u)continue;(!s||c<s.distance||c===s.distance&&a.source==="sibling"&&s.anchor.source!=="sibling")&&(s={distance:c,anchor:a,snappedRect:u})}return s}function Ff(e,t,n,r,o,i){let s=null;for(const a of n){if(!r.includes(a.type))continue;const l=Zs(e,a.type),c=Math.abs(a.value-l);if(c>o)continue;const u=Fo(e,t,a.type,a.value,i);if(!u)continue;(!s||c<s.distance||c===s.distance&&a.source==="sibling"&&s.anchor.source!=="sibling")&&(s={distance:c,anchor:a,snappedRect:u})}return s}function Bf(e,t,n,r){const o=[],i=Math.max(1,r.width),s=Math.max(1,r.height);if(t){const a=t.value;if(t.source==="viewport"||!t.sourceRect)o.push({x1:a,y1:0,x2:a,y2:s});else{const l=t.sourceRect,c=Math.min(l.top,e.top),u=Math.max(St(l),St(e));o.push({x1:a,y1:c,x2:a,y2:u})}}if(n){const a=n.value;if(n.source==="viewport"||!n.sourceRect)o.push({x1:0,y1:a,x2:i,y2:a});else{const l=n.sourceRect,c=Math.min(l.left,e.left),u=Math.max(Et(l),Et(e));o.push({x1:c,y1:a,x2:u,y2:a})}}return o}function Vf(e){var S,g;const{rect:t,resize:n,anchors:r,thresholdPx:o,hysteresisPx:i,minSizePx:s,viewport:a}=e;if(!Do(t))return{snappedRect:t,guideLines:[],lockX:null,lockY:null};const l=n.hasWest?"right":n.hasEast?"left":null,c=n.hasNorth?"bottom":n.hasSouth?"top":null,u=l==="left"?["right","center"]:l==="right"?["left","center"]:[],f=c==="top"?["bottom","middle"]:c==="bottom"?["top","middle"]:[];let m=je({},t),h=e.lockX,d=e.lockY;if(l){if(h)if(!u.includes(h.type))h=null;else{const k=qs(m,h.type),v=Math.abs(h.value-k),L=Oo(m,l,h.type,h.value,s);(v>o+i||!L)&&(h=null)}if(h){const k=Oo(m,l,h.type,h.value,s);k&&(m=k)}else{const k=Of(m,l,r.x,u,o,s);k&&(h={type:k.anchor.type,value:k.anchor.value,source:k.anchor.source,sourceRect:(S=k.anchor.sourceRect)!=null?S:null},m=k.snappedRect)}}else h=null;if(c){if(d)if(!f.includes(d.type))d=null;else{const k=Zs(m,d.type),v=Math.abs(d.value-k),L=Fo(m,c,d.type,d.value,s);(v>o+i||!L)&&(d=null)}if(d){const k=Fo(m,c,d.type,d.value,s);k&&(m=k)}else{const k=Ff(m,c,r.y,f,o,s);k&&(d={type:k.anchor.type,value:k.anchor.value,source:k.anchor.source,sourceRect:(g=k.anchor.sourceRect)!=null?g:null},m=k.snappedRect)}}else d=null;const b=Bf(m,h,d,a);return{snappedRect:m,guideLines:b,lockX:h,lockY:d}}function Wt(e,t){return ct(e)&&e>0&&e>=t}function Xt(e){const t=Math.round(e);return`${Object.is(t,-0)?0:t}px`}function Js(e,t,n){return ct(e)?Math.min(n,Math.max(t,e)):t}function $f(e){const{rect:t,lockX:n,lockY:r,viewport:o,minGapPx:i}=e;if(!Do(t))return[];const s=ct(o.width)?Math.max(1,o.width):1,a=ct(o.height)?Math.max(1,o.height):1,l=Math.max(0,i),c=[];if(n&&n.source==="sibling"&&n.sourceRect){const u=n.sourceRect,f=t.top-St(u),m=u.top-St(t);Wt(f,l)?c.push({kind:"sibling",axis:"y",value:Math.round(f),text:Xt(f),line:{x1:n.value,y1:St(u),x2:n.value,y2:t.top}}):Wt(m,l)&&c.push({kind:"sibling",axis:"y",value:Math.round(m),text:Xt(m),line:{x1:n.value,y1:St(t),x2:n.value,y2:u.top}})}if(r&&r.source==="sibling"&&r.sourceRect){const u=r.sourceRect,f=t.left-Et(u),m=u.left-Et(t);Wt(f,l)?c.push({kind:"sibling",axis:"x",value:Math.round(f),text:Xt(f),line:{x1:Et(u),y1:r.value,x2:t.left,y2:r.value}}):Wt(m,l)&&c.push({kind:"sibling",axis:"x",value:Math.round(m),text:Xt(m),line:{x1:Et(t),y1:r.value,x2:u.left,y2:r.value}})}if(n&&n.source==="viewport"){const u=Js(Cn(t),0,a),f=t.left,m=s-Et(t),h=()=>Wt(f,l)?(c.push({kind:"viewport",axis:"x",value:Math.round(f),text:Xt(f),line:{x1:0,y1:u,x2:t.left,y2:u}}),!0):!1,d=()=>Wt(m,l)?(c.push({kind:"viewport",axis:"x",value:Math.round(m),text:Xt(m),line:{x1:Et(t),y1:u,x2:s,y2:u}}),!0):!1;n.type==="center"?(h(),d()):n.type==="left"?h()||d():d()||h()}if(r&&r.source==="viewport"){const u=Js(kn(t),0,s),f=t.top,m=a-St(t),h=()=>Wt(f,l)?(c.push({kind:"viewport",axis:"y",value:Math.round(f),text:Xt(f),line:{x1:u,y1:0,x2:u,y2:t.top}}),!0):!1,d=()=>Wt(m,l)?(c.push({kind:"viewport",axis:"y",value:Math.round(m),text:Xt(m),line:{x1:u,y1:St(t),x2:u,y2:a}}),!0):!1;r.type==="middle"?(h(),d()):r.type==="top"?h()||d():d()||h()}return c}const zn=1,Hf=3,zf=["nw","n","ne","e","se","s","sw","w"],Uf={n:"ns-resize",s:"ns-resize",e:"ew-resize",w:"ew-resize",ne:"nesw-resize",sw:"nesw-resize",nw:"nwse-resize",se:"nwse-resize"};function Ar(e){return typeof e=="number"&&Number.isFinite(e)}function Tr(e){return e?Ar(e.left)&&Ar(e.top)&&Ar(e.width)&&Ar(e.height)&&e.width>.5&&e.height>.5:!1}function Nr(e,t){return Number.isFinite(e)?e<t?t:e:t}function Yt(e){const t=e.trim();if(!t||t==="auto"||t==="none")return null;const n=t.match(/^(-?\d+(?:\.\d+)?)px$/);if(n){const o=Number(n[1]);return Number.isFinite(o)?o:null}const r=Number(t);return Number.isFinite(r)?r:null}function jt(e){if(!Number.isFinite(e))return"0px";const t=Math.round(e*100)/100;return`${Object.is(t,-0)?0:t}px`}function Gf(e){const t=e.trim().toLowerCase();return t==="fixed"?"fixed":t==="absolute"?"absolute":t==="relative"||t==="sticky"?"relative":"static"}function ea(e){return e==="w"||e==="nw"||e==="sw"}function Bo(e){return e==="e"||e==="ne"||e==="se"}function ta(e){return e==="n"||e==="nw"||e==="ne"}function Vo(e){return e==="s"||e==="sw"||e==="se"}function Wf(e){try{const t=e.getBoundingClientRect();return!Number.isFinite(t.left)||!Number.isFinite(t.top)||!Number.isFinite(t.width)||!Number.isFinite(t.height)?null:{left:t.left,top:t.top,width:Math.max(0,t.width),height:Math.max(0,t.height)}}catch(t){return null}}function na(e){try{return window.getComputedStyle(e)}catch(t){return null}}function _r(e,t,n){var i,s;const r=(i=Yt(e.getPropertyValue(t)))!=null?i:0,o=(s=Yt(e.getPropertyValue(n)))!=null?s:0;return r+o}function Xf(e){const n=e.getPropertyValue("box-sizing").trim()==="border-box"?"border-box":"content-box",r=_r(e,"padding-left","padding-right"),o=_r(e,"padding-top","padding-bottom"),i=_r(e,"border-left-width","border-right-width"),s=_r(e,"border-top-width","border-bottom-width");return{boxSizing:n,horizontalExtras:r+i,verticalExtras:o+s}}function ra(e,t,n){return n==="border-box"?e:Math.max(0,e-t)}function Yf(e){var t,n;try{const r=e.offsetParent;if(r instanceof HTMLElement){const o=r.getBoundingClientRect(),i=na(r),s=i&&(t=Yt(i.getPropertyValue("border-left-width")))!=null?t:0,a=i&&(n=Yt(i.getPropertyValue("border-top-width")))!=null?n:0;return{originX:o.left+s,originY:o.top+a,scrollLeft:r.scrollLeft,scrollTop:r.scrollTop}}}catch(r){}return{originX:0,originY:0,scrollLeft:0,scrollTop:0}}function Rr(e){e.cancelable&&e.preventDefault(),e.stopPropagation()}function jf(e){const t=new Pe,{container:n,canvasOverlay:r,transactionManager:o,positionTracker:i}=e,s=document.createElement("div");s.className="we-handles-layer",s.setAttribute("aria-hidden","true"),n.append(s),t.add(()=>s.remove());const a=document.createElement("div");a.className="we-selection-frame",a.hidden=!0,s.append(a);const l=document.createElement("div");l.className="we-size-hud",l.hidden=!0,a.append(l);const c=new Map;for(const x of zf){const I=document.createElement("div");I.className="we-resize-handle",I.dataset.dir=x,I.tabIndex=-1,a.append(I),c.set(x,I)}let u=null,f=null,m=null,h=null;function d(){h!==null&&(cancelAnimationFrame(h),h=null)}t.add(d);function b(x){if(!(!!u&&Tr(x))){a.hidden=!0;return}a.hidden=!1,a.style.transform=`translate3d(${x.left}px, ${x.top}px, 0)`,a.style.width=`${x.width}px`,a.style.height=`${x.height}px`}function S(x){if(!x){l.hidden=!0,l.textContent="";return}l.hidden=!1,l.textContent=x}function g(x){document.body.style.cursor=x.prevBodyCursor,document.body.style.userSelect=x.prevBodyUserSelect}function k(x){const I=m;if(I){if(d(),m=null,I.tx)try{I.tx.rollback()}catch(N){console.warn(`${_e} Resize rollback failed:`,N)}try{g(I)}catch(N){}try{r.setGuideLines(null),r.setDistanceLabels(null),r.render()}catch(N){}S(null),b(f);try{i.forceUpdate()}catch(N){}x&&console.log(`${_e} Resize cancelled (${x})`)}}function v(){const x=m;if(x){if(d(),m=null,x.tx)try{x.tx.commit({merge:!1})}catch(I){console.warn(`${_e} Resize commit failed:`,I);try{x.tx.rollback()}catch(N){}}try{g(x)}catch(I){}try{r.setGuideLines(null),r.setDistanceLabels(null),r.render()}catch(I){}S(null);try{i.forceUpdate()}catch(I){}}}function L(){h!==null||t.isDisposed||(h=requestAnimationFrame(()=>{h=null,A()}))}function A(){const x=m;if(!x)return;if(!x.target.isConnected){k("target_disconnected");return}const I=x.lastClientX-x.startClientX,N=x.lastClientY-x.startClientY;if(!x.hasPassedThreshold){if(Math.hypot(I,N)<Hf)return;x.hasPassedThreshold=!0;const te=o.beginMultiStyle(x.target,Array.from(x.properties));if(!te){k("tx_unavailable");return}x.tx=te;try{const se=Mf(x.target),pe=Df();x.anchors=Pf(se,pe)}catch(se){x.anchors=null}}const _=x.tx;if(!_){k("tx_missing");return}let M=x.startRect.width,W=x.startRect.height;x.affectsWidth&&(Bo(x.dir)&&(M=Nr(x.startRect.width+I,zn)),ea(x.dir)&&(M=Nr(x.startRect.width-I,zn))),x.affectsHeight&&(Vo(x.dir)&&(W=Nr(x.startRect.height+N,zn)),ta(x.dir)&&(W=Nr(x.startRect.height-N,zn)));const C=x.hasWest?x.startRect.width-M:0,p=x.hasNorth?x.startRect.height-W:0,y={left:x.startRect.left+C,top:x.startRect.top+p,width:M,height:W};let R=y;if(x.anchors){const te=Bo(x.dir),se=Vo(x.dir),pe=Vf({rect:y,resize:{hasWest:x.hasWest,hasEast:te,hasNorth:x.hasNorth,hasSouth:se},anchors:x.anchors,thresholdPx:Ja,hysteresisPx:el,minSizePx:zn,lockX:x.lockX,lockY:x.lockY,viewport:{width:window.innerWidth||1,height:window.innerHeight||1}});x.lockX=pe.lockX,x.lockY=pe.lockY,R=pe.snappedRect;const xe=$f({rect:R,lockX:x.lockX,lockY:x.lockY,minGapPx:rl,viewport:{width:window.innerWidth||1,height:window.innerHeight||1}}),we=pe.guideLines.length>0,H=xe.length>0;if(we||x.hadGuidesLastFrame||H||x.hadDistanceLabelsLastFrame){try{r.setGuideLines(we?pe.guideLines:null),r.setDistanceLabels(H?xe:null),r.render()}catch(ae){}x.hadGuidesLastFrame=we,x.hadDistanceLabelsLastFrame=H}M=R.width,W=R.height}const B=R.left-x.startRect.left,Y=R.top-x.startRect.top;b(R),S(`${Math.round(R.width)} × ${Math.round(R.height)}`);const Q={};if(x.affectsWidth){const te=ra(M,x.extras.horizontalExtras,x.extras.boxSizing);Q.width=jt(te)}if(x.affectsHeight){const te=ra(W,x.extras.verticalExtras,x.extras.boxSizing);Q.height=jt(te)}x.mode==="absolute"||x.mode==="fixed"?(x.affectsWidth&&(Q.left=jt(x.startPosX+B),Q.right=""),x.affectsHeight&&(Q.top=jt(x.startPosY+Y),Q.bottom="")):x.mode==="relative"?(x.affectsWidth&&x.hasWest&&(Q.left=jt(x.startPosX+B)),x.affectsHeight&&x.hasNorth&&(Q.top=jt(x.startPosY+Y))):(x.affectsWidth&&x.hasWest&&(Q["margin-left"]=jt(x.startPosX+B)),x.affectsHeight&&x.hasNorth&&(Q["margin-top"]=jt(x.startPosY+Y)));try{_.set(Q)}catch(te){console.warn(`${_e} Resize preview apply failed:`,te),k("apply_failed")}}function O(x,I,N){var le,be,Te,Ne;if(t.isDisposed||N.button!==0)return;const _=u;if(!_||!_.isConnected)return;m&&k("restart");const M=na(_);if(!M)return;const W=M.getPropertyValue("transform").trim();if(W&&W!=="none"){console.warn(`${_e} Resize handles do not support transformed elements yet`);return}const C=M.getPropertyValue("position"),p=Gf(C),y=ea(x),R=ta(x),B=y||Bo(x),Y=R||Vo(x),Q=M.getPropertyValue("margin-left").trim().toLowerCase(),te=M.getPropertyValue("margin-top").trim().toLowerCase(),se=(le=Yt(Q))!=null?le:0,pe=(be=Yt(te))!=null?be:0;if(p==="static"){if(y&&Q==="auto"){console.warn(`${_e} Resize from west is disabled when margin-left is auto`);return}if(R&&te==="auto"){console.warn(`${_e} Resize from north is disabled when margin-top is auto`);return}}const xe=Tr(f)?f:Wf(_);if(!xe||!Tr(xe))return;const we=[];B&&(we.push("width"),p==="absolute"||p==="fixed"?we.push("left","right"):p==="relative"?y&&we.push("left"):y&&we.push("margin-left")),Y&&(we.push("height"),p==="absolute"||p==="fixed"?we.push("top","bottom"):p==="relative"?R&&we.push("top"):R&&we.push("margin-top"));let H=null,ae=0,ne=0;p==="absolute"?(H=Yf(_),ae=B?xe.left-se-H.originX+H.scrollLeft:0,ne=Y?xe.top-pe-H.originY+H.scrollTop:0):p==="fixed"?(H={originX:0,originY:0,scrollLeft:0,scrollTop:0},ae=B?xe.left-se:0,ne=Y?xe.top-pe:0):p==="relative"?(ae=B&&y&&(Te=Yt(M.getPropertyValue("left")))!=null?Te:0,ne=Y&&R&&(Ne=Yt(M.getPropertyValue("top")))!=null?Ne:0):(ae=B&&y?se:0,ne=Y&&R?pe:0);const me=Xf(M),z=document.body.style.cursor,J=document.body.style.userSelect;m={pointerId:N.pointerId,dir:x,handleEl:I,target:_,mode:p,properties:we,tx:null,hasPassedThreshold:!1,affectsWidth:B,affectsHeight:Y,hasWest:y,hasNorth:R,anchors:null,lockX:null,lockY:null,hadGuidesLastFrame:!1,hadDistanceLabelsLastFrame:!1,startClientX:N.clientX,startClientY:N.clientY,lastClientX:N.clientX,lastClientY:N.clientY,startRect:xe,startPosX:ae,startPosY:ne,absOrigin:H,extras:me,prevBodyCursor:z,prevBodyUserSelect:J};try{I.setPointerCapture(N.pointerId)}catch(Z){}document.body.style.cursor=Uf[x],document.body.style.userSelect="none",Rr(N),b(xe),L()}function V(x){const I=m;I&&x.pointerId===I.pointerId&&(Rr(x),I.lastClientX=x.clientX,I.lastClientY=x.clientY,L())}function F(x){const I=m;I&&x.pointerId===I.pointerId&&(Rr(x),I.lastClientX=x.clientX,I.lastClientY=x.clientY,v())}function T(x){const I=m;I&&x.pointerId===I.pointerId&&(Rr(x),k(x.type))}function P(x){m&&x.key==="Escape"&&(x.preventDefault(),x.stopImmediatePropagation(),x.stopPropagation(),k("escape"))}function j(){m&&k("blur")}function E(){m&&document.visibilityState!=="visible"&&k("visibilitychange")}for(const[x,I]of c)t.listen(I,"pointerdown",N=>O(x,I,N)),t.listen(I,"pointermove",V),t.listen(I,"pointerup",F),t.listen(I,"pointercancel",T),t.listen(I,"lostpointercapture",T);t.listen(document,"keydown",P,{capture:!0}),t.listen(window,"blur",j),t.listen(document,"visibilitychange",E);function w(x){t.isDisposed||(m&&k("target_change"),x instanceof HTMLElement&&x.isConnected?u=x:u=null,b(f))}function D(x){if(!t.isDisposed){if(f=Tr(x)?x:null,!u||!u.isConnected){a.hidden=!0;return}if(m&&!f){k("rect_lost");return}m||b(f)}}function $(){k("dispose"),u=null,f=null,t.dispose()}return b(null),{setTarget:w,setSelectionRect:D,dispose:$}}function Ir(e){return e instanceof Document||e instanceof ShadowRoot}function oa(e){var n;const t=(n=e.tagName)==null?void 0:n.toUpperCase();return t==="HTML"||t==="BODY"||t==="HEAD"}function Kf(e){const{left:t,top:n,width:r,height:o}=e;return!Number.isFinite(t)||!Number.isFinite(n)||!Number.isFinite(r)||!Number.isFinite(o)?null:{left:t,top:n,width:Math.max(0,r),height:Math.max(0,o)}}function qf(e,t,n){if(!Number.isFinite(t)||!Number.isFinite(n))return[];try{if(typeof e.elementsFromPoint=="function")return e.elementsFromPoint(t,n)}catch(r){}try{const r=e.elementFromPoint(t,n);return r?[r]:[]}catch(r){return[]}}function Zf(e){try{const t=window.getComputedStyle(e),n=t.display;if(n==="grid"||n==="inline-grid")return null;if(n==="flex"||n==="inline-flex"){const r=t.flexWrap;if(r==="wrap"||r==="wrap-reverse")return null;switch(t.flexDirection){case"row":return{axis:"x",reverse:!1};case"row-reverse":return{axis:"x",reverse:!0};case"column":return{axis:"y",reverse:!1};case"column-reverse":return{axis:"y",reverse:!0};default:return{axis:"y",reverse:!1}}}return{axis:"y",reverse:!1}}catch(t){return null}}function Qf(e,t,n,r,o){const i=r==="x"?t.left+t.width/2:t.top+t.height/2,s=o?-e:e,a=o?-i:i;return n?n==="before"?s>a+hn?"after":"before":s<a-hn?"before":"after":s<a?"before":"after"}function ia(e,t,n){return e.parentNode!==t?!1:n===e||n===e.nextSibling||n===null&&e.nextSibling===null}function Jf(e,t,n,r){var i;if(!e.isConnected||r(e)||e===t||oa(e)||t.contains(e)||!e.parentElement)return!1;const o=(i=e.getRootNode)==null?void 0:i.call(e);return!(!Ir(o)||o!==n)}function ep(e){const t=new Pe,{canvasOverlay:n,isOverlayElement:r,positionTracker:o,transactionManager:i,uiRoot:s}=e;let a=null,l=null;function c(){l!==null&&(cancelAnimationFrame(l),l=null)}t.add(c);function u(A,O){s.style.pointerEvents=A?O.uiPointerEventsBefore:"none"}function f(){n.setDragGhostRect(null),n.setInsertionLine(null),n.render()}function m(){const A=a;A&&(c(),u(!0,A),f(),a=null)}function h(A){const V=qf(A.draggedRoot,A.lastClientX,A.lastClientY).slice(0,Za).find(I=>Jf(I,A.draggedElement,A.draggedRoot,r));if(!V)return null;const F=V.parentElement;if(!F)return null;const T=Zf(F);if(!T)return null;let P;try{P=V.getBoundingClientRect()}catch(I){return null}if(!Number.isFinite(P.left)||!Number.isFinite(P.top)||P.width<=.5||P.height<=.5)return null;const j=A.preview&&A.preview.target===V?A.preview.side:null,E=T.axis==="x"?A.lastClientX:A.lastClientY,w=Qf(E,P,j,T.axis,T.reverse),D=w==="before"?V:V.nextSibling,$=ia(A.draggedElement,F,D);let x;if(T.axis==="x"){const I=T.reverse?P.left+P.width:P.left,N=T.reverse?P.left:P.left+P.width,_=w==="before"?I:N;x={x1:_,y1:P.top,x2:_,y2:P.top+P.height}}else{const I=T.reverse?P.top+P.height:P.top,N=T.reverse?P.top:P.top+P.height,_=w==="before"?I:N;x={x1:P.left,y1:_,x2:P.left+P.width,y2:_}}return{target:V,parent:F,side:w,referenceNode:D,isNoop:$,indicatorLine:x}}function d(){var V,F;l=null;const A=a;if(!A)return;if(!A.draggedElement.isConnected){A.moveHandle.cancel(),m();return}const O={left:A.lastClientX-A.pointerOffsetX,top:A.lastClientY-A.pointerOffsetY,width:A.startRect.width,height:A.startRect.height};A.preview=h(A),n.setDragGhostRect(O),n.setInsertionLine((F=(V=A.preview)==null?void 0:V.indicatorLine)!=null?F:null),n.render()}function b(){t.isDisposed||l===null&&(l=requestAnimationFrame(d))}function S(A,O){var j,E;const V=O.parent;if(!V.isConnected||A===V||A.contains(V))return!1;const F=(j=A.getRootNode)==null?void 0:j.call(A),T=(E=V.getRootNode)==null?void 0:E.call(V);if(!Ir(F)||!Ir(T)||F!==T||!O.target.isConnected||O.target.parentElement!==V)return!1;const P=O.side==="before"?O.target:O.target.nextSibling;if(ia(A,V,P))return!0;try{return V.insertBefore(A,P),!0}catch(w){return console.warn(`${_e} DOM move failed:`,w),!1}}function g(A){var w;if(t.isDisposed)return!1;a&&(a.moveHandle.cancel(),m());const O=A.draggedElement;if(!O||!(O instanceof Element)||!O.isConnected||oa(O))return!1;const V=(w=O.getRootNode)==null?void 0:w.call(O),F=Ir(V)?V:document;let T;try{T=O.getBoundingClientRect()}catch(D){return!1}const P=Kf(T);if(!P||P.width<=.5||P.height<=.5)return!1;const j=i.beginMove(O);if(!j)return!1;const E=s.style.pointerEvents;return a={pointerId:A.pointerId,draggedElement:O,draggedRoot:F,startRect:P,pointerOffsetX:A.startClientX-P.left,pointerOffsetY:A.startClientY-P.top,lastClientX:A.clientX,lastClientY:A.clientY,preview:null,uiPointerEventsBefore:E,moveHandle:j},u(!1,a),b(),console.log(`${_e} Drag started`),!0}function k(A){const O=a;O&&A.pointerId===O.pointerId&&(O.lastClientX=A.clientX,O.lastClientY=A.clientY,b())}function v(A){const O=a;if(!O||A.pointerId!==O.pointerId)return;O.lastClientX=A.clientX,O.lastClientY=A.clientY,c();const V=h(O);if(!V||V.isNoop){O.moveHandle.cancel(),m(),console.log(`${_e} Drag cancelled (no-op or no target)`);return}if(!S(O.draggedElement,V)){O.moveHandle.cancel(),m(),console.log(`${_e} Drag failed (DOM move error)`);return}O.moveHandle.commit(O.draggedElement),o.forceUpdate(),m(),console.log(`${_e} Drag completed`)}function L(A){const O=a;O&&(O.moveHandle.cancel(),m(),console.log(`${_e} Drag cancelled`))}return t.add(()=>{const A=a;A&&(A.moveHandle.cancel(),m())}),{onDragStart:g,onDragMove:k,onDragEnd:v,onDragCancel:L,dispose:()=>t.dispose()}}const zt={capture:!0,passive:!1},tp=["pointerup","pointercancel","pointerover","pointerout","pointerenter","pointerleave"],np=["mouseup","click","dblclick","contextmenu","auxclick","mouseover","mouseout","mouseenter","mouseleave"],rp=["keyup","keypress"],op=["touchstart","touchmove","touchend","touchcancel"];function ip(e){const{isOverlayElement:t,onHover:n,onSelect:r,onDeselect:o,onStartEdit:i,findTargetForSelect:s,getSelectedElement:a,onStartDrag:l,onDragMove:c,onDragEnd:u,onDragCancel:f}=e,m=new Pe,h=typeof PointerEvent!="undefined";let d="hover",b=null,S=null,g=null,k=null,v=!1,L=!1,A=!1,O=0,V=0,F=null;function T(H){try{if(typeof H.composedPath=="function")return H.composedPath().some(ae=>t(ae))}catch(ae){}return t(H.target)}function P(H){const ae=S;if(!ae)return!1;try{if(typeof H.composedPath=="function")return H.composedPath().some(me=>me===ae)}catch(me){}const ne=H.target;return ne instanceof Node&&ae.contains(ne)}function j(H){H.cancelable&&H.preventDefault(),H.stopImmediatePropagation(),H.stopPropagation()}function E(H){return{alt:H.altKey,shift:H.shiftKey,ctrl:H.ctrlKey,meta:H.metaKey}}function w(H){return H instanceof PointerEvent?H.pointerId:0}function D(H){return!(h&&!(H instanceof PointerEvent))}function $(H,ae){try{if(typeof H.composedPath=="function")return H.composedPath().some(me=>me===ae)}catch(me){}const ne=H.target;return ne instanceof Node&&ae.contains(ne)}function x(){g=null,k=null,v=!1}function I(H){if(d==="dragging"){x();try{f==null||f({reason:H})}catch(ae){}L=!0,y("selecting")}}function N(H,ae,ne){if(d==="dragging"&&!(k===null||k!==H)){x();try{u==null||u({pointerId:H,clientX:ae,clientY:ne})}catch(me){}L=!0,y("selecting")}}function _(H,ae){if(!Number.isFinite(H)||!Number.isFinite(ae))return null;const ne=document.elementFromPoint(H,ae);return!ne||t(ne)?null:ne}function M(H,ae,ne,me){if(!Number.isFinite(ae)||!Number.isFinite(ne))return null;if(s){const z=s(ae,ne,me,H);return z&&t(z)?null:z}return _(ae,ne)}function W(){F!==null&&(cancelAnimationFrame(F),F=null)}m.add(W);function C(H=!1){if(F=null,m.isDisposed||d!=="hover"&&d!=="selecting"||!A)return;const ae=_(O,V);!H&&ae===b||(b=ae,n(ae))}function p(H=!1){F===null&&(m.isDisposed||(F=requestAnimationFrame(()=>{C(H)})))}function y(H){if(m.isDisposed||d===H)return;const ae=d;if(d=H,ae==="editing"&&H!=="editing"&&(S=null),ae==="selecting"&&H!=="selecting"&&(g=null),ae==="dragging"&&H!=="dragging"){const ne=!L;if(L=!1,x(),ne)try{f==null||f({reason:"mode_change"})}catch(me){}}else L=!1;ae==="hover"&&H!=="hover"&&(W(),b=null),H==="hover"&&ae!=="hover"&&(b=null,x(),o(),A&&p(!0))}function R(H){var ae;if(!(d==="editing"&&P(H))){if(T(H)){d==="hover"&&b!==null&&(b=null,n(null));return}if(j(H),O=H.clientX,V=H.clientY,A=!0,d==="dragging"&&D(H)){const ne=w(H),me=H instanceof PointerEvent;if(v!==me)return;k!==null&&ne===k&&(c==null||c({pointerId:ne,clientX:H.clientX,clientY:H.clientY}));return}if(d==="selecting"&&g&&D(H)){const ne=w(H);if(ne!==g.pointerId)return;const me=H instanceof PointerEvent;if(g.isPointerEventOrigin!==me)return;const z=H.clientX-g.startClientX,J=H.clientY-g.startClientY;if(Math.hypot(z,J)<Pt)return;const le={pointerId:ne,draggedElement:g.selectedElement,startClientX:g.startClientX,startClientY:g.startClientY,clientX:H.clientX,clientY:H.clientY,modifiers:g.modifiers},be=g.isPointerEventOrigin;if(g=null,!((ae=l==null?void 0:l(le))!=null?ae:!1))return;k=ne,v=be,y("dragging"),c==null||c({pointerId:ne,clientX:H.clientX,clientY:H.clientY});return}d!=="hover"&&d!=="selecting"||p()}}function B(H){var me;if(d==="editing"&&P(H)||T(H)||(j(H),O=H.clientX,V=H.clientY,A=!0,H.button!==0))return;const ae=E(H);if(d==="selecting"){if(!D(H))return;const z=(me=a==null?void 0:a())!=null?me:null,J=M(H,H.clientX,H.clientY,ae);if(J&&J!==z){g=null,r(J,ae);return}if(l&&z&&z.isConnected&&$(H,z)){const le=H instanceof PointerEvent;g={pointerId:w(H),startClientX:H.clientX,startClientY:H.clientY,modifiers:ae,selectedElement:z,isPointerEventOrigin:le}}return}if(d==="dragging")return;if(d==="editing"){const z=M(H,H.clientX,H.clientY,ae);y("selecting"),z&&r(z,ae);return}if(d!=="hover")return;const ne=M(H,H.clientX,H.clientY,ae);ne&&(y("selecting"),r(ne,ae))}function Y(H){if(d==="editing"&&P(H)||T(H)||(j(H),H.button!==0)||!i)return;const ae=E(H),ne=M(H,H.clientX,H.clientY,ae);!ne||!i(ne,ae)||(S=ne,y("editing"))}function Q(H){if(!(d==="editing"&&P(H))&&!T(H)&&(j(H),H.key==="Escape")){if(d==="dragging"){I("escape");return}d==="selecting"&&(g=null,y("hover"))}}function te(H){if(d==="editing"&&P(H)||T(H)||(j(H),!D(H)))return;const ae=w(H),ne=H instanceof PointerEvent;d==="selecting"&&g&&g.pointerId===ae&&g.isPointerEventOrigin===ne&&(g=null),d==="dragging"&&v===ne&&N(ae,H.clientX,H.clientY)}function se(H){if(d==="editing"&&P(H)||T(H))return;j(H);const ae=H.pointerId;g&&g.pointerId===ae&&g.isPointerEventOrigin&&(g=null),d==="dragging"&&v&&(k===null||k!==ae||I("pointercancel"))}function pe(H){if(!T(H)&&!(d==="editing"&&P(H))){if(H.type==="dblclick"){Y(H);return}if(H.type==="pointerup"||H.type==="mouseup"){te(H);return}if(H.type==="pointercancel"){se(H);return}j(H)}}if(h){m.listen(document,"pointermove",R,zt),m.listen(document,"pointerdown",B,zt);for(const H of tp)m.listen(document,H,pe,zt)}m.listen(document,"mousemove",R,zt),m.listen(document,"mousedown",B,zt);for(const H of np)m.listen(document,H,pe,zt);m.listen(document,"keydown",Q,zt);for(const H of rp)m.listen(document,H,pe,zt);for(const H of op)m.listen(document,H,pe,zt);function xe(){d==="selecting"&&g&&(g=null),d==="dragging"&&I("blur")}function we(){document.visibilityState!=="visible"&&(d==="selecting"&&g&&(g=null),d==="dragging"&&I("visibilitychange"))}return m.listen(window,"blur",xe),m.listen(document,"visibilitychange",we),m.add(()=>{if(d==="dragging")try{f==null||f({reason:"dispose"})}catch(H){}x()}),{getMode:()=>d,setMode:y,dispose:()=>m.dispose()}}const $o={passive:!0},sp=.5,sa={childList:!0,subtree:!0};function ap(e){const{left:t,top:n,width:r,height:o}=e;return!Number.isFinite(t)||!Number.isFinite(n)||!Number.isFinite(r)||!Number.isFinite(o)?null:{left:t,top:n,width:Math.max(0,r),height:Math.max(0,o)}}function Lr(e,t){return Math.abs(e-t)<sp}function aa(e,t){return e===t?!0:!e||!t?!1:Lr(e.left,t.left)&&Lr(e.top,t.top)&&Lr(e.width,t.width)&&Lr(e.height,t.height)}function lp(e,t){return aa(e.hover,t.hover)&&aa(e.selection,t.selection)}function cp(e){const{onPositionUpdate:t}=e,n=new Pe;let r=null,o=null,i={hover:null,selection:null},s=null;function a(){s!==null&&(cancelAnimationFrame(s),s=null)}n.add(a);function l(){n.isDisposed||s===null&&(s=requestAnimationFrame(()=>{s=null,d()}))}let c=new Pe;n.add(()=>c.dispose());function u(){var V,F;c.dispose(),c=new Pe;const v=o;if(!v)return;c.observeResize(v,()=>{n.isDisposed||o===v&&l()});const L=()=>{n.isDisposed||o===v&&l()},A=(V=v.getRootNode)==null?void 0:V.call(v);A instanceof ShadowRoot&&c.observeMutation(A,L,sa);const O=(F=document.body)!=null?F:document.documentElement;O&&c.observeMutation(O,L,sa)}function f(v){return v&&v.isConnected?v:null}function m(v){if(!v)return null;try{return ap(v.getBoundingClientRect())}catch(L){return null}}function h(){const v=f(r),L=f(o);if(r&&!v&&(r=null),o&&!L&&(o=null,u()),v&&L&&v===L){const A=m(v);return{hover:A,selection:A}}return{hover:m(v),selection:m(L)}}function d(){if(n.isDisposed)return;const v=h();lp(v,i)||(i=v,t(v))}function b(){!r&&!o&&!i.hover&&!i.selection||l()}n.listen(window,"scroll",b,$o),n.listen(document,"scroll",b,mt(je({},$o),{capture:!0})),n.listen(window,"resize",b,$o);function S(v){n.isDisposed||r!==v&&(r=v,l())}function g(v){n.isDisposed||o!==v&&(o=v,u(),l())}function k(){n.isDisposed||(a(),d())}return{setHoverElement:S,setSelectionElement:g,forceUpdate:k,dispose:()=>n.dispose()}}const up=8,dp=6,fp=60,Kt=.5,pp=new Set(["A","BUTTON","INPUT","SELECT","TEXTAREA","LABEL","SUMMARY","DETAILS"]),mp=new Set(["button","link","checkbox","radio","switch","tab","menuitem","option","combobox","textbox"]),hp=new Set(["DIV","SPAN","SECTION","ARTICLE","MAIN","HEADER","FOOTER","NAV","ASIDE"]);function Lt(e){const t=Number.parseFloat(e);return Number.isFinite(t)?t:0}function gp(e){const t=e.trim().toLowerCase();if(t==="transparent")return!0;const n=t.match(/^rgba?\((.+)\)$/);if(n){const o=n[1].split(",").map(i=>i.trim());if(o.length>=4){const i=Number.parseFloat(o[3]);return Number.isFinite(i)&&i<=.01}return!1}const r=t.match(/^hsla?\((.+)\)$/);if(r){const o=r[1].split(",").map(i=>i.trim());if(o.length>=4){const i=Number.parseFloat(o[3]);return Number.isFinite(i)&&i<=.01}return!1}return!1}function bp(e){var t;for(const n of Array.from(e.childNodes))if(n.nodeType===Node.TEXT_NODE&&((t=n.textContent)!=null&&t.trim()))return!0;return!1}function Un(e){var t;if(e.parentElement)return e.parentElement;try{const n=(t=e.getRootNode)==null?void 0:t.call(e);if(n instanceof ShadowRoot)return n.host}catch(n){}return null}function la(e,t){if(!Number.isFinite(e)||!Number.isFinite(t))return[];try{if(typeof document.elementsFromPoint=="function")return document.elementsFromPoint(e,t)}catch(r){}const n=document.elementFromPoint(e,t);return n?[n]:[]}function Ho(){const e=Math.max(1,window.innerWidth||1),t=Math.max(1,window.innerHeight||1);return e*t}function ca(e){try{const t=e.getBoundingClientRect();return!Number.isFinite(t.left)||!Number.isFinite(t.top)||!Number.isFinite(t.width)||!Number.isFinite(t.height)?null:t}catch(t){return null}}function ua(e,t){return e.display==="none"||e.visibility==="hidden"||e.visibility==="collapse"||Lt(e.opacity)<=.01||e.contentVisibility==="hidden"||t.width<=Kt||t.height<=Kt}function da(e,t){let n=0;const r=[];(!gp(t.backgroundColor)||t.backgroundImage!=="none")&&(n+=2,r.push("visual:background:+2")),[Lt(t.borderTopWidth),Lt(t.borderRightWidth),Lt(t.borderBottomWidth),Lt(t.borderLeftWidth)].some(a=>a>Kt)&&(t.borderTopStyle!=="none"||t.borderRightStyle!=="none"||t.borderBottomStyle!=="none"||t.borderLeftStyle!=="none")&&(n+=3,r.push("visual:border:+3")),t.boxShadow&&t.boxShadow!=="none"&&(n+=2,r.push("visual:shadow:+2")),t.outlineStyle!=="none"&&Lt(t.outlineWidth)>Kt&&(n+=1,r.push("visual:outline:+1"));const s=e.tagName.toUpperCase();return(s==="IMG"||s==="VIDEO"||s==="CANVAS"||s==="SVG")&&(n+=2,r.push("visual:media:+2")),e instanceof SVGElement&&s!=="SVG"&&(n-=1,r.push("visual:svg-sub:-1")),{points:n,reasons:r}}function fa(e,t){var s,a;let n=0;const r=[],o=e.tagName.toUpperCase();pp.has(o)&&(n+=6,r.push(`type:${o.toLowerCase()}:+6`));const i=(a=(s=e.getAttribute("role"))==null?void 0:s.toLowerCase())!=null?a:"";return i&&mp.has(i)&&(n+=4,r.push(`role:${i}:+4`)),e instanceof HTMLAnchorElement&&e.href&&(n+=2,r.push("attr:href:+2")),e instanceof HTMLElement&&(e.isContentEditable&&(n+=5,r.push("attr:contenteditable:+5")),e.tabIndex>=0&&(n+=2,r.push("focusable:+2"))),t.cursor==="pointer"&&(n+=2,r.push("cursor:pointer:+2")),{points:n,reasons:r}}function wp(e,t){let n=0;const r=[],o=e.width*e.height;if(!Number.isFinite(o)||o<=0)return n-=6,r.push("size:invalid:-6"),{points:n,reasons:r};e.width<4||e.height<4?(n-=6,r.push("size:tiny:-6")):o<256?(n-=4,r.push("size:small:-4")):o<1936&&(n-=1,r.push("size:below-tap-target:-1"));const i=t>0?o/t:0;return i>.85?(n-=8,r.push("size:huge:-8")):i>.6&&(n-=4,r.push("size:very-large:-4")),{points:n,reasons:r}}function xp(e){return Lt(e.paddingTop)>Kt||Lt(e.paddingRight)>Kt||Lt(e.paddingBottom)>Kt||Lt(e.paddingLeft)>Kt}function pa(e,t,n,r){if(t.display==="contents")return!0;if(r>0)return!1;const o=e.tagName.toUpperCase();return!(!hp.has(o)||e.children.length!==1||bp(e)||n>0||xp(t))}function ma(e,t){return e.hitOrder!==t.hitOrder?e.hitOrder-t.hitOrder:e.depthFromHit-t.depthFromHit}function yp(e){const t=new Pe,{isOverlayElement:n}=e;function r(m,h,d){if(!m.isConnected||n(m))return null;const b=m.tagName.toUpperCase();if(b==="HTML"||b==="BODY")return null;const S=ca(m);if(!S)return null;let g=h.get(m);if(g||(g=window.getComputedStyle(m),h.set(m,g)),ua(g,S))return null;const k=[];let v=0;const L=fa(m,g);v+=L.points,k.push(...L.reasons);const A=da(m,g);v+=A.points,k.push(...A.reasons);const O=wp(S,d);v+=O.points,k.push(...O.reasons);const V=pa(m,g,A.points,L.points);V&&(v-=8,k.push("wrapperOnly:-8")),b==="SPAN"&&L.points===0&&A.points===0&&(v-=2,k.push("inline:span:-2"));const F=S.width*S.height,T=d>0?F/d:0;return g.position==="fixed"&&T>.3&&(v-=2,k.push("position:fixed-large:-2")),{element:m,score:v,reasons:k,wrapperOnly:V}}function o(m,h){const d=la(m,h);if(d.length===0)return[];const b=new Map;function S(A,O){if(n(A)||b.size>=fp&&!b.has(A))return;const V=b.get(A);(!V||ma(O,V)<0)&&b.set(A,O)}const g=Math.min(d.length,up);for(let A=0;A<g;A++){const O=d[A];S(O,{hitOrder:A,depthFromHit:0});let V=O;for(let F=1;F<=dp&&(V=V?Un(V):null,!!V);F++)S(V,{hitOrder:A,depthFromHit:F})}const k=Ho(),v=new Map,L=[];for(const[A,O]of b){const V=r(A,v,k);V&&L.push(je(je({},V),O))}return L.sort((A,O)=>O.score!==A.score?O.score-A.score:ma(A,O)),L.map(F=>{var T=F,{hitOrder:A,depthFromHit:O}=T,V=qa(T,["hitOrder","depthFromHit"]);return V})}function i(m){let h=Un(m);if(!h)return null;const d=new Map;for(;h;){if(n(h))return null;const b=h.tagName.toUpperCase();if(b==="HTML"||b==="BODY")return null;const S=ca(h);if(!S){h=Un(h);continue}let g=d.get(h);if(g||(g=window.getComputedStyle(h),d.set(h,g)),ua(g,S)){h=Un(h);continue}const k=fa(h,g),v=da(h,g);if(!pa(h,g,v.points,k.points))return h;h=Un(h)}return null}function s(m,h,d){var g,k,v;const S=(k=(g=o(m,h)[0])==null?void 0:g.element)!=null?k:null;return S?d.alt&&(v=i(S))!=null?v:S:null}function a(m){try{const h=typeof m.composedPath=="function"?m.composedPath():null;if(!Array.isArray(h)||h.length===0)return[];const d=[];for(const b of h){if(!(b instanceof Element)||n(b))continue;const S=b.tagName.toUpperCase();S==="HTML"||S==="BODY"||d.push(b)}return d}catch(h){return[]}}function l(m){const h=m,d=typeof h.clientX=="number"?h.clientX:Number.NaN,b=typeof h.clientY=="number"?h.clientY:Number.NaN;return!Number.isFinite(d)||!Number.isFinite(b)?null:{x:d,y:b}}const c=32;function u(m){const h=Ho(),d=new Map,b=Math.min(m.length,c);for(let S=0;S<b;S++){const g=m[S],k=r(g,d,h);if(k)return k.element}return null}function f(m,h){var A,O,V;const d=a(m),b=l(m);if(h.ctrl||h.meta){const F=u(d);return F||(b?s(b.x,b.y,h):null)}const S=(A=d[0])!=null?A:b?la(b.x,b.y)[0]:null;if(!S)return b?s(b.x,b.y,h):null;const g=Ho(),v=r(S,new Map,g);let L;return v&&!v.wrapperOnly?L=S:L=(O=i(S))!=null?O:S,h.alt&&(V=i(L))!=null?V:L}return{findBestTarget:s,findBestTargetFromEvent:f,getCandidatesAtPoint:o,getParentCandidate:i,dispose:()=>t.dispose()}}const ha=new WeakMap,ga=new WeakMap;let vp=0,Ep=0,zo;const Sp=["data-testid","data-test-id","data-test","data-qa","data-cy","name","aria-label","title","alt"],an=48,kp=64;function Mr(e){return(e!=null&&e.tagName?String(e.tagName):"").toLowerCase().trim()||"unknown"}function kt(e){return typeof e=="string"?e.trim():""}function Cp(e){return String(e!=null?e:"").replace(/\s+/g," ").trim()}function qt(e,t){const n=String(e!=null?e:"");return n.length<=t?n:n.slice(0,Math.max(0,t-1)).trimEnd()+"…"}function Ap(){if(zo!==void 0)return zo;let e="";try{const t=window.frameElement;if(t instanceof HTMLIFrameElement){const n=Mr(t),r=kt(t.id||t.getAttribute("id"));if(r)e=`${n}#${r}`;else{const o=kt(t.name||t.getAttribute("name"));if(o)e=`${n}[name="${qt(o,an)}"]`;else{const i=kt(t.getAttribute("src")||t.src);e=i?`${n}[src="${qt(i,an)}"]`:n}}}}catch(t){e=""}return zo=e,e}function Tp(e){const t=ga.get(e);if(t)return t;const n=Mr(e),r=kt(e.id||e.getAttribute("id")),o=r?`${n}#${r}`:`${n}_h${++Ep}`;return ga.set(e,o),o}function ba(e,t){var o;const n=[];let r=e;for(;;){let i;try{i=(o=r.getRootNode)==null?void 0:o.call(r)}catch(a){i=null}if(!(i instanceof ShadowRoot))break;const s=i.host;if(!(s instanceof Element))break;n.unshift(Tp(s)),r=s}return n.length>0?n.join(">"):""}function Np(e){for(const t of Sp){const n=kt(e.getAttribute(t));if(n)return{attr:t,value:n}}return null}function Mt(e,t){const n=ha.get(e);if(n)return n;const r=Mr(e),o=kt(e.id||e.getAttribute("id")),i=o?`${r}#${o}`:`${r}_${++vp}`,s=[],a=Ap();a&&s.push(`frame:${a}`);const l=ba(e);l&&s.push(`shadow:${l}`),s.push(i);const c=s.join("|");return ha.set(e,c),c}function Uo(e){var s;const t=Mr(e),n=kt(e.id||e.getAttribute("id"));if(n)return`${t}#${n}`;const r=Np(e);if(r)return`${t}[${r.attr}="${qt(r.value,an)}"]`;const o=kt(e.getAttribute("role"));if(o)return`${t}[role="${qt(o,an)}"]`;if(e instanceof HTMLInputElement){const a=kt(e.getAttribute("type")||e.type);if(a&&a!=="text")return`${t}[type="${qt(a,an)}"]`;const l=kt(e.getAttribute("placeholder")||e.placeholder);if(l)return`${t}[placeholder="${qt(l,an)}"]`}if(e instanceof HTMLIFrameElement){const a=kt(e.getAttribute("src")||e.src);if(a)return`${t}[src="${qt(a,an)}"]`}const i=Cp((s=e.textContent)!=null?s:"");return i?`${t}("${qt(i,kp)}")`:t}function wa(e,t){const n=Uo(e),r=ba(e);return r?`${r} >> ${n}`:n}const _p=100,Rp=800,Ip={capture:!0,passive:!1};function ln(e){const t=e.trim();return t?t.startsWith("--")?t:t.includes("-")?t.toLowerCase():t.replace(/[A-Z]/g,n=>`-${n.toLowerCase()}`).toLowerCase():""}function Dr(e){const n=e.style;return!n||typeof n.getPropertyValue!="function"||typeof n.setProperty!="function"||typeof n.removeProperty!="function"?null:n}function Pr(e,t){const n=ln(t);return n?e.getPropertyValue(n).trim():""}function Gn(e,t,n){const r=ln(t);if(!r)return;const o=n.trim();o?e.setProperty(r,o):e.removeProperty(r)}function xa(e,t){if(!t)return;const n=Dr(e);if(n)for(const[r,o]of Object.entries(t))Gn(n,r,o)}function Or(e){const t=[],n=new Set;for(const r of e!=null?e:[]){const o=String(r!=null?r:"").trim();o&&(n.has(o)||(n.add(o),t.push(o)))}return t}function ya(e,t){if(e.length!==t.length)return!1;for(let n=0;n<e.length;n++)if(e[n]!==t[n])return!1;return!0}function Lp(e){var t;try{const n=e.classList;if(n&&typeof n[Symbol.iterator]=="function")return Array.from(n).filter(Boolean)}catch(n){}try{return((t=e.getAttribute("class"))!=null?t:"").split(/\s+/).map(r=>r.trim()).filter(Boolean)}catch(n){return[]}}function va(e,t){const r=Or(t).join(" ").trim();try{r?e.setAttribute("class",r):e.removeAttribute("class")}catch(o){}}function Mp(e){const t=Dr(e);if(!t)return;const n={};for(let r=0;r<t.length;r++){const o=t.item(r);if(!o)continue;const i=t.getPropertyValue(o).trim();i&&(n[o]=i)}return Object.keys(n).length>0?n:void 0}function Ea(e){const t=String(e!=null?e:"").trim();if(!t)return null;try{const n=document.createElement("template");n.innerHTML=t;const r=n.content.firstElementChild;return!r||n.content.childElementCount!==1?null:r}catch(n){return null}}function Dp(e){try{e.removeAttribute("id");const t=e.querySelectorAll("[id]");for(const n of Array.from(t))n.removeAttribute("id")}catch(t){}}function Sa(e,t,n){var o;if(!e.isConnected)return!1;let r=null;if(n.anchorLocator){const i=He(n.anchorLocator);i&&i.parentElement===e&&(r=n.anchorPosition==="before"?i:i.nextSibling)}if(!r){const i=Array.from(e.children),s=Math.max(0,Math.min(n.insertIndex,i.length));r=(o=i[s])!=null?o:null}try{return e.insertBefore(t,r),!0}catch(i){return!1}}function Go(e,t,n){const r=e.parentElement;if(!r)return null;const o=String(t||"div").toLowerCase(),i=document.createElement(o);n&&xa(i,n);try{return r.insertBefore(i,e),i.appendChild(e),i}catch(s){return null}}function Wo(e){const t=e.parentElement;if(!t||e.childElementCount!==1)return null;const n=e.firstElementChild;if(!n)return null;try{return t.insertBefore(n,e),e.remove(),n}catch(r){return null}}function Pp(e){const t=e.parentElement;if(!t)return null;const r=Array.from(t.children).indexOf(e);return r<0?null:{parentLocator:Ge(t),insertIndex:r+1,anchorLocator:Ge(e),anchorPosition:"after"}}let ka=0;function cn(e){return ka+=1,`tx_${e.toString(36)}_${ka.toString(36)}`}function Ca(e,t,n,r,o,i){return{id:e,type:"style",targetLocator:t,elementKey:i,before:{locator:t,styles:n},after:{locator:t,styles:r},timestamp:o,merged:!1}}function Aa(e,t,n,r,o,i,s){const a=ln(n);return Ca(e,t,{[a]:r},{[a]:o},i,s)}function Op(e,t,n,r,o,i){return{id:e,type:"text",targetLocator:t,elementKey:i,before:{locator:t,text:n},after:{locator:t,text:r},timestamp:o,merged:!1}}function Fp(e,t,n,r,o,i,s){return{id:e,type:"class",targetLocator:n,elementKey:s,before:{locator:t,classes:r},after:{locator:n,classes:o},timestamp:i,merged:!1}}function Bp(e,t,n,r,o,i){return{id:e,type:"move",targetLocator:n,elementKey:i,before:{locator:t},after:{locator:n},moveData:r,timestamp:o,merged:!1}}function Fr(e,t,n,r,o,i,s){return{id:e,type:"structure",targetLocator:t,elementKey:s,before:{locator:n},after:{locator:r},structureData:o,timestamp:i,merged:!1}}function un(e){var n;const t=(n=e.tagName)==null?void 0:n.toUpperCase();return t==="HTML"||t==="BODY"||t==="HEAD"}function dn(e){var n;const t=(n=e.tagName)==null?void 0:n.toUpperCase();return t==="HTML"||t==="HEAD"}function Xo(e){var n;const t=(n=e.tagName)==null?void 0:n.toUpperCase();return t==="HTML"||t==="BODY"||t==="HEAD"}function Yo(e){const t=e.parentElement;if(!t)return null;const r=Array.from(t.children).indexOf(e);if(r<0)return null;const o=Ge(t),i=e.nextElementSibling;if(i)return{parentLocator:o,insertIndex:r,anchorLocator:Ge(i),anchorPosition:"before"};const s=e.previousElementSibling;return s?{parentLocator:o,insertIndex:r,anchorLocator:Ge(s),anchorPosition:"after"}:{parentLocator:o,insertIndex:r,anchorPosition:"before"}}function Vp(e,t){var s,a,l;if(!e.isConnected||Xo(e))return!1;const n=He(t.parentLocator);if(!n||!n.isConnected)return!1;const r=(s=e.getRootNode)==null?void 0:s.call(e),o=(a=n.getRootNode)==null?void 0:a.call(n);if(r&&o&&r!==o||e===n||e.contains(n))return!1;let i=null;if(t.anchorLocator){const c=He(t.anchorLocator);c&&c!==e&&c.parentElement===n&&(i=t.anchorPosition==="before"?c:c.nextSibling,i===e&&(i=e.nextSibling))}if(!i){const c=Array.from(n.children),u=c.indexOf(e);u!==-1&&c.splice(u,1);const f=Math.max(0,Math.min(t.insertIndex,c.length));i=(l=c[f])!=null?l:null}try{return n.insertBefore(e,i),!0}catch(c){return!1}}function jo(e){const t=new Set;if(e.before.styles)for(const n of Object.keys(e.before.styles))t.add(n);if(e.after.styles)for(const n of Object.keys(e.after.styles))t.add(n);return t.size===1?Array.from(t)[0]:null}function $p(e,t,n){if(e.type!=="style"||t.type!=="style"||Math.abs(t.timestamp-e.timestamp)>n||sn(e.targetLocator)!==sn(t.targetLocator))return!1;const r=jo(e),o=jo(t);return!(!r||!o||r!==o)}function Hp(e,t){var o;const n=jo(e);if(!n)return!1;const r=(o=t.after.styles)==null?void 0:o[n];return r===void 0?!1:(e.after.styles||(e.after.styles={}),e.after.styles[n]=r,e.timestamp=t.timestamp,e.merged=!0,!0)}function zp(e,t){var o,i,s,a,l,c,u,f,m,h,d,b;const n=e.structureData;if(!n)return!1;const r=t==="redo";switch(n.action){case"wrap":{if(r){const k=(i=(o=He(e.before.locator))!=null?o:He(e.targetLocator))!=null?i:He(e.after.locator);if(!k||!k.isConnected||un(k))return!1;const v=k.parentElement;if(!v||!v.isConnected||dn(v))return!1;const L=Go(k,(s=n.wrapperTag)!=null?s:"div",n.wrapperStyles);if(!L||!L.isConnected)return!1;const A=Ge(L);return e.after.locator=A,e.targetLocator=A,!0}const S=(a=He(e.after.locator))!=null?a:He(e.targetLocator);if(!S||!S.isConnected||un(S))return!1;const g=Wo(S);return!g||!g.isConnected?!1:(e.before.locator=Ge(g),!0)}case"unwrap":{if(r){const v=(f=(c=He(e.before.locator))!=null?c:(l=He(e.after.locator))==null?void 0:l.parentElement)!=null?f:(u=He(e.targetLocator))==null?void 0:u.parentElement;if(!v||!v.isConnected||un(v))return!1;const L=Wo(v);if(!L||!L.isConnected)return!1;const A=Ge(L);return e.after.locator=A,e.targetLocator=A,!0}const S=(m=He(e.after.locator))!=null?m:He(e.targetLocator);if(!S||!S.isConnected||un(S))return!1;const g=S.parentElement;if(!g||!g.isConnected||dn(g))return!1;const k=Go(S,(h=n.wrapperTag)!=null?h:"div",n.wrapperStyles);return!k||!k.isConnected?!1:(e.before.locator=Ge(k),!0)}case"delete":{if(r){const v=(d=He(e.before.locator))!=null?d:He(e.targetLocator);return!v||!v.isConnected||un(v)?!1:(v.remove(),!0)}if(!n.position||!n.html)return!1;const S=He(n.position.parentLocator);if(!S||!S.isConnected||dn(S))return!1;const g=Ea(n.html);if(!g||!Sa(S,g,n.position))return!1;const k=Ge(g);return e.before.locator=k,e.targetLocator=k,!0}case"duplicate":{if(r){if(!n.position||!n.html)return!1;const g=He(n.position.parentLocator);if(!g||!g.isConnected||dn(g))return!1;const k=Ea(n.html);if(!k||!Sa(g,k,n.position))return!1;const v=Ge(k);return e.after.locator=v,e.targetLocator=v,!0}const S=(b=He(e.after.locator))!=null?b:He(e.targetLocator);return!S||!S.isConnected||un(S)?!1:(S.remove(),!0)}default:return!1}}function Ta(e,t){var o,i,s,a,l;if(e.type==="move"){const c=e.moveData;if(!c)return!1;const u=t==="undo"?e.after.locator:e.before.locator,f=t==="undo"?e.before.locator:e.after.locator,m=(i=(o=He(u))!=null?o:He(f))!=null?i:He(e.targetLocator);if(!m)return!1;const h=t==="undo"?c.from:c.to;return Vp(m,h)}if(e.type==="class"){const c=t==="undo"?e.after.locator:e.before.locator,u=t==="undo"?e.before.locator:e.after.locator,f=(a=(s=He(c))!=null?s:He(u))!=null?a:He(e.targetLocator);if(!f)return!1;const m=t==="undo"?e.before:e.after,h=Array.isArray(m.classes)?m.classes:[];return va(f,h),!0}if(e.type==="structure")return zp(e,t);if(e.type!=="style"&&e.type!=="text")return!0;const n=He(e.targetLocator);if(!n)return!1;const r=t==="undo"?e.before:e.after;return e.type==="style"?(xa(n,r.styles),!0):(e.type==="text"&&(n.textContent=(l=r.text)!=null?l:""),!0)}function Up(e={}){var P,j,E;const t=new Pe,n=Math.max(1,(P=e.maxHistory)!=null?P:_p),r=Math.max(0,(j=e.mergeWindowMs)!=null?j:Rp),o=(E=e.now)!=null?E:(()=>Date.now()),i=[],s=[];function a(w,D){var $;($=e.onChange)==null||$.call(e,{action:w,transaction:D,undoCount:i.length,redoCount:s.length})}function l(){i.length>n&&i.splice(0,i.length-n)}function c(w,D){const $=s.length>0;if($&&(s.length=0),!$&&D&&i.length>0){const x=i[i.length-1];if($p(x,w,r)&&Hp(x,w)){a("merge",x);return}}i.push(w),l(),a("push",w)}function u(w,D,$,x,I){if(t.isDisposed)return null;const N=ln(D);if(!N)return null;const _=$.trim(),M=x.trim();if(_===M)return null;const W=cn(o()),C=Aa(W,w,N,_,M,o());return c(C,(I==null?void 0:I.merge)!==!1),C}function f(w,D,$){if(t.isDisposed)return null;const x=String(D!=null?D:""),I=String($!=null?$:"");if(x===I)return null;const N=Ge(w),_=o(),M=cn(_),W=Mt(w,N.shadowHostChain),C=Op(M,N,x,I,_,W);return c(C,!1),C}function m(w,D,$){if(t.isDisposed||!w.isConnected)return null;const x=Or(Lp(w)),I=Or(D),N=Or($),_=ya(I,x)?I:x;if(ya(_,N))return null;const M=o(),W=cn(M),C=Ge(w),p=Mt(w,C.shadowHostChain);va(w,N);const y=Ge(w),R=Fp(W,C,y,_,N,M,p);return c(R,!1),R}function h(w,D){var N,_,M,W;if(t.isDisposed||!w.isConnected||un(w))return null;const $=D==null?void 0:D.action,x=o(),I=cn(x);if($==="wrap"){const C=w.parentElement;if(!C||!C.isConnected||dn(C))return null;const p=Ge(w),y=Go(w,(N=D.wrapperTag)!=null?N:"div",D.wrapperStyles);if(!y||!y.isConnected)return null;const R=Ge(y),B=Mt(y,R.shadowHostChain),Y={action:"wrap",wrapperTag:(_=D.wrapperTag)!=null?_:"div",wrapperStyles:D.wrapperStyles},Q=Fr(I,R,p,R,Y,x,B);return c(Q,!1),Q}if($==="unwrap"){const C=w,p=C.parentElement;if(!p||!p.isConnected||dn(p)||C.childElementCount!==1)return null;const y=Ge(C),R=C.tagName.toLowerCase(),B=Mp(C),Y=Wo(C);if(!Y||!Y.isConnected)return null;const Q=Ge(Y),te=Mt(Y,Q.shadowHostChain),pe=Fr(I,Q,y,Q,{action:"unwrap",wrapperTag:R,wrapperStyles:B},x,te);return c(pe,!1),pe}if($==="delete"){const C=Yo(w);if(!C)return null;const p=String((M=w.outerHTML)!=null?M:"").trim();if(!p)return null;const y=Ge(w),R=Mt(w,y.shadowHostChain),B=C.parentLocator;try{w.remove()}catch(te){return null}const Q=Fr(I,y,y,B,{action:"delete",position:C,html:p},x,R);return c(Q,!1),Q}if($==="duplicate"){const C=w.parentElement;if(!C||!C.isConnected||dn(C))return null;const p=Pp(w);if(!p)return null;const y=Ge(w),R=w.cloneNode(!0);Dp(R);try{C.insertBefore(R,w.nextSibling)}catch(pe){return null}const B=String((W=R.outerHTML)!=null?W:"").trim();if(!B)return null;const Y=Ge(R),Q=Mt(R,Y.shadowHostChain),se=Fr(I,Y,y,Y,{action:"duplicate",position:p,html:B},x,Q);return c(se,!1),se}return null}function d(w){if(t.isDisposed||!w.isConnected||Xo(w))return null;const D=Yo(w);if(!D)return null;const $=o(),x=cn($),I=Ge(w);let N=!1;function _(W){if(N||t.isDisposed||(N=!0,!W.isConnected)||Xo(W))return null;const C=Yo(W);if(!C)return null;const p=sn(D.parentLocator)===sn(C.parentLocator),y=D.insertIndex===C.insertIndex,R=D.anchorPosition===C.anchorPosition,B=!D.anchorLocator&&!C.anchorLocator||D.anchorLocator&&C.anchorLocator&&sn(D.anchorLocator)===sn(C.anchorLocator);if(p&&y&&B&&R)return null;const Y=Ge(W),Q=Mt(W,Y.shadowHostChain),se=Bp(x,I,Y,{from:D,to:C},o(),Q);return c(se,!1),se}function M(){N||t.isDisposed||(N=!0)}return{id:x,beforeLocator:I,from:D,commit:_,cancel:M}}function b(w,D){if(t.isDisposed)return null;const $=Dr(w);if(!$)return null;const x=$,I=ln(D);if(!I)return null;const N=Ge(w),_=Pr(x,I),M=cn(o()),W=Mt(w,N.shadowHostChain);let C=!1;function p(B){C||t.isDisposed||Gn(x,I,B)}function y(B){if(C||t.isDisposed)return null;C=!0;const Y=Pr(x,I);if(Y===_)return null;const Q=Aa(M,N,I,_,Y,o(),W);return c(Q,(B==null?void 0:B.merge)!==!1),Q}function R(){C||t.isDisposed||(C=!0,Gn(x,I,_),a("rollback",null))}return{id:M,property:I,targetLocator:N,set:p,commit:y,rollback:R}}function S(w,D){if(t.isDisposed)return null;const $=Dr(w);if(!$)return null;const x=$,I=Array.from(new Set(D.map(Q=>ln(String(Q))).filter(Q=>!!Q)));if(I.length===0)return null;const N=new Set(I),_=Ge(w),M=o(),W=cn(M),C=Mt(w,_.shadowHostChain),p={};for(const Q of I)p[Q]=Pr(x,Q);let y=!1;function R(Q){if(!(y||t.isDisposed))for(const[te,se]of Object.entries(Q)){const pe=ln(te);!pe||!N.has(pe)||Gn(x,pe,String(se!=null?se:""))}}function B(Q){var xe;if(y||t.isDisposed)return null;y=!0;const te={},se={};for(const we of I){const H=(xe=p[we])!=null?xe:"",ae=Pr(x,we);ae!==H&&(te[we]=H,se[we]=ae)}if(Object.keys(te).length===0)return null;const pe=Ca(W,_,te,se,o(),C);return c(pe,(Q==null?void 0:Q.merge)===!0),pe}function Y(){var Q;if(!(y||t.isDisposed)){y=!0;for(const te of I)Gn(x,te,(Q=p[te])!=null?Q:"");a("rollback",null)}}return{id:W,properties:I,targetLocator:_,set:R,commit:B,rollback:Y}}function g(w,D,$,x){const I=b(w,D);return I?(I.set($),I.commit(x)):null}function k(){var $;if(t.isDisposed)return null;const w=i.pop();return w?Ta(w,"undo")?(s.push(w),a("undo",w),w):(i.push(w),($=e.onApplyError)==null||$.call(e,new Error(`Failed to locate element for undo: ${w.id}`)),null):null}function v(){var $;if(t.isDisposed)return null;const w=s.pop();return w?Ta(w,"redo")?(i.push(w),l(),a("redo",w),w):(s.push(w),($=e.onApplyError)==null||$.call(e,new Error(`Failed to locate element for redo: ${w.id}`)),null):null}function L(){return i.length>0}function A(){return s.length>0}function O(){return i.slice()}function V(){return s.slice()}function F(){i.length=0,s.length=0,a("clear",null)}e.enableKeyBindings&&t.listen(window,"keydown",w=>{var x;if((x=e.isEventFromEditorUi)!=null&&x.call(e,w)||!(w.metaKey||w.ctrlKey)||w.altKey)return;const $=w.key.toLowerCase();$==="z"?(w.shiftKey?v():k(),w.preventDefault(),w.stopPropagation(),w.stopImmediatePropagation()):$==="y"&&(v(),w.preventDefault(),w.stopPropagation(),w.stopImmediatePropagation())},Ip);function T(){i.length=0,s.length=0,t.dispose()}return{beginStyle:b,beginMultiStyle:S,beginMove:d,applyStyle:g,recordStyle:u,recordText:f,recordClass:m,applyStructure:h,undo:k,redo:v,canUndo:L,canRedo:A,getUndoStack:O,getRedoStack:V,clear:F,dispose:T}}const Na=96,_a=64,Gp=new Set(["style","text","class"]);function Ko(e){return String(e!=null?e:"").trim()}function Br(e){return String(e!=null?e:"").trim()}function Ra(e){return String(e!=null?e:"").replace(/\s+/g," ").trim()}function Vr(e,t){const n=String(e!=null?e:"");return n.length<=t?n:n.slice(0,Math.max(0,t-1)).trimEnd()+"…"}function Ia(e){const t=[],n=new Set;for(const r of e!=null?e:[]){const o=String(r!=null?r:"").trim();o&&(n.has(o)||(n.add(o),t.push(o)))}return t}function Wp(e){if(typeof document=="undefined")return null;try{return He(e)}catch(t){return null}}function Xp(e,t){var l,c,u;let n="";const r=Ko(e.fingerprint);if(r){const f=r.split("|").map(b=>b.trim()).filter(Boolean),m=(l=f[0])!=null?l:"element",h=f.find(b=>b.startsWith("id=")),d=h?h.slice(3).trim():"";n=d?`${m}#${d}`:m}else Array.isArray(e.selectors)&&e.selectors.length>0?n=Vr(Ko(e.selectors[0]),_a)||"element":n=Vr(t,_a)||"element";const o=[],i=((c=e.frameChain)!=null?c:[]).join(">").trim(),s=((u=e.shadowHostChain)!=null?u:[]).join(">").trim();i&&o.push(i),s&&o.push(s);const a=o.length?`${o.join(">")} >> ${n}`:n;return{label:n,fullLabel:a}}function Yp(e,t){const n=Wp(e);return n?{label:Uo(n),fullLabel:wa(n,e.shadowHostChain)}:Xp(e,t)}function jp(e,t,n){return Number(e)+Number(t)+Number(n)>1?"mixed":e?"style":t?"text":n?"class":"mixed"}function Kp(e){var u,f,m,h;const t=new Map,n=new Map;for(const d of e){if(d.type!=="style")continue;const b=(u=d.before.styles)!=null?u:{},S=(f=d.after.styles)!=null?f:{},g=new Set([...Object.keys(b),...Object.keys(S)]);for(const k of g){const v=String(k!=null?k:"").trim();if(!v)continue;const L=Br(b[v]),A=Br(S[v]);t.has(v)||t.set(v,L),n.set(v,A)}}if(t.size===0&&n.size===0)return null;const r={},o={},i=new Set([...t.keys(),...n.keys()]);for(const d of i){const b=(m=t.get(d))!=null?m:"",S=(h=n.get(d))!=null?h:"";b!==S&&(r[d]=b,o[d]=S)}const s=Array.from(new Set([...Object.keys(r),...Object.keys(o)])).sort();if(s.length===0)return null;let a=0,l=0,c=0;for(const d of s){const b=Br(r[d]),S=Br(o[d]);!b&&S?a+=1:b&&!S?l+=1:c+=1}return{before:r,after:o,added:a,removed:l,modified:c,details:s}}function qp(e){var i,s;let t,n;for(const a of e)a.type==="text"&&(t===void 0&&(t=String((i=a.before.text)!=null?i:"")),n=String((s=a.after.text)!=null?s:""));if(t===void 0||n===void 0||t===n)return null;const r=Vr(Ra(t),Na),o=Vr(Ra(n),Na);return{before:t,after:n,beforePreview:r,afterPreview:o}}function Zp(e){let t,n;for(const c of e)c.type==="class"&&(t||(t=Ia(c.before.classes)),n=Ia(c.after.classes));if(!t||!n)return null;const r=new Set(t),o=new Set(n),i=Array.from(o).filter(c=>!r.has(c)).sort(),s=Array.from(r).filter(c=>!o.has(c)).sort();if(i.length===0&&s.length===0)return null;const a=Array.from(r).sort(),l=Array.from(o).sort();return{before:a,after:l,added:i,removed:s}}function qo(e){var o,i;const t=e.map((s,a)=>({tx:s,index:a}));t.sort((s,a)=>{var u,f;const l=Number((u=s.tx.timestamp)!=null?u:0),c=Number((f=a.tx.timestamp)!=null?f:0);return l!==c?l-c:s.index-a.index});const n=new Map;for(const{tx:s}of t){if(!Gp.has(s.type))continue;const a=Ko(s.elementKey);let l;if(a)l=a;else try{l=sn(s.targetLocator)}catch(u){l=`unknown:${s.id}`}const c=n.get(l);c?c.push(s):n.set(l,[s])}const r=[];for(const[s,a]of n.entries()){if(a.length===0)continue;const l=a[a.length-1],c=(i=(o=l.after)==null?void 0:o.locator)!=null?i:l.targetLocator,u=Kp(a),f=qp(a),m=Zp(a),h=u!==null,d=f!==null,b=m!==null;if(!h&&!d&&!b)continue;const{label:S,fullLabel:g}=Yp(c,s),k={elementKey:s,locator:c};u&&(k.styleChanges={before:u.before,after:u.after}),f&&(k.textChange={before:f.before,after:f.after}),m&&(k.classChanges={before:m.before,after:m.after});const v={};u&&(v.style={added:u.added,removed:u.removed,modified:u.modified,details:u.details}),f&&(v.text={beforePreview:f.beforePreview,afterPreview:f.afterPreview}),m&&(v.class={added:m.added,removed:m.removed});const L=a.reduce((O,V)=>{var T;const F=Number((T=V.timestamp)!=null?T:0);return Number.isFinite(F)?Math.max(O,F):O},0),A=jp(h,d,b);r.push({elementKey:s,label:S,fullLabel:g,locator:c,type:A,changes:v,transactionIds:a.map(O=>O.id),netEffect:k,updatedAt:L,debugSource:c.debugSource})}return r.sort((s,a)=>a.updatedAt-s.updatedAt||s.label.localeCompare(a.label)),r}const Qp=2e3,Jp=12e4,em=["completed","failed","error","timeout","cancelled"];function $r(e){return em.includes(e)}function La(e){switch(e){case"pending":return"Waiting...";case"starting":return"Starting Agent...";case"running":return"Running...";case"locating":return"Locating code...";case"applying":return"Applying changes...";case"completed":return"Completed";case"failed":case"error":return"Failed";case"timeout":return"Timed out";case"cancelled":return"Cancelled";default:return""}}class tm{constructor(t={}){Dt(this,"disposer",new Pe);Dt(this,"executions",new Map);Dt(this,"pollTimers",new Map);Dt(this,"pollInterval");Dt(this,"timeout");Dt(this,"onStatusChange");var n,r;this.pollInterval=(n=t.pollInterval)!=null?n:Qp,this.timeout=(r=t.timeout)!=null?r:Jp,this.onStatusChange=t.onStatusChange,this.disposer.add(()=>this.stopAllPolling())}track(t,n){const r=Date.now(),o={requestId:t,sessionId:n,status:"pending",message:La("pending"),startedAt:r,updatedAt:r};return this.executions.set(t,o),this.startPolling(t),o}getState(t){return this.executions.get(t)}cancel(t){return Qe(this,null,function*(){const n=this.executions.get(t);if(n&&(this.stopPolling(t),!$r(n.status))){this.updateState(t,{status:"cancelled",message:"Cancelling..."});try{const r=yield chrome.runtime.sendMessage({type:Ot.WEB_EDITOR_CANCEL_EXECUTION,payload:{sessionId:n.sessionId,requestId:n.requestId}});r!=null&&r.success?this.updateState(t,{status:"cancelled",message:"Cancelled by user"}):(console.warn("[ExecutionTracker] Cancel request failed:",r==null?void 0:r.error),this.updateState(t,{status:"cancelled",message:"Cancelled (server may still be running)"}))}catch(r){console.warn("[ExecutionTracker] Cancel request error:",r),this.updateState(t,{status:"cancelled",message:"Cancelled by user"})}}})}updateFromBackground(t,n){this.updateState(t,n)}dispose(){this.disposer.dispose(),this.executions.clear()}startPolling(t){const n=window.setTimeout(()=>{const i=this.executions.get(t);i&&!$r(i.status)&&(this.updateState(t,{status:"timeout",message:"Execution timed out"}),this.stopPolling(t))},this.timeout);this.disposer.add(()=>window.clearTimeout(n));const r=()=>Qe(this,null,function*(){const i=this.executions.get(t);if(!i||$r(i.status)){this.stopPolling(t);return}try{const s=yield this.queryStatus(t,i.sessionId);if(s&&(this.updateState(t,s),$r(s.status))){this.stopPolling(t);return}}catch(s){}if(!this.disposer.isDisposed){const s=window.setTimeout(r,this.pollInterval);this.pollTimers.set(t,s)}}),o=window.setTimeout(r,500);this.pollTimers.set(t,o)}stopPolling(t){const n=this.pollTimers.get(t);n!==void 0&&(window.clearTimeout(n),this.pollTimers.delete(t))}stopAllPolling(){for(const t of this.pollTimers.values())window.clearTimeout(t);this.pollTimers.clear()}updateState(t,n){var i;const r=this.executions.get(t);if(!r)return;const o=mt(je(je({},r),n),{updatedAt:Date.now()});n.status&&!n.message&&(o.message=La(n.status)),this.executions.set(t,o),(i=this.onStatusChange)==null||i.call(this,o)}queryStatus(t,n){return Qe(this,null,function*(){try{const r=yield chrome.runtime.sendMessage({type:Ot.WEB_EDITOR_STATUS_QUERY,requestId:t,sessionId:n});if(r!=null&&r.status)return{status:r.status,message:r.message,result:r.result}}catch(r){}return null})}}function nm(e){return new tm(e)}const rm=.5,om=.001,Zt=/(-?\d*\.?\d+(?:e[+-]?\d+)?)px/gi,im=/-?\d*\.?\d+(?:e[+-]?\d+)?/gi;function Hr(e){return String(e!=null?e:"").replace(/\s+/g," ").trim()}function Ma(e,t){var s;const n={},r=[],o=new Set;for(const a of t){const l=String(a!=null?a:"").trim();!l||o.has(l)||(o.add(l),r.push(l))}let i=null;try{i=window.getComputedStyle(e)}catch(a){i=null}for(const a of r){let l="";try{l=(s=i==null?void 0:i.getPropertyValue(a))!=null?s:""}catch(c){l=""}n[a]=zr(l)}return n}function sm(e,t,n={}){var a,l;const r=Number.isFinite(n.pxEpsilon)?n.pxEpsilon:rm,o=Number.isFinite(n.matrixEpsilon)?n.matrixEpsilon:om,i=[];for(const c of Object.keys(e)){const u=zr((a=e[c])!=null?a:""),f=zr((l=t[c])!=null?l:""),{match:m,reason:h}=cm(u,f,r,o);i.push({property:c,expected:u,actual:f,match:m,reason:h})}return{matches:i.every(c=>c.match),diffs:i}}function zr(e){return String(e!=null?e:"").replace(/\s+/g," ").replace(/,\s+/g,",").replace(/\(\s+/g,"(").replace(/\s+\)/g,")").trim()}function Da(e,t,n){return Math.abs(e-t)<=n}function Zo(e){const t=e.toLowerCase();return t.startsWith("matrix(")||t.startsWith("matrix3d(")}function Pa(e){if(!Zo(e))return null;const t=e.match(im);if(!t||t.length===0)return null;const n=[];for(const r of t){const o=Number(r);if(!Number.isFinite(o))return null;n.push(o)}return n.length>0?n:null}function Oa(e){const t=[];Zt.lastIndex=0;let n;for(;(n=Zt.exec(e))!==null;){const r=Number(n[1]);if(!Number.isFinite(r))return null;t.push(r)}return t.length>0?t:null}function Fa(e){return Zt.lastIndex=0,zr(e).replace(Zt,"#px")}function am(e,t,n){const r=Pa(e),o=Pa(t);if(!r||!o||r.length!==o.length)return!1;const i=e.toLowerCase().startsWith("matrix3d(")?"matrix3d":"matrix",s=t.toLowerCase().startsWith("matrix3d(")?"matrix3d":"matrix";if(i!==s)return!1;for(let a=0;a<r.length;a++)if(!Da(r[a],o[a],n))return!1;return!0}function lm(e,t,n){const r=Oa(e),o=Oa(t);if(!r||!o||r.length!==o.length||Fa(e)!==Fa(t))return!1;for(let i=0;i<r.length;i++)if(!Da(r[i],o[i],n))return!1;return!0}function cm(e,t,n,r){if(e===t)return{match:!0,reason:"exact"};if(Zo(e)&&Zo(t)&&am(e,t,r))return{match:!0,reason:"matrix_epsilon"};const o=Zt.test(e);Zt.lastIndex=0;const i=Zt.test(t);return Zt.lastIndex=0,o&&i&&lm(e,t,n)?{match:!0,reason:"px_epsilon"}:{match:!1,reason:"string"}}const um=300,dm=8e3,fm=2e3,pm=200,mm=16,hm={childList:!0,subtree:!0,characterData:!0,attributes:!0},gm={childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","style","id"],characterData:!0},bm=new Set(["completed","failed","error","timeout","cancelled"]),wm=8,xm=6;function Ba(e){try{const t=e.getBoundingClientRect();return!Number.isFinite(t.left)||!Number.isFinite(t.top)||!Number.isFinite(t.width)||!Number.isFinite(t.height)?null:t}catch(t){return null}}function Va(e){return{x:e.left+e.width/2,y:e.top+e.height/2}}function ym(e,t){try{const n=document.elementsFromPoint(e,t);return Array.isArray(n)?n.filter(r=>r instanceof Element):[]}catch(n){try{const r=document.elementFromPoint(e,t);return r?[r]:[]}catch(r){return[]}}}function vm(e,t,n){try{const r=e.querySelectorAll(t),o=[],i=Math.min(n,r.length);for(let s=0;s<i;s++)o.push(r[s]);return o}catch(r){return[]}}function Em(e){var n,r,o;const t=(o=(r=(n=e.tagName)==null?void 0:n.toUpperCase)==null?void 0:r.call(n))!=null?o:"";return t==="HTML"||t==="BODY"}function fn(e,t){return!(!e.isConnected||Em(e)||t!=null&&t(e))}function $a(e){const t=String(e!=null?e:"").trim().split("|").filter(Boolean),n=t[0]||"unknown";let r,o=[],i;for(const s of t.slice(1))s.startsWith("id=")?r=s.slice(3)||void 0:s.startsWith("class=")?o=s.slice(6).split(".").filter(Boolean):s.startsWith("text=")&&(i=s.slice(5)||void 0);return{tag:n,id:r,classes:o,text:i}}function Sm(e,t){if(!e.length||!t.length)return 0;const n=new Set(t);return e.filter(r=>n.has(r)).length}function km(e,t){const n=Math.min(e.length,t.length);let r=0;for(;r<n&&e[r]===t[r];)r++;return r}function Qo(e){var a,l;const{element:t,expected:n,locator:r,anchorCenter:o}=e,i=$a(_o(t));if(i.tag!==n.tag||n.id&&i.id!==n.id)return-1/0;let s=0;if(n.id&&(s+=12),s+=Math.min(8,Sm(n.classes,i.classes)*2),n.text){const c=Hr(n.text);Hr((a=t.textContent)!=null?a:"").includes(c)&&(s+=4)}if((l=r.path)!=null&&l.length){const c=Fs(t),u=km(r.path,c);s+=u/r.path.length*6,u===r.path.length&&c.length===r.path.length&&(s+=2)}if(o&&Number.isFinite(o.x)){const c=Ba(t);if(c){const u=Va(c),f=Math.hypot(u.x-o.x,u.y-o.y);s+=Math.max(0,6-f/50)}}return s}function Cm(e){var l;const{locator:t,expected:n,isOverlayElement:r,maxElements:o,anchorCenter:i}=e;let s=null,a=0;if(n.id){const c=document.getElementById(n.id);if(c&&fn(c,r)){const u=Qo({element:c,expected:n,locator:t,anchorCenter:i});Number.isFinite(u)&&(s={element:c,score:u})}}for(const c of(l=t.selectors)!=null?l:[]){if(a>=o)break;const u=o-a;if(u<=0)break;const f=vm(document,c,u);for(const m of f){if(a++,!fn(m,r))continue;const h=Qo({element:m,expected:n,locator:t,anchorCenter:i});Number.isFinite(h)&&(!s||h>s.score)&&(s={element:m,score:h})}}return s}function Am(e){const{expected:t,locator:n,anchorCenter:r,isOverlayElement:o,selectionEngine:i,maxCandidates:s}=e,a=[];if(i)try{for(const u of i.getCandidatesAtPoint(r.x,r.y))if(a.push(u.element),a.length>=s)break}catch(u){}if(a.length===0){for(const u of ym(r.x,r.y))if(a.push(u),a.length>=s)break}let l=null;const c=new Set;for(const u of a){if(c.has(u)||(c.add(u),!fn(u,o)))continue;const f=Qo({element:u,expected:t,locator:n,anchorCenter:r});Number.isFinite(f)&&(!l||f>l.score)&&(l={element:u,score:f})}return l}function Tm(e){var n,r;const t=new Set;for(const o of Object.keys((n=e.before.styles)!=null?n:{}))t.add(o);for(const o of Object.keys((r=e.after.styles)!=null?r:{}))t.add(o);return Array.from(t).filter(Boolean)}function Nm(e){var I,N,_,M,W;const t=new Pe,n=()=>Date.now(),r=Math.max(0,(I=e.quietWindowMs)!=null?I:um),o=Math.max(0,(N=e.settleDeadlineMs)!=null?N:dm),i=Math.max(0,(_=e.noSignalDeadlineMs)!=null?_:fm),s=Math.max(1,(M=e.relaxedLocateMaxElements)!=null?M:pm),a=Math.max(1,(W=e.geometricMaxCandidates)!=null?W:mm);let l=0,c=null,u=null;t.add(()=>b("skipped","disposed"));function f(C,p){var y;(y=e.setToolbarStatus)==null||y.call(e,C,p)}function m(C,p){var R,B,Y,Q,te,se,pe;const y=n();return{outcome:p.outcome,reason:p.reason,requestId:C==null?void 0:C.requestId,sessionId:C==null?void 0:C.sessionId,txId:(R=C==null?void 0:C.txId)!=null?R:"",txTimestamp:(B=C==null?void 0:C.txTimestamp)!=null?B:0,txType:(Y=C==null?void 0:C.txType)!=null?Y:"style",resolved:p.resolved,style:p.style,text:p.text,signals:{hadRelevantMutation:(Q=C==null?void 0:C.signals.hadRelevantMutation)!=null?Q:!1,hadElementDisconnect:(te=C==null?void 0:C.signals.hadElementDisconnect)!=null?te:!1},timing:{startedAt:(se=C==null?void 0:C.startedAt)!=null?se:y,executionCompletedAt:(pe=C==null?void 0:C.executionCompletedAt)!=null?pe:void 0,finalizedAt:y}}}function h(C){var p;u=C,(p=e.onResult)==null||p.call(e,C)}function d(C){C.timers.quietTimer!==null&&(window.clearTimeout(C.timers.quietTimer),C.timers.quietTimer=null),C.timers.deadlineTimer!==null&&(window.clearTimeout(C.timers.deadlineTimer),C.timers.deadlineTimer=null),C.timers.noSignalTimer!==null&&(window.clearTimeout(C.timers.noSignalTimer),C.timers.noSignalTimer=null)}function b(C,p,y){const R=c;if(!R)return;const B=m(R,{outcome:C,reason:p,resolved:y==null?void 0:y.resolved,style:y==null?void 0:y.style,text:y==null?void 0:y.text});d(R),R.disposer.dispose(),c=null;const Y=R.phase==="settling"||R.phase==="verifying";y!=null&&y.toolbar?f(y.toolbar.status,y.toolbar.message):C==="skipped"&&Y&&f("idle"),h(B)}function S(C,p){try{const y=e.transactionManager.getUndoStack();if(y.length===0)return!1;const R=y[y.length-1];return R.id===C&&R.timestamp===p}catch(y){return!1}}function g(C){if(!e.isOverlayElement)return!1;const p=C.target;return p instanceof Element&&e.isOverlayElement(p)?!0:C.type==="childList"?[...C.addedNodes,...C.removedNodes].some(R=>{var B;return R instanceof Element&&((B=e.isOverlayElement)==null?void 0:B.call(e,R))}):!1}function k(C,p){if(!p||g(C))return!1;const y=C.target;if(C.type==="characterData"){if(y instanceof Text){const R=y.parentElement;if(R&&(R===p||R.contains(p)||p.contains(R)))return!0}return!1}if(!(y instanceof Element))return!1;if(C.type==="attributes")try{return y===p||y.contains(p)||p.contains(y)}catch(R){return!1}if(C.type==="childList"){try{if(y===p||y.contains(p)||p.contains(y))return!0}catch(R){}for(const R of C.removedNodes){if(R===p)return!0;if(R instanceof Element)try{if(R.contains(p))return!0}catch(B){}}}return!1}function v(C,p){C.disposer.isDisposed||C.phase==="settling"&&(C.timers.quietTimer!==null&&(window.clearTimeout(C.timers.quietTimer),C.timers.quietTimer=null),C.timers.quietTimer=window.setTimeout(()=>{C.timers.quietTimer=null,P(`quiet:${p}`)},r))}function L(C){C.signals.hadRelevantMutation=!0,v(C,"mutation")}function A(C){var B,Y,Q;if(C.disposer.isDisposed||C.phase==="settling"||C.phase==="verifying")return;C.phase="settling",C.executionCompletedAt=n(),f("verifying","Waiting for HMR…");const p=document.head;p&&C.disposer.observeMutation(p,()=>{(c==null?void 0:c.key)!==C.key||c.phase!=="settling"||L(c)},hm);const y=(Y=(B=C.originalElement)==null?void 0:B.getRootNode)==null?void 0:Y.call(B),R=y instanceof ShadowRoot?y:(Q=document.body)!=null?Q:document.documentElement;R&&C.disposer.observeMutation(R,te=>{if((c==null?void 0:c.key)!==C.key||c.phase!=="settling")return;const se=c.originalElement;se&&!se.isConnected&&(c.signals.hadElementDisconnect=!0),te.some(pe=>k(pe,se))&&L(c)},gm),C.timers.deadlineTimer=window.setTimeout(()=>{(c==null?void 0:c.key)===C.key&&b("uncertain","timeout waiting for HMR",{toolbar:{status:"uncertain",message:"Uncertain (timeout)"}})},o),C.timers.noSignalTimer=window.setTimeout(()=>{(c==null?void 0:c.key)!==C.key||c.phase!=="settling"||P("no_signal")},i),v(C,"initial")}function O(C){const p=e.isOverlayElement,y=C.originalElement;if(y&&fn(y,p))return{element:y,source:"current",confidence:"high"};const R=He(C.locator);if(R&&fn(R,p))return{element:R,source:"strict",confidence:"high"};const B=$a(C.locator.fingerprint),Y=Cm({locator:C.locator,expected:B,isOverlayElement:p,maxElements:s,anchorCenter:C.anchorCenter});if(Y&&fn(Y.element,p)&&Y.score>=wm)return{element:Y.element,source:"relaxed",confidence:"medium",score:Y.score};if(C.anchorCenter){const Q=Am({expected:B,locator:C.locator,anchorCenter:C.anchorCenter,isOverlayElement:p,selectionEngine:e.selectionEngine,maxCandidates:a});if(Q&&fn(Q.element,p)&&Q.score>=xm)return{element:Q.element,source:"geometric",confidence:"low",score:Q.score}}return null}function V(C,p){var R,B;!e.onReselect||((B=(R=e.getSelectedElement)==null?void 0:R.call(e))!=null?B:null)===p||(C.flags.suppressNextSelectionChange=!0,e.onReselect(p))}function F(C,p){const y=C.expectedStyle;if(!(y!=null&&y.computed))return{ok:!1};const R=Ma(p,y.properties);return{ok:!0,style:sm(y.computed,R)}}function T(C,p){var B;const y=C.expectedText;if(y===null)return{ok:!1};const R=Hr((B=p.textContent)!=null?B:"");return{ok:!0,text:{expected:y,actual:R,match:y===R}}}function P(C){return Qe(this,null,function*(){const p=c;if(!(!p||p.disposer.isDisposed||p.phase!=="settling"||p.flags.verifying)){p.flags.verifying=!0,p.phase="verifying",f("verifying","Verifying…");try{if(!S(p.txId,p.txTimestamp)){b("skipped","skipped: new edits detected");return}if(p.flags.selectionChanged){b("skipped","skipped: selection changed");return}p.originalElement&&!p.originalElement.isConnected&&(p.signals.hadElementDisconnect=!0);const y=O(p);if(!y){b("lost",`lost: unable to locate target (${C})`,{toolbar:{status:"lost",message:"Target lost"}});return}V(p,y.element);const R={source:y.source,confidence:y.confidence,score:y.score},B=p.signals.hadRelevantMutation||p.signals.hadElementDisconnect;if(y.confidence==="low"){b("uncertain",`uncertain: low confidence resolution (${y.source})`,{resolved:R,toolbar:{status:"uncertain",message:"Uncertain (low confidence)"}});return}if(p.txType==="style"){const Y=F(p,y.element);if(!Y.ok||!Y.style){b("uncertain","uncertain: missing computed baseline",{resolved:R,toolbar:{status:"uncertain",message:"Uncertain (no baseline)"}});return}const Q=Y.style.diffs.filter(te=>!te.match);if(Q.length>0){b("mismatch",`mismatch: ${Q.length} property mismatch`,{resolved:R,style:Y.style,toolbar:{status:"mismatch",message:`Mismatch (${Q.length})`}});return}if(!B){b("uncertain","uncertain: no HMR signal observed",{resolved:R,style:Y.style,toolbar:{status:"uncertain",message:"Uncertain (no HMR signal)"}});return}b("verified","verified",{resolved:R,style:Y.style,toolbar:{status:"verified",message:"Verified"}});return}if(p.txType==="text"){const Y=T(p,y.element);if(!Y.ok||!Y.text){b("uncertain","uncertain: missing text baseline",{resolved:R,toolbar:{status:"uncertain",message:"Uncertain (no baseline)"}});return}if(!Y.text.match){b("mismatch","mismatch: text differs from expected",{resolved:R,text:Y.text,toolbar:{status:"mismatch",message:"Mismatch (text)"}});return}if(!B){b("uncertain","uncertain: no HMR signal observed",{resolved:R,text:Y.text,toolbar:{status:"uncertain",message:"Uncertain (no HMR signal)"}});return}b("verified","verified",{resolved:R,text:Y.text,toolbar:{status:"verified",message:"Verified"}});return}b("skipped",`skipped: tx type "${p.txType}" not supported`)}finally{(c==null?void 0:c.key)===p.key&&(c.flags.verifying=!1)}}})}function j(C){var H,ae;const{tx:p,requestId:y,sessionId:R,element:B}=C;if(p.type!=="style"&&p.type!=="text")return;b("skipped","skipped: superseded by new apply");const Y=`hmr_${n().toString(36)}_${(++l).toString(36)}`,Q=new Pe,te=B!=null&&B.isConnected?B:null,se=te?Ba(te):null,pe=se?Va(se):null;let xe=null,we=null;if(p.type==="style"){const ne=Tm(p),me=te?Ma(te,ne):null;xe=me?{properties:ne,computed:me}:null}else if(p.type==="text"){const ne=te?(H=te.textContent)!=null?H:"":(ae=p.after.text)!=null?ae:"";we=Hr(ne)}c={key:Y,phase:"executing",requestId:(y==null?void 0:y.trim())||void 0,sessionId:(R==null?void 0:R.trim())||void 0,txId:p.id,txTimestamp:p.timestamp,txType:p.type,locator:p.targetLocator,originalElement:te,expectedStyle:xe,expectedText:we,anchorRect:se,anchorCenter:pe,startedAt:n(),executionCompletedAt:null,signals:{hadRelevantMutation:!1,hadElementDisconnect:!1},flags:{verifying:!1,selectionChanged:!1,suppressNextSelectionChange:!1},timers:{quietTimer:null,deadlineTimer:null,noSignalTimer:null},disposer:Q},S(p.id,p.timestamp)||b("skipped","skipped: transaction no longer latest")}function E(C){const p=c;!p||p.disposer.isDisposed||p.requestId&&C.requestId!==p.requestId||bm.has(C.status)&&(C.status==="completed"?A(p):b("skipped",`skipped: execution ${C.status}`))}function w(C){const p=c;!p||p.disposer.isDisposed||S(p.txId,p.txTimestamp)||b("skipped","skipped: new edits detected")}function D(C){const p=c;if(!p||p.disposer.isDisposed)return;if(p.flags.suppressNextSelectionChange){p.flags.suppressNextSelectionChange=!1;return}const y=p.originalElement;if(C===null&&y){p.flags.selectionChanged=!0,b("skipped","skipped: selection cleared");return}y&&C&&C!==y&&(p.flags.selectionChanged=!0,b("skipped","skipped: selection changed"))}function $(){var p;const C=c;return{phase:(p=C==null?void 0:C.phase)!=null?p:"idle",activeRequestId:C==null?void 0:C.requestId,activeTxId:C==null?void 0:C.txId,lastResult:u}}function x(){t.dispose(),f("idle")}return{start:j,onExecutionStatus:E,onTransactionChange:w,onSelectionChange:D,getSnapshot:$,dispose:x}}function Jo(e){return typeof e=="number"&&Number.isFinite(e)}function _m(e){return e/1048576}function Ha(e,t){const n=_m(e);return Number.isFinite(n)?n.toFixed(t):"N/A"}function Rm(){try{const t=performance.memory;if(!t)return null;const n=t.usedJSHeapSize,r=t.jsHeapSizeLimit,o=t.totalJSHeapSize;return!Jo(n)||!Jo(r)||!Jo(o)?null:{usedJSHeapSize:n,totalJSHeapSize:o,jsHeapSizeLimit:r}}catch(e){return null}}function Im(e){var F,T;const t=new Pe,n=e.container,r=Math.max(100,Math.floor(e.fpsUiIntervalMs)),o=Math.max(250,Math.floor(e.memorySampleIntervalMs)),i=document.createElement("div");i.className="we-perf-hud",i.hidden=!0,i.setAttribute("aria-hidden","true");const s=document.createElement("div");s.className="we-perf-hud-line",s.textContent="FPS: --";const a=document.createElement("div");a.className="we-perf-hud-line",a.textContent="Heap: --",i.append(s,a),n.append(i),t.add(()=>i.remove());let l=!1,c=null,u=0,f=0,m=0,h=(F=s.textContent)!=null?F:"",d=(T=a.textContent)!=null?T:"";function b(){c!==null&&(cancelAnimationFrame(c),c=null)}t.add(b);function S(P,j,E){if(E==="fps"){if(j===h)return;h=j}else{if(j===d)return;d=j}P.textContent=j}function g(){const P=Rm();if(!P){S(a,"Heap: N/A","heap");return}const j=Ha(P.usedJSHeapSize,1),E=Ha(P.jsHeapSizeLimit,0);S(a,`Heap: ${j} / ${E} MB`,"heap")}function k(P){u=0,f=P,m=P-o,S(s,"FPS: --","fps"),g()}function v(){t.isDisposed||l&&c===null&&document.visibilityState==="visible"&&(c=requestAnimationFrame(L))}function L(P){if(c=null,t.isDisposed||!l||document.visibilityState!=="visible")return;u+=1;const j=P-f;if(j>=r){const E=j>0?u*1e3/j:0,w=Math.max(0,Math.round(E));S(s,`FPS: ${w}`,"fps"),u=0,f=P}P-m>=o&&(m=P,g()),v()}function A(){if(l){if(document.visibilityState!=="visible"){b();return}k(performance.now()),v()}}t.listen(document,"visibilitychange",A);function O(P){if(l!==P){if(l=P,!l){i.hidden=!0,b();return}i.hidden=!1,document.visibilityState==="visible"&&(k(performance.now()),v())}}function V(){return O(!l),l}return{isEnabled:()=>l,setEnabled:O,toggle:V,dispose:()=>{l=!1,i.hidden=!0,t.dispose()}}}const Lm=50,Mm=8;function Dm(e={}){var m,h;const t=Math.max(1,Math.floor((m=e.maxDeclarationsPerToken)!=null?m:Lm)),n=Math.max(0,Math.floor((h=e.maxInlineDepth)!=null?h:Mm));function r(d){try{return d.cssRules}catch(b){return null}}function o(d){var b,S,g;if(d.disabled)return!1;try{const k=(g=(S=(b=d.media)==null?void 0:b.mediaText)==null?void 0:S.trim())!=null?g:"";return!k||k.toLowerCase()==="all"?!0:window.matchMedia(k).matches}catch(k){return!0}}function i(d,b){var k,v;const S=typeof d.href=="string"?d.href:void 0;if(S){const L=(v=(k=S.split("/").pop())==null?void 0:k.split("?")[0])!=null?v:S;return{url:S,label:L}}const g=d.ownerNode;return(g==null?void 0:g.nodeType)===Node.ELEMENT_NODE?{label:`<${g.tagName.toLowerCase()} #${b}>`}:{label:`<constructed #${b}>`}}function s(d,b){var S,g,k;try{const v=(k=(g=(S=d.media)==null?void 0:S.mediaText)==null?void 0:g.trim())!=null?k:"";return!v||v.toLowerCase()==="all"?!0:window.matchMedia(v).matches}catch(v){return b.push(`Failed to evaluate @media: ${String(v)}`),!1}}function a(d,b){var S,g;try{const k=(g=(S=d.conditionText)==null?void 0:S.trim())!=null?g:"";return!k||typeof(CSS==null?void 0:CSS.supports)!="function"?!0:CSS.supports(k)}catch(k){return b.push(`Failed to evaluate @supports: ${String(k)}`),!1}}function l(d){var g,k,v;const b=[],S=Number((g=d==null?void 0:d.length)!=null?g:0);for(let L=0;L<S;L++){let A="";try{A=String((k=d.item(L))!=null?k:"").trim()}catch(F){continue}if(!A.startsWith("--"))continue;let O="",V=!1;try{O=String((v=d.getPropertyValue(A))!=null?v:"").trim(),V=d.getPropertyPriority(A)==="important"}catch(F){}b.push({name:A,value:O,important:V})}return b}function c(d){var P,j,E;const b=d instanceof ShadowRoot?"shadow":"document",S=[],g=new Map;let k=0,v=0,L=0;function A(w){var $;const D=($=g.get(w.name))!=null?$:[];D.length>=t||(D.push(mt(je({},w),{order:L++})),g.set(w.name,D),v++)}function O(w,D){var $,x,I,N,_,M;for(const W of Array.from(w)){if(k++,W.type===CSSRule.IMPORT_RULE){const p=W,y=p.styleSheet;if(y&&!D.visited.has(y)){try{const Y=(I=(x=($=p.media)==null?void 0:$.mediaText)==null?void 0:x.trim())!=null?I:"";if(Y&&Y.toLowerCase()!=="all"&&!window.matchMedia(Y).matches)continue}catch(Y){}if(!o(y))continue;const R=r(y),B=i(y,D.sheetIndex);if(!R){S.push(`Skipped @import (cross-origin): ${(N=B.url)!=null?N:B.label}`);continue}D.visited.add(y);try{O(R,mt(je({},D),{source:B}))}finally{D.visited.delete(y)}}continue}if(W.type===CSSRule.MEDIA_RULE){s(W,S)&&O(W.cssRules,D);continue}if(W.type===CSSRule.SUPPORTS_RULE){a(W,S)&&O(W.cssRules,D);continue}if(W.type===CSSRule.STYLE_RULE){const p=W,y=String((_=p.selectorText)!=null?_:"").trim()||void 0,R=l(p.style);for(const B of R)A({name:B.name,value:B.value,important:B.important,origin:"rule",rootType:b,styleSheet:D.source,selectorText:y});continue}const C=W;if((M=C.cssRules)!=null&&M.length)try{O(C.cssRules,D)}catch(p){}}}const V=d,F=[];try{for(const w of Array.from((P=V.styleSheets)!=null?P:[]))w instanceof CSSStyleSheet&&F.push(w)}catch(w){}try{const w=Array.from((j=V.adoptedStyleSheets)!=null?j:[]);for(const D of w)D instanceof CSSStyleSheet&&F.push(D)}catch(w){}for(let w=0;w<F.length;w++){const D=F[w];if(!o(D))continue;const $=i(D,w),x=r(D);if(!x){S.push(`Skipped stylesheet (cross-origin): ${(E=$.url)!=null?E:$.label}`);continue}O(x,{sheetIndex:w,source:$,visited:new Set([D])})}const T={styleSheets:F.length,rulesScanned:k,tokens:g.size,declarations:v};return{rootType:b,tokens:g,warnings:[...new Set(S)],stats:T}}function u(d){var b;if(d.parentElement)return d.parentElement;try{const S=(b=d.getRootNode)==null?void 0:b.call(d);if(S instanceof ShadowRoot)return S.host}catch(S){}return null}function f(d,b){var L,A,O;const S=Math.max(0,Math.floor((L=b==null?void 0:b.maxDepth)!=null?L:n)),g=new Set;let k=d,v=0;for(;k&&v<=S;){v++;try{const V=k.style;if(V){const F=Number((A=V.length)!=null?A:0);for(let T=0;T<F;T++){const P=String((O=V.item(T))!=null?O:"").trim();P.startsWith("--")&&g.add(P)}}}catch(V){}k=u(k)}return g}return{collectRootIndex:c,collectInlineTokenNames:f}}function Pm(e={}){const t=!!e.enableProbe;function n(l,c){const u=typeof c=="string"?c.trim():"";return u?`var(${l}, ${u})`:`var(${l})`}function r(l){const c=String(l!=null?l:"").trim();if(!c.toLowerCase().startsWith("var("))return null;let u=0,f=-1;for(let g=0;g<c.length;g++){const k=c[g];if(k==="(")u++;else if(k===")"&&(u--,u===0)){f=g;break}}if(f<0||f!==c.length-1)return null;const m=c.slice(4,f).trim();if(!m)return null;let h=-1;u=0;for(let g=0;g<m.length;g++){const k=m[g];if(k==="(")u++;else if(k===")")u=Math.max(0,u-1);else if(k===","&&u===0){h=g;break}}const d=(h>=0?m.slice(0,h):m).trim(),b=h>=0?m.slice(h+1).trim():"";if(!d.startsWith("--"))return null;const S=d;return b?{name:S,fallback:b}:{name:S}}function o(l){var h;const c=[],u=String(l!=null?l:""),f=/var\(\s*(--[\w-]+)/g;let m;for(;m=f.exec(u);){const d=(h=m[1])==null?void 0:h.trim();d!=null&&d.startsWith("--")&&c.push(d)}return c}function i(l,c){try{return window.getComputedStyle(l).getPropertyValue(c).trim()}catch(u){return""}}function s(l,c){const u=i(l,c);return{token:c,computedValue:u,availability:u?"available":"unset"}}function a(l,c,u,f={}){const m=n(c,f.fallback),h=t&&f.preview?"probe":"computed";let d;return h==="computed"&&f.preview&&(d=i(l,c)||void 0),{token:c,cssProperty:u,cssValue:m,resolvedValue:d,method:h}}return{formatCssVar:n,parseCssVar:r,extractCssVarNames:o,readComputedValue:i,resolveToken:s,resolveTokenForProperty:a}}function Om(e={}){var w,D,$,x,I;const t=new Pe,n=(w=e.now)!=null?w:(()=>performance.now()),r=Math.max(0,Math.floor((D=e.cacheMaxAgeMs)!=null?D:0)),o=e.observeHead!==!1,i=!!e.observeShadowRoots,s=Math.max(0,Math.floor(($=e.maxInlineDepth)!=null?$:8)),a=(x=e.detector)!=null?x:Dm(e.detectorOptions),l=(I=e.resolver)!=null?I:Pm(e.resolverOptions),c=new WeakMap,u=new WeakSet,f=new Set;function m(N){return N instanceof ShadowRoot?"shadow":"document"}function h(N,_){const M={root:N,rootType:m(N),reason:_,timestamp:n()};for(const W of f)try{W(M)}catch(C){}}function d(N){var _,M,W;try{const C=(_=N.getRootNode)==null?void 0:_.call(N);return C instanceof ShadowRoot?C:(M=N.ownerDocument)!=null?M:document}catch(C){return(W=N.ownerDocument)!=null?W:document}}function b(N){if(u.has(N))return;if(u.add(N),N instanceof ShadowRoot){if(!i)return;t.observeMutation(N,()=>g(N,"shadow_mutation"),{childList:!0,subtree:!0,characterData:!0,attributes:!0});return}if(!o)return;const _=N.head;_&&t.observeMutation(_,()=>g(N,"head_mutation"),{childList:!0,subtree:!0,characterData:!0,attributes:!0})}function S(N){const _=c.get(N);if(_)if(r>0)if(n()-_.collectedAt>=r)g(N,"ttl");else return _.index;else return _.index;const M=a.collectRootIndex(N);return c.set(N,{index:M,collectedAt:n()}),M}function g(N,_="manual"){c.delete(N),h(N,_)}function k(N,_){const M=[..._].sort((W,C)=>W.order-C.order);return{name:N,kind:"unknown",declarations:M}}function v(N,_={}){b(N);const M=S(N),W=[];for(const[C,p]of M.tokens)W.push(k(C,p));return _.sortByName!==!1&&W.sort((C,p)=>C.name.localeCompare(p.name)),{tokens:W,warnings:M.warnings,stats:M.stats}}function L(N,_={}){var B,Y;const M=d(N);b(M);const W=S(M),C=new Set;for(const Q of W.tokens.keys())C.add(Q);if(_.includeInlineAncestors!==!1){const Q=(B=_.inlineMaxDepth)!=null?B:s,te=a.collectInlineTokenNames(N,{maxDepth:Q});for(const se of te)C.add(se)}const y=[];let R=null;try{R=window.getComputedStyle(N)}catch(Q){}if(R)for(const Q of C){let te="";try{te=R.getPropertyValue(Q).trim()}catch(pe){}if(!te)continue;const se=(Y=W.tokens.get(Q))!=null?Y:[];y.push({token:k(Q,se),computedValue:te})}return _.sortByName!==!1&&y.sort((Q,te)=>Q.token.name.localeCompare(te.token.name)),{tokens:y,warnings:W.warnings,stats:W.stats}}function A(N,_){return l.resolveToken(N,_)}function O(N,_,M,W){return l.resolveTokenForProperty(N,_,M,W)}function V(N,_){return l.formatCssVar(N,_)}function F(N){return l.parseCssVar(N)}function T(N){return l.extractCssVarNames(N)}function P(N,_,M,W,C){const p=V(W,C==null?void 0:C.fallback);return N.applyStyle(_,M,p,{merge:C==null?void 0:C.merge})}function j(N){return f.add(N),()=>f.delete(N)}function E(){f.clear(),t.dispose()}return{getRootTokens:v,getContextTokens:L,resolveToken:A,resolveTokenForProperty:O,formatCssVar:V,parseCssVar:F,extractCssVarNames:T,invalidateRoot:g,onInvalidation:j,applyTokenToStyle:P,dispose:E}}function Fm(){const e={active:!1,shadowHost:null,canvasOverlay:null,handlesController:null,eventController:null,positionTracker:null,selectionEngine:null,dragReorderController:null,transactionManager:null,executionTracker:null,hmrConsistencyVerifier:null,toolbar:null,breadcrumbs:null,propertyPanel:null,propsBridge:null,tokensService:null,perfMonitor:null,perfHotkeyCleanup:null,hoveredElement:null,pendingHoverTransition:!1,selectedElement:null,applyingSnapshot:null,toolbarPosition:null,propertyPanelPosition:null,uiResizeCleanup:null},t={alt:!1,shift:!1,ctrl:!1,meta:!1};let n=null;function r(E){return!(!(E instanceof HTMLElement)||E instanceof HTMLInputElement||E instanceof HTMLTextAreaElement||E.childElementCount>0)}function o(E){const{element:w,beforeContentEditable:D,beforeSpellcheck:$}=E;D===null?w.removeAttribute("contenteditable"):w.setAttribute("contenteditable",D),w.spellcheck=$,w.removeEventListener("keydown",E.keydownHandler,!0),w.removeEventListener("blur",E.blurHandler,!0)}function i(){var $,x;const E=n;if(!E)return;n=null;const w=E.element,D=($=w.textContent)!=null?$:"";w.textContent=D,o(E),E.beforeText!==D&&((x=e.transactionManager)==null||x.recordText(w,E.beforeText,D)),console.log(`${_e} Text edit committed`)}function s(){const E=n;E&&(n=null,E.element.textContent=E.beforeText,o(E),console.log(`${_e} Text edit cancelled`))}function a(E,w){var _;if(!r(E)||!E.isConnected)return!1;if(e.selectedElement!==E&&c(E,w),(n==null?void 0:n.element)===E)return!0;n&&i();const D=(_=E.textContent)!=null?_:"",$=E.getAttribute("contenteditable"),x=E.spellcheck,I=M=>{var W;M.key==="Escape"&&(M.preventDefault(),M.stopPropagation(),M.stopImmediatePropagation(),s(),(W=e.eventController)==null||W.setMode("selecting"))},N=()=>{var M;i(),(M=e.eventController)==null||M.setMode("selecting")};E.addEventListener("keydown",I,!0),E.addEventListener("blur",N,!0),E.setAttribute("contenteditable","true"),E.spellcheck=!1;try{E.focus({preventScroll:!0})}catch(M){try{E.focus()}catch(W){}}return n={element:E,beforeText:D,beforeContentEditable:$,beforeSpellcheck:x,keydownHandler:I,blurHandler:N},console.log(`${_e} Text edit started`),!0}function l(E){const w=e.hoveredElement;e.hoveredElement=E;const D=w!==null&&E!==null&&w!==E;e.pendingHoverTransition=D,e.positionTracker&&(e.positionTracker.setHoverElement(E),e.positionTracker.forceUpdate())}function c(E,w){var $,x,I,N;n&&n.element!==E&&i(),e.selectedElement=E,e.hoveredElement=null,e.positionTracker&&(e.positionTracker.setHoverElement(null),e.positionTracker.setSelectionElement(E),e.positionTracker.forceUpdate()),($=e.breadcrumbs)==null||$.setTarget(E),(x=e.propertyPanel)==null||x.setTarget(E),(I=e.handlesController)==null||I.setTarget(E),(N=e.hmrConsistencyVerifier)==null||N.onSelectionChange(E),g(E);const D=w.alt?" (Alt: drill-up)":"";console.log(`${_e} Selected${D}:`,E.tagName,E)}function u(){var E,w,D,$;e.selectedElement=null,e.positionTracker&&(e.positionTracker.setSelectionElement(null),e.positionTracker.forceUpdate()),(E=e.breadcrumbs)==null||E.setTarget(null),(w=e.propertyPanel)==null||w.setTarget(null),(D=e.handlesController)==null||D.setTarget(null),($=e.hmrConsistencyVerifier)==null||$.onSelectionChange(null),g(null),console.log(`${_e} Deselected`)}function f(E){var D,$;(D=e.breadcrumbs)==null||D.setAnchorRect(E.selection);const w=e.pendingHoverTransition;e.pendingHoverTransition=!1,e.canvasOverlay&&(e.canvasOverlay.setHoverRect(E.hover,{animate:w}),e.canvasOverlay.setSelectionRect(E.selection),($=e.handlesController)==null||$.setSelectionRect(E.selection),e.canvasOverlay.render())}const m=100;let h=null,d="push";function b(E){d=E;const w=E==="clear";h!==null&&(window.clearTimeout(h),h=null);const D=()=>{var M;const $=e.transactionManager;if(!$)return;const x=$.getUndoStack(),I=$.getRedoStack(),N=qo(x),_={tabId:0,action:d,elements:N,undoCount:x.length,redoCount:I.length,hasApplicableChanges:N.length>0,pageUrl:window.location.href};typeof chrome!="undefined"&&((M=chrome.runtime)!=null&&M.sendMessage)&&chrome.runtime.sendMessage({type:Ot.WEB_EDITOR_TX_CHANGED,payload:_}).catch(()=>{})};w?D():h=window.setTimeout(D,m)}let S=null;function g(E){var $;let w=null;if(E){const x=Mt(E);if(x===S)return;S=x;const I=Ge(E);w={elementKey:x,locator:I,label:Uo(E),fullLabel:wa(E),tagName:E.tagName.toLowerCase(),updatedAt:Date.now()}}else{if(S===null)return;S=null}const D={tabId:0,selected:w,pageUrl:window.location.href};typeof chrome!="undefined"&&(($=chrome.runtime)!=null&&$.sendMessage)&&chrome.runtime.sendMessage({type:Ot.WEB_EDITOR_SELECTION_CHANGED,payload:D}).catch(()=>{})}function k(){var $;if(S=null,typeof chrome=="undefined"||!(($=chrome.runtime)!=null&&$.sendMessage))return;const E=window.location.href,w={tabId:0,action:"clear",elements:[],undoCount:0,redoCount:0,hasApplicableChanges:!1,pageUrl:E},D={tabId:0,selected:null,pageUrl:E};chrome.runtime.sendMessage({type:Ot.WEB_EDITOR_TX_CHANGED,payload:w}).catch(()=>{}),chrome.runtime.sendMessage({type:Ot.WEB_EDITOR_SELECTION_CHANGED,payload:D}).catch(()=>{})}function v(E){var x,I,N;const{action:w,undoCount:D,redoCount:$}=E;console.log(`${_e} Transaction: ${w} (undo: ${D}, redo: ${$})`),(x=e.toolbar)==null||x.setHistory(D,$),(w==="undo"||w==="redo")&&((I=e.propertyPanel)==null||I.refresh()),b(w),(N=e.hmrConsistencyVerifier)==null||N.onTransactionChange(E)}function L(){return Qe(this,null,function*(){var x;const E=e.transactionManager;if(!E)throw new Error("Transaction manager not ready");if(e.applyingSnapshot)throw new Error("Apply already in progress");const w=E.getUndoStack();if(w.length===0)throw new Error("No changes to apply");for(const I of w){if(I.type==="move")throw new Error("Apply does not support reorder operations yet");if(I.type==="structure")throw new Error("Apply does not support structure operations yet");if(I.type!=="style"&&I.type!=="text"&&I.type!=="class")throw new Error(`Apply does not support "${I.type}" transactions`)}const D=qo(w);if(D.length===0)throw new Error("No net changes to apply");const $=w[w.length-1];e.applyingSnapshot={txId:$.id,txTimestamp:$.timestamp};try{if(typeof chrome=="undefined"||!((x=chrome.runtime)!=null&&x.sendMessage))throw new Error("Chrome runtime API not available");const I={tabId:0,elements:D,excludedKeys:[],pageUrl:window.location.href},_=yield chrome.runtime.sendMessage({type:Ot.WEB_EDITOR_APPLY_BATCH,payload:I});if(_&&_.success===!0){const W=typeof _.requestId=="string"?_.requestId:void 0,C=typeof _.sessionId=="string"?_.sessionId:void 0;return W&&C&&e.executionTracker&&e.executionTracker.track(W,C),E.clear(),u(),{requestId:W,sessionId:C}}const M=typeof(_==null?void 0:_.error)=="string"?_.error:"Agent request failed";throw new Error(M)}finally{e.applyingSnapshot=null}})}function A(E){return Qe(this,null,function*(){var $,x,I,N,_;const w=String(E!=null?E:"").trim();if(!w)return{success:!1,error:"elementKey is required"};const D=e.transactionManager;if(!D)return{success:!1,error:"Transaction manager not ready"};if(e.applyingSnapshot)return{success:!1,error:"Cannot revert while Apply is in progress"};try{const M=D.getUndoStack(),C=qo(M).find(te=>te.elementKey===w);if(!C)return{success:!1,error:"Element not found in current changes"};const p=He(C.locator);if(!p||!p.isConnected)return{success:!1,error:"Failed to locate element for revert"};const y={};let R=!1;const B=C.netEffect.classChanges;if(B){const te=Array.isArray(B.before)?B.before:[],se=(()=>{var we;try{const H=p.classList;if(H&&typeof H[Symbol.iterator]=="function")return Array.from(H).filter(Boolean)}catch(H){}return((we=p.getAttribute("class"))!=null?we:"").split(/\s+/).map(H=>H.trim()).filter(Boolean)})();D.recordClass(p,se,te)&&(y.class=!0,R=!0)}const Y=C.netEffect.textChange;if(Y){const te=String(($=Y.before)!=null?$:""),se=(x=p.textContent)!=null?x:"";se!==te&&(p.textContent=te,D.recordText(p,se,te)&&(y.text=!0,R=!0))}const Q=C.netEffect.styleChanges;if(Q){const te=(I=Q.before)!=null?I:{},se=(N=Q.after)!=null?N:{},pe=Array.from(new Set([...Object.keys(te),...Object.keys(se)])).map(xe=>String(xe!=null?xe:"").trim()).filter(Boolean);if(pe.length>0){const xe=D.beginMultiStyle(p,pe);xe&&(xe.set(te),xe.commit({merge:!1})&&(y.style=!0,R=!0))}}return R?((_=e.propertyPanel)==null||_.refresh(),{success:!0,reverted:y}):{success:!1,error:"No changes were reverted"}}catch(M){return console.error(`${_e} Revert element failed:`,M),{success:!1,error:M instanceof Error?M.message:String(M)}}})}function O(){e.selectedElement&&(e.eventController?(e.eventController.setMode("hover"),e.selectedElement&&u()):u(),console.log(`${_e} Selection cleared (from sidepanel)`))}function V(E){console.error(`${_e} Transaction apply error:`,E)}function F(){var E,w,D,$,x,I,N,_,M,W,C,p,y,R,B,Y,Q,te;if(e.active){console.log(`${_e} Already active`);return}try{e.shadowHost=fl({});const se=e.shadowHost.getElements();if(!(se!=null&&se.overlayRoot))throw new Error("Shadow host overlayRoot not available");e.canvasOverlay=Lf({container:se.overlayRoot}),e.perfMonitor=Im({container:se.overlayRoot,fpsUiIntervalMs:500,memorySampleIntervalMs:1e3});const pe=ne=>{if(ne.repeat||!(ne.metaKey||ne.ctrlKey)||!ne.shiftKey||ne.altKey||(ne.key||"").toLowerCase()!=="p")return;const J=e.perfMonitor;J&&(J.toggle(),ne.preventDefault(),ne.stopPropagation(),ne.stopImmediatePropagation())},xe={capture:!0,passive:!1};window.addEventListener("keydown",pe,xe),e.perfHotkeyCleanup=()=>{window.removeEventListener("keydown",pe,xe)},e.selectionEngine=yp({isOverlayElement:e.shadowHost.isOverlayElement}),e.positionTracker=cp({onPositionUpdate:f}),e.transactionManager=Up({enableKeyBindings:!0,isEventFromEditorUi:ne=>{var z;if((z=e.shadowHost)!=null&&z.isEventFromUi(ne))return!0;const me=n;if(me!=null&&me.element)try{const J=typeof ne.composedPath=="function"?ne.composedPath():null;if(J!=null&&J.some(le=>le===me.element))return!0}catch(J){const le=ne.target;if(le instanceof Node&&me.element.contains(le))return!0}return!1},onChange:v,onApplyError:V}),e.handlesController=jf({container:se.overlayRoot,canvasOverlay:e.canvasOverlay,transactionManager:e.transactionManager,positionTracker:e.positionTracker}),e.dragReorderController=ep({isOverlayElement:e.shadowHost.isOverlayElement,uiRoot:se.uiRoot,canvasOverlay:e.canvasOverlay,positionTracker:e.positionTracker,transactionManager:e.transactionManager}),e.eventController=ip({isOverlayElement:e.shadowHost.isOverlayElement,onHover:l,onSelect:c,onDeselect:u,onStartEdit:a,findTargetForSelect:(ne,me,z,J)=>{var le,be;return(be=(le=e.selectionEngine)==null?void 0:le.findBestTargetFromEvent(J,z))!=null?be:null},getSelectedElement:()=>e.selectedElement,onStartDrag:ne=>{var me,z;return(z=(me=e.dragReorderController)==null?void 0:me.onDragStart(ne))!=null?z:!1},onDragMove:ne=>{var me;return(me=e.dragReorderController)==null?void 0:me.onDragMove(ne)},onDragEnd:ne=>{var me;return(me=e.dragReorderController)==null?void 0:me.onDragEnd(ne)},onDragCancel:ne=>{var me;return(me=e.dragReorderController)==null?void 0:me.onDragCancel(ne)}}),e.executionTracker=nm({onStatusChange:ne=>{var J,le,be,Te,Ne;if(!(((le=(J=e.hmrConsistencyVerifier)==null?void 0:J.getSnapshot().phase)!=null?le:"idle")!=="idle")||ne.status!=="completed"){const G=(be={pending:"applying",starting:"starting",running:"running",locating:"locating",applying:"applying",completed:"completed",failed:"failed",error:"failed",timeout:"timeout",cancelled:"cancelled"}[ne.status])!=null?be:"running";(Te=e.toolbar)==null||Te.setStatus(G,ne.message)}(Ne=e.hmrConsistencyVerifier)==null||Ne.onExecutionStatus(ne)}}),e.hmrConsistencyVerifier=Nm({transactionManager:e.transactionManager,getSelectedElement:()=>e.selectedElement,onReselect:ne=>c(ne,t),onDeselect:u,setToolbarStatus:(ne,me)=>{var z;return(z=e.toolbar)==null?void 0:z.setStatus(ne,me)},isOverlayElement:(E=e.shadowHost)==null?void 0:E.isOverlayElement,selectionEngine:(w=e.selectionEngine)!=null?w:void 0}),e.toolbar=Tl({container:se.uiRoot,dock:"top",initialPosition:e.toolbarPosition,onPositionChange:ne=>{e.toolbarPosition=ne},getApplyBlockReason:()=>{const ne=e.transactionManager;if(!ne)return;const me=ne.getUndoStack();if(me.length!==0)for(const z of me){if(z.type==="move")return"Apply does not support reorder operations yet";if(z.type==="structure")return"Apply does not support structure operations yet";if(z.type!=="style"&&z.type!=="text"&&z.type!=="class")return`Apply does not support "${z.type}" transactions`}},getSelectedElement:()=>e.selectedElement,onStructure:ne=>{const me=e.selectedElement;if(!me)return;const z=e.transactionManager;if(!z)return;const J=z.applyStructure(me,ne);if(J)if(ne.action==="delete")u();else{const le=He(J.targetLocator);le&&le.isConnected&&c(le,t)}},onApply:L,onUndo:()=>{var ne;return(ne=e.transactionManager)==null?void 0:ne.undo()},onRedo:()=>{var ne;return(ne=e.transactionManager)==null?void 0:ne.redo()},onRequestClose:()=>T()}),e.toolbar.setHistory(e.transactionManager.getUndoStack().length,e.transactionManager.getRedoStack().length),e.breadcrumbs=Fl({container:se.uiRoot,dock:"top",onSelect:ne=>{ne.isConnected&&c(ne,t)}}),e.propsBridge=_f({}),e.tokensService=Om(),e.propertyPanel=yf({container:se.uiRoot,transactionManager:e.transactionManager,propsBridge:e.propsBridge,tokensService:e.tokensService,initialPosition:e.propertyPanelPosition,onPositionChange:ne=>{e.propertyPanelPosition=ne},defaultTab:"design",onSelectElement:ne=>{ne.isConnected&&c(ne,t)},onRequestClose:()=>T()});let we=null;const H=()=>{const ne=e.toolbarPosition,me=e.propertyPanelPosition;e.toolbar&&ne&&e.toolbar.setPosition(ne),e.propertyPanel&&me&&e.propertyPanel.setPosition(me)},ae=()=>{e.active&&we===null&&(we=window.requestAnimationFrame(()=>{we=null,H()}))};window.addEventListener("resize",ae,{passive:!0}),e.uiResizeCleanup=()=>{window.removeEventListener("resize",ae),we!==null&&(window.cancelAnimationFrame(we),we=null)},H(),e.active=!0,console.log(`${_e} Started`)}catch(se){(D=e.uiResizeCleanup)==null||D.call(e),e.uiResizeCleanup=null,($=e.propertyPanel)==null||$.dispose(),e.propertyPanel=null,(x=e.tokensService)==null||x.dispose(),e.tokensService=null,(I=e.propsBridge)==null||I.dispose(),e.propsBridge=null,(N=e.breadcrumbs)==null||N.dispose(),e.breadcrumbs=null,(_=e.toolbar)==null||_.dispose(),e.toolbar=null,(M=e.eventController)==null||M.dispose(),e.eventController=null,(W=e.dragReorderController)==null||W.dispose(),e.dragReorderController=null,(C=e.handlesController)==null||C.dispose(),e.handlesController=null,(p=e.transactionManager)==null||p.dispose(),e.transactionManager=null,(y=e.positionTracker)==null||y.dispose(),e.positionTracker=null,(R=e.selectionEngine)==null||R.dispose(),e.selectionEngine=null,(B=e.perfHotkeyCleanup)==null||B.call(e),e.perfHotkeyCleanup=null,(Y=e.perfMonitor)==null||Y.dispose(),e.perfMonitor=null,(Q=e.canvasOverlay)==null||Q.dispose(),e.canvasOverlay=null,(te=e.shadowHost)==null||te.dispose(),e.shadowHost=null,e.hoveredElement=null,e.selectedElement=null,e.applyingSnapshot=null,e.active=!1,console.error(`${_e} Failed to start:`,se)}}function T(){var E,w,D,$,x,I,N,_,M,W,C,p,y,R,B,Y,Q,te;if(e.active){e.active=!1,h!==null&&(window.clearTimeout(h),h=null);try{n&&i(),(E=e.uiResizeCleanup)==null||E.call(e),e.uiResizeCleanup=null,(w=e.propertyPanel)==null||w.dispose(),e.propertyPanel=null,(D=e.tokensService)==null||D.dispose(),e.tokensService=null,($=e.propsBridge)==null||$.cleanup(),e.propsBridge=null,(x=e.breadcrumbs)==null||x.dispose(),e.breadcrumbs=null,(I=e.toolbar)==null||I.dispose(),e.toolbar=null,(N=e.eventController)==null||N.dispose(),e.eventController=null,(_=e.dragReorderController)==null||_.dispose(),e.dragReorderController=null,(M=e.handlesController)==null||M.dispose(),e.handlesController=null,(W=e.executionTracker)==null||W.dispose(),e.executionTracker=null,(C=e.hmrConsistencyVerifier)==null||C.dispose(),e.hmrConsistencyVerifier=null,(p=e.transactionManager)==null||p.dispose(),e.transactionManager=null,(y=e.positionTracker)==null||y.dispose(),e.positionTracker=null,(R=e.selectionEngine)==null||R.dispose(),e.selectionEngine=null,(B=e.perfHotkeyCleanup)==null||B.call(e),e.perfHotkeyCleanup=null,(Y=e.perfMonitor)==null||Y.dispose(),e.perfMonitor=null,(Q=e.canvasOverlay)==null||Q.dispose(),e.canvasOverlay=null,(te=e.shadowHost)==null||te.dispose(),e.shadowHost=null,e.hoveredElement=null,e.selectedElement=null,e.applyingSnapshot=null,console.log(`${_e} Stopped`)}catch(se){console.error(`${_e} Error during cleanup:`,se),e.propertyPanel=null,e.propsBridge=null,e.breadcrumbs=null,e.toolbar=null,e.eventController=null,e.dragReorderController=null,e.handlesController=null,e.transactionManager=null,e.positionTracker=null,e.selectionEngine=null,e.perfHotkeyCleanup=null,e.perfMonitor=null,e.canvasOverlay=null,e.shadowHost=null,e.hoveredElement=null,e.selectedElement=null,e.applyingSnapshot=null}finally{k()}}}function P(){return e.active?T():F(),e.active}function j(){return{active:e.active,version:qe}}return{start:F,stop:T,toggle:P,getState:j,revertElement:A,clearSelection:O}}const Ct={PING:"web_editor_ping_v2",TOGGLE:"web_editor_toggle_v2",START:"web_editor_start_v2",STOP:"web_editor_stop_v2",HIGHLIGHT_ELEMENT:"web_editor_highlight_element_v2",REVERT_ELEMENT:"web_editor_revert_element_v2",CLEAR_SELECTION:"web_editor_clear_selection_v2"};function Bm(e){if(!e||typeof e!="object")return!1;const t=e.action;return t===Ct.PING||t===Ct.TOGGLE||t===Ct.START||t===Ct.STOP}function Vm(e){if(!e||typeof e!="object")return!1;const t=e;if(t.action!==Ct.HIGHLIGHT_ELEMENT||t.mode!=="hover"&&t.mode!=="clear")return!1;if(t.mode==="clear")return!0;const n=typeof t.selector=="string"&&t.selector.trim().length>0,r=t.locator!==null&&typeof t.locator=="object";return n||r}function $m(e){if(!e||typeof e!="object")return!1;const t=e;return t.action===Ct.REVERT_ELEMENT&&typeof t.elementKey=="string"&&t.elementKey.trim().length>0}function Hm(e){return!e||typeof e!="object"?!1:e.action===Ct.CLEAR_SELECTION}let An=null;function ei(){An&&An.parentNode&&An.parentNode.removeChild(An),An=null}function zm(e){ei();const t=e.getBoundingClientRect();if(t.width===0&&t.height===0)return;const n=document.createElement("div");n.setAttribute("data-web-editor-highlight","true"),n.style.cssText=`
    position: fixed;
    top: ${t.top}px;
    left: ${t.left}px;
    width: ${t.width}px;
    height: ${t.height}px;
    background-color: rgba(59, 130, 246, 0.15);
    border: 2px solid rgba(59, 130, 246, 0.8);
    border-radius: 4px;
    pointer-events: none;
    z-index: 2147483646;
    box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
    transition: all 0.15s ease;
  `,document.body.appendChild(n),An=n}function Um(e){try{return document.querySelector(e)}catch(t){return null}}function Gm(e){const t=(n,r,o)=>{if(Vm(n)){if(n.mode==="clear")ei(),o({success:!0});else{let i=null;if(n.locator)try{i=He(n.locator)}catch(s){i=null}!i&&typeof n.selector=="string"&&(i=Um(n.selector)),i?(zm(i),o({success:!0})):o({success:!1,error:"Element not found"})}return!1}if($m(n))return Qe(null,null,function*(){try{const i=yield e.revertElement(n.elementKey);o(i)}catch(i){o({success:!1,error:i instanceof Error?i.message:String(i)})}}),!0;if(Hm(n))return e.clearSelection(),o({success:!0}),!1;if(!Bm(n))return!1;switch(n.action){case Ct.PING:{const i={status:"pong",active:e.getState().active,version:2};return o(i),!1}case Ct.TOGGLE:{const i={active:e.toggle()};return o(i),!1}case Ct.START:return e.start(),o({active:!0}),!1;case Ct.STOP:return e.stop(),o({active:!1}),!1;default:return!1}};return chrome.runtime.onMessage.addListener(t),()=>{chrome.runtime.onMessage.removeListener(t),ei()}}const Wm=Ke(()=>{if(window!==window.top)return;if(window.__MCP_WEB_EDITOR_V2__){console.log(`${_e} Already installed, skipping initialization`);return}const e=Fm();window.__MCP_WEB_EDITOR_V2__=e,Gm(e),console.log(`${_e} Installed successfully`)});function Zm(){}function Ur(e,...t){}const Xm={debug:(...e)=>Ur(console.debug,...e),log:(...e)=>Ur(console.log,...e),warn:(...e)=>Ur(console.warn,...e),error:(...e)=>Ur(console.error,...e)};return Qe(null,null,function*(){try{return yield Wm.main()}catch(e){throw Xm.error('The unlisted script "web-editor-v2" crashed on startup!',e),e}})})();
webEditorV2;