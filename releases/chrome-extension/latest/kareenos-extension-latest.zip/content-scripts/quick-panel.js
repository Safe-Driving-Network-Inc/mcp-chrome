var quickPanel=(function(){"use strict";var bt=Object.defineProperty,_t=Object.defineProperties;var vt=Object.getOwnPropertyDescriptors;var oe=Object.getOwnPropertySymbols;var Ce=Object.prototype.hasOwnProperty,Ae=Object.prototype.propertyIsEnumerable;var fe=(x,_,v)=>_ in x?bt(x,_,{enumerable:!0,configurable:!0,writable:!0,value:v}):x[_]=v,Y=(x,_)=>{for(var v in _||(_={}))Ce.call(_,v)&&fe(x,v,_[v]);if(oe)for(var v of oe(_))Ae.call(_,v)&&fe(x,v,_[v]);return x},Le=(x,_)=>_t(x,vt(_));var Ne=(x,_)=>{var v={};for(var R in x)Ce.call(x,R)&&_.indexOf(R)<0&&(v[R]=x[R]);if(x!=null&&oe)for(var R of oe(x))_.indexOf(R)<0&&Ae.call(x,R)&&(v[R]=x[R]);return v};var S=(x,_,v)=>fe(x,typeof _!="symbol"?_+"":_,v);var M=(x,_,v)=>new Promise((R,J)=>{var se=A=>{try{Q(v.next(A))}catch(W){J(W)}},ie=A=>{try{Q(v.throw(A))}catch(W){J(W)}},Q=A=>A.done?R(A.value):Promise.resolve(A.value).then(se,ie);Q((v=v.apply(x,_)).next())});var Se,Ie;function x(t){return t}const _={SWITCH_SEMANTIC_MODEL:"switch_semantic_model",GET_MODEL_STATUS:"get_model_status",UPDATE_MODEL_STATUS:"update_model_status",GET_STORAGE_STATS:"get_storage_stats",CLEAR_ALL_DATA:"clear_all_data",GET_SERVER_STATUS:"get_server_status",REFRESH_SERVER_STATUS:"refresh_server_status",SERVER_STATUS_CHANGED:"server_status_changed",INITIALIZE_SEMANTIC_ENGINE:"initialize_semantic_engine",RR_START_RECORDING:"rr_start_recording",RR_STOP_RECORDING:"rr_stop_recording",RR_PAUSE_RECORDING:"rr_pause_recording",RR_RESUME_RECORDING:"rr_resume_recording",RR_GET_RECORDING_STATUS:"rr_get_recording_status",RR_LIST_FLOWS:"rr_list_flows",RR_FLOWS_CHANGED:"rr_flows_changed",RR_GET_FLOW:"rr_get_flow",RR_DELETE_FLOW:"rr_delete_flow",RR_PUBLISH_FLOW:"rr_publish_flow",RR_UNPUBLISH_FLOW:"rr_unpublish_flow",RR_RUN_FLOW:"rr_run_flow",RR_SAVE_FLOW:"rr_save_flow",RR_EXPORT_FLOW:"rr_export_flow",RR_EXPORT_ALL:"rr_export_all",RR_IMPORT_FLOW:"rr_import_flow",RR_LIST_RUNS:"rr_list_runs",RR_LIST_TRIGGERS:"rr_list_triggers",RR_SAVE_TRIGGER:"rr_save_trigger",RR_DELETE_TRIGGER:"rr_delete_trigger",RR_REFRESH_TRIGGERS:"rr_refresh_triggers",RR_SCHEDULE_FLOW:"rr_schedule_flow",RR_UNSCHEDULE_FLOW:"rr_unschedule_flow",RR_LIST_SCHEDULES:"rr_list_schedules",ELEMENT_MARKER_LIST_ALL:"element_marker_list_all",ELEMENT_MARKER_LIST_FOR_URL:"element_marker_list_for_url",ELEMENT_MARKER_SAVE:"element_marker_save",ELEMENT_MARKER_UPDATE:"element_marker_update",ELEMENT_MARKER_DELETE:"element_marker_delete",ELEMENT_MARKER_VALIDATE:"element_marker_validate",ELEMENT_MARKER_START:"element_marker_start_from_popup",ELEMENT_PICKER_UI_EVENT:"element_picker_ui_event",ELEMENT_PICKER_FRAME_EVENT:"element_picker_frame_event",WEB_EDITOR_TOGGLE:"web_editor_toggle",WEB_EDITOR_APPLY:"web_editor_apply",WEB_EDITOR_STATUS_QUERY:"web_editor_status_query",WEB_EDITOR_APPLY_BATCH:"web_editor_apply_batch",WEB_EDITOR_TX_CHANGED:"web_editor_tx_changed",WEB_EDITOR_HIGHLIGHT_ELEMENT:"web_editor_highlight_element",WEB_EDITOR_REVERT_ELEMENT:"web_editor_revert_element",WEB_EDITOR_SELECTION_CHANGED:"web_editor_selection_changed",WEB_EDITOR_CLEAR_SELECTION:"web_editor_clear_selection",WEB_EDITOR_CANCEL_EXECUTION:"web_editor_cancel_execution",WEB_EDITOR_PROPS_REGISTER_EARLY_INJECTION:"web_editor_props_register_early_injection",WEB_EDITOR_OPEN_SOURCE:"web_editor_open_source",QUICK_PANEL_SEND_TO_AI:"quick_panel_send_to_ai",QUICK_PANEL_CANCEL_AI:"quick_panel_cancel_ai",QUICK_PANEL_TABS_QUERY:"quick_panel_tabs_query",QUICK_PANEL_TAB_ACTIVATE:"quick_panel_tab_activate",QUICK_PANEL_TAB_CLOSE:"quick_panel_tab_close"},v={QUICK_PANEL_AI_EVENT:"quick_panel_ai_event"},R="[QuickPanelAgentBridge]",J=200,se=3e4;class ie{constructor(e){S(this,"listenersByRequestId",new Map);S(this,"bufferByRequestId",new Map);S(this,"cleanupTimers",new Map);S(this,"maxBufferedEvents");S(this,"boundMessageHandler");S(this,"disposed",!1);var r;this.maxBufferedEvents=(r=e==null?void 0:e.maxBufferedEvents)!=null?r:J,this.boundMessageHandler=this.handleMessage.bind(this),chrome.runtime.onMessage.addListener(this.boundMessageHandler)}dispose(){if(!this.disposed){this.disposed=!0,chrome.runtime.onMessage.removeListener(this.boundMessageHandler),this.listenersByRequestId.clear(),this.bufferByRequestId.clear();for(const e of this.cleanupTimers.values())clearTimeout(e);this.cleanupTimers.clear()}}isDisposed(){return this.disposed}onRequestEvent(e,r){if(this.disposed)return console.warn(`${R} Cannot subscribe - bridge is disposed`),()=>{};const n=e.trim();if(!n)return console.warn(`${R} Invalid requestId`),()=>{};let a=this.listenersByRequestId.get(n);a||(a=new Set,this.listenersByRequestId.set(n,a)),a.add(r);const o=this.bufferByRequestId.get(n);if(o&&o.length>0){for(const i of o)this.safeInvokeListener(r,i);this.bufferByRequestId.delete(n)}return()=>{const i=this.listenersByRequestId.get(n);i&&(i.delete(r),i.size===0&&this.listenersByRequestId.delete(n))}}sendToAI(e){return M(this,null,function*(){if(this.disposed)return{success:!1,error:"Bridge is disposed"};try{return yield chrome.runtime.sendMessage({type:_.QUICK_PANEL_SEND_TO_AI,payload:e})}catch(r){return{success:!1,error:(r instanceof Error?r.message:String(r))||"Failed to send message"}}})}cancelRequest(e,r){return M(this,null,function*(){if(this.disposed)return{success:!1,error:"Bridge is disposed"};try{return yield chrome.runtime.sendMessage({type:_.QUICK_PANEL_CANCEL_AI,payload:{requestId:e,sessionId:r}})}catch(n){return{success:!1,error:(n instanceof Error?n.message:String(n))||"Failed to cancel request"}}})}hasListeners(e){const r=this.listenersByRequestId.get(e);return r!==void 0&&r.size>0}getActiveRequestCount(){return this.listenersByRequestId.size+this.bufferByRequestId.size}handleMessage(e){if(this.disposed)return;const r=e;if(!r||r.action!==v.QUICK_PANEL_AI_EVENT)return;const n=typeof r.requestId=="string"?r.requestId:"",a=r.event;if(!n||!a)return;const o=this.listenersByRequestId.get(n);if(o&&o.size>0)for(const i of o)this.safeInvokeListener(i,a);else this.bufferEvent(n,a);this.isTerminalEvent(a,n)&&this.scheduleDelayedCleanup(n)}safeInvokeListener(e,r){try{e(r)}catch(n){console.warn(`${R} Listener error:`,n)}}bufferEvent(e,r){let n=this.bufferByRequestId.get(e);n||(n=[],this.bufferByRequestId.set(e,n)),n.push(r),n.length>this.maxBufferedEvents&&n.splice(0,n.length-this.maxBufferedEvents)}isTerminalEvent(e,r){if(e.type==="error")return!0;if(e.type==="status"){const n=e.data;if((n==null?void 0:n.requestId)!==r)return!1;const a=n.status;return a==="completed"||a==="error"||a==="cancelled"}return!1}cleanupRequest(e){const r=this.cleanupTimers.get(e);r&&(clearTimeout(r),this.cleanupTimers.delete(e)),this.bufferByRequestId.delete(e),this.listenersByRequestId.delete(e)}scheduleDelayedCleanup(e){if(this.cleanupTimers.has(e))return;const r=setTimeout(()=>{this.cleanupTimers.delete(e),this.cleanupRequest(e)},se);this.cleanupTimers.set(e,r)}}function Q(t){return new ie(t)}class A{constructor(){S(this,"disposed",!1);S(this,"disposers",[])}get isDisposed(){return this.disposed}add(e){if(this.disposed){try{e()}catch(r){}return}this.disposers.push(e)}listen(e,r,n,a){e.addEventListener(r,n,a),this.add(()=>e.removeEventListener(r,n,a))}observeResize(e,r,n){const a=new ResizeObserver(r);return a.observe(e,n),this.add(()=>a.disconnect()),a}observeMutation(e,r,n){const a=new MutationObserver(r);return a.observe(e,n),this.add(()=>a.disconnect()),a}requestAnimationFrame(e){const r=requestAnimationFrame(e);let n=!1;const a=()=>{n||(n=!0,cancelAnimationFrame(r))};return this.add(a),a}dispose(){if(!this.disposed){this.disposed=!0;for(let e=this.disposers.length-1;e>=0;e--)try{this.disposers[e]()}catch(r){}this.disposers.length=0}}}const W=`
  /* ============================================================
   * Reset & Box Sizing
   * ============================================================ */

  :host {
    all: initial;
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  [hidden] {
    display: none !important;
  }

  /* ============================================================
   * Root Container & Theme Tokens
   * Subset of AgentChat tokens for Quick Panel use
   * ============================================================ */

  .qp-root {
    position: fixed;
    inset: 0;
    pointer-events: none;
    font-family: var(--ac-font-body, ui-sans-serif, system-ui);
    color: var(--ac-text, #111827);
    line-height: 1.4;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  .qp-root.agent-theme {
    /* ===========================================
     * Font Stacks
     * =========================================== */
    --ac-font-sans:
      'Inter', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial,
      'Apple Color Emoji', 'Segoe UI Emoji';
    --ac-font-serif: 'Newsreader', ui-serif, Georgia, Cambria, 'Times New Roman', Times, serif;
    --ac-font-mono:
      'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono',
      'Courier New', monospace;
    --ac-font-grotesk:
      'Space Grotesk', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial;

    --ac-font-body: var(--ac-font-sans);
    --ac-font-heading: var(--ac-font-serif);
    --ac-font-code: var(--ac-font-mono);

    /* ===========================================
     * Geometry & Spacing
     * =========================================== */
    --ac-border-width: 1px;
    --ac-border-width-strong: 2px;
    --ac-radius-container: 0px;
    --ac-radius-card: 12px;
    --ac-radius-inner: 8px;
    --ac-radius-button: 8px;

    /* ===========================================
     * Motion
     * =========================================== */
    --ac-motion-fast: 120ms;
    --ac-motion-normal: 180ms;

    /* ===========================================
     * Warm Editorial Theme (Default)
     * =========================================== */
    --ac-bg: transparent;
    --ac-bg-pattern: none;
    --ac-bg-pattern-size: 16px 16px;

    --ac-header-bg: rgba(253, 252, 248, 0.95);
    --ac-header-border: rgba(245, 245, 244, 0.5);

    --ac-surface: #ffffff;
    --ac-surface-muted: #f2f0eb;
    --ac-surface-inset: #f2f0eb;

    --ac-text: #1a1a1a;
    --ac-text-muted: #6e6e6e;
    --ac-text-subtle: #a8a29e;
    --ac-text-inverse: #ffffff;
    --ac-text-placeholder: #a8a29e;

    --ac-border: #e7e5e4;
    --ac-border-strong: #d6d3d1;

    --ac-hover-bg: #f5f5f4;
    --ac-hover-bg-subtle: #fafaf9;

    --ac-accent: #d97757;
    --ac-accent-hover: #c4664a;
    --ac-accent-subtle: rgba(217, 119, 87, 0.12);
    --ac-accent-contrast: #ffffff;

    --ac-link: var(--ac-accent);
    --ac-link-hover: var(--ac-accent-hover);

    --ac-selection-bg: #ffedd5;
    --ac-selection-text: #7c2d12;

    --ac-shadow-card: 0 1px 3px rgba(0, 0, 0, 0.08);
    --ac-shadow-float: 0 4px 20px -2px rgba(0, 0, 0, 0.05);

    --ac-focus-ring: rgba(214, 211, 209, 0.9);

    --ac-timeline-node-pulse-shadow:
      0 0 0 2px rgba(217, 119, 87, 0.25), 0 0 12px rgba(217, 119, 87, 0.2);

    /* Status Colors */
    --ac-success: #22c55e;
    --ac-warning: #f59e0b;
    --ac-danger: #ef4444;

    /* Scrollbar */
    --ac-scrollbar-size: 4px;
    --ac-scrollbar-thumb: rgba(0, 0, 0, 0.25);
    --ac-scrollbar-thumb-hover: rgba(0, 0, 0, 0.4);

    /* ===========================================
     * Quick Panel Solid Tokens (Editorial Style)
     * No glassmorphism - solid backgrounds for clarity
     * =========================================== */
    --qp-panel-bg: var(--ac-surface);
    --qp-panel-border: var(--ac-border);
    --qp-panel-shadow: var(--ac-shadow-card), 0 25px 50px -12px rgba(0, 0, 0, 0.15);
    --qp-divider: var(--ac-border);
    --qp-input-bg: var(--ac-surface);
    --qp-input-border: var(--ac-border);
  }

  /* ===========================================
   * Dark Console Theme
   * =========================================== */
  .qp-root.agent-theme[data-agent-theme='dark-console'] {
    --ac-font-body: var(--ac-font-mono);
    --ac-font-heading: var(--ac-font-mono);
    --ac-font-code: var(--ac-font-mono);

    --ac-surface: #0f1117;
    --ac-surface-muted: #0a0c10;
    --ac-surface-inset: #1a1d26;

    --ac-text: #e5e7eb;
    --ac-text-muted: #9ca3af;
    --ac-text-subtle: #6b7280;
    --ac-text-inverse: #0a0c10;
    --ac-text-placeholder: #4b5563;

    --ac-border: #1f2937;
    --ac-border-strong: #374151;

    --ac-hover-bg: rgba(255, 255, 255, 0.06);
    --ac-hover-bg-subtle: rgba(255, 255, 255, 0.04);

    --ac-accent: #d97757;
    --ac-accent-hover: #e8956f;
    --ac-accent-subtle: rgba(217, 119, 87, 0.18);
    --ac-accent-contrast: #ffffff;

    --ac-focus-ring: rgba(217, 119, 87, 0.4);
    --ac-timeline-node-pulse-shadow:
      0 0 0 2px rgba(217, 119, 87, 0.35), 0 0 14px rgba(217, 119, 87, 0.25);

    --ac-scrollbar-thumb: rgba(255, 255, 255, 0.12);
    --ac-scrollbar-thumb-hover: rgba(255, 255, 255, 0.22);

    --qp-panel-bg: var(--ac-surface);
    --qp-panel-border: var(--ac-border);
    --qp-panel-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4);
    --qp-divider: var(--ac-border);
    --qp-input-bg: var(--ac-surface-inset);
    --qp-input-border: var(--ac-border);
  }

  .qp-root ::selection {
    background: var(--ac-selection-bg);
    color: var(--ac-selection-text);
  }

  /* ============================================================
   * Utility Classes (AgentChat Subset)
   * ============================================================ */

  /* Scrollbar Styling */
  .qp-root .ac-scroll {
    scrollbar-width: thin;
    scrollbar-color: var(--ac-scrollbar-thumb) transparent;
  }

  .qp-root .ac-scroll::-webkit-scrollbar {
    width: var(--ac-scrollbar-size);
    height: var(--ac-scrollbar-size);
  }

  .qp-root .ac-scroll::-webkit-scrollbar-track {
    background: transparent;
  }

  .qp-root .ac-scroll::-webkit-scrollbar-thumb {
    background-color: var(--ac-scrollbar-thumb);
    border-radius: 999px;
  }

  .qp-root .ac-scroll::-webkit-scrollbar-thumb:hover {
    background-color: var(--ac-scrollbar-thumb-hover);
  }

  /* Focus Ring */
  .qp-root .ac-focus-ring:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px var(--ac-focus-ring);
  }

  /* Button Base */
  .qp-root .ac-btn {
    transition:
      background-color var(--ac-motion-fast),
      color var(--ac-motion-fast);
  }

  .qp-root .ac-btn:hover {
    background-color: var(--ac-hover-bg);
  }

  /* Pulse Animation (Streaming Indicator) */
  @keyframes ac-pulse {
    0%, 100% {
      opacity: 1;
    }
    50% {
      opacity: 0.5;
    }
  }

  .qp-root .ac-pulse {
    animation: ac-pulse 1.5s cubic-bezier(0.4, 0, 0.6, 1) infinite;
  }

  @media (prefers-reduced-motion: reduce) {
    .qp-root .ac-pulse {
      animation: none;
    }
  }

  /* Text Shimmer (Streaming Status) */
  .qp-root .text-shimmer {
    background: linear-gradient(
      90deg,
      var(--ac-accent, #d97757) 0%,
      var(--ac-accent-hover, #ffcab0) 50%,
      var(--ac-accent, #d97757) 100%
    );
    background-size: 200% auto;
    color: transparent;
    -webkit-background-clip: text;
    background-clip: text;
    animation: ac-shimmer 3s linear infinite;
  }

  @keyframes ac-shimmer {
    to {
      background-position: 200% center;
    }
  }

  /* ============================================================
   * Liquid Glass Panel (PRD V6)
   * ============================================================ */

  .qp-overlay {
    position: fixed;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
    pointer-events: auto;
  }

  .qp-panel {
    width: min(760px, calc(100vw - 48px));
    max-height: min(720px, calc(100vh - 48px));
    display: flex;
    flex-direction: column;
    border-radius: 24px;
    overflow: hidden;
    pointer-events: auto;

    background: var(--qp-panel-bg);
    border: var(--ac-border-width) solid var(--qp-panel-border);
    box-shadow: var(--qp-panel-shadow);
  }

  /* ============================================================
   * AI Chat Layout Components
   * ============================================================ */

  /* Header */
  .qp-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 14px 16px;
    border-bottom: var(--ac-border-width) solid var(--qp-divider);
  }

  .qp-header-left {
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .qp-brand {
    width: 34px;
    height: 34px;
    border-radius: var(--ac-radius-inner);
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--ac-accent-subtle);
    color: var(--ac-accent);
    font-size: 24px;
  }

  .qp-title {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }

  .qp-title-name {
    font-weight: 700;
    font-size: 13px;
    letter-spacing: 0.2px;
    color: var(--ac-text);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .qp-title-sub {
    font-size: 11px;
    color: var(--ac-text-muted);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .qp-header-right {
    display: flex;
    align-items: center;
    gap: 10px;
    flex: none;
  }

  .qp-stream-indicator {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    color: var(--ac-text-muted);
    user-select: none;
  }

  .qp-stream-dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: var(--ac-accent);
    box-shadow: var(--ac-timeline-node-pulse-shadow);
  }

  /* Buttons */
  .qp-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    border: var(--ac-border-width) solid var(--qp-divider);
    background: var(--ac-hover-bg);
    color: var(--ac-text);
    border-radius: var(--ac-radius-button);
    padding: 8px 10px;
    font-size: 11px;
    cursor: pointer;
    user-select: none;
    font-family: inherit;
    transition: background-color var(--ac-motion-fast);
  }

  .qp-btn:hover:not(:disabled) {
    background: var(--ac-hover-bg-subtle);
  }

  .qp-btn:disabled {
    cursor: not-allowed;
    opacity: 0.6;
  }

  .qp-btn--primary {
    background: var(--ac-accent);
    border-color: var(--ac-accent);
    color: var(--ac-accent-contrast);
  }

  .qp-btn--primary:hover:not(:disabled) {
    background: var(--ac-accent-hover);
  }

  .qp-btn--danger {
    background: var(--ac-danger);
    border-color: var(--ac-danger);
    color: #ffffff;
  }

  /* Content Area */
  .qp-content {
    flex: 1;
    overflow: auto;
    padding: 14px;
    min-height: 0;
  }

  .qp-messages {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  /* Message Bubbles */
  .qp-msg {
    display: flex;
    gap: 10px;
  }

  .qp-msg--user {
    justify-content: flex-end;
  }

  .qp-msg--assistant {
    justify-content: flex-start;
  }

  .qp-bubble {
    max-width: 90%;
    border-radius: var(--ac-radius-card);
    border: var(--ac-border-width) solid var(--ac-border);
    box-shadow: var(--ac-shadow-card);
    padding: 10px 12px;
    background: var(--ac-surface);
  }

  .qp-bubble--user {
    background: color-mix(in srgb, var(--ac-accent-subtle) 80%, transparent);
    border-color: color-mix(in srgb, var(--ac-border) 70%, transparent);
  }

  .qp-msg-text {
    font-size: 13px;
    white-space: pre-wrap;
    word-break: break-word;
    color: var(--ac-text);
  }

  .qp-msg-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-top: 6px;
    font-size: 10px;
    color: var(--ac-text-subtle);
  }

  .qp-msg-meta code {
    font-family: var(--ac-font-code);
    font-size: 10px;
  }

  .qp-msg-stream-dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: var(--ac-accent);
    box-shadow: var(--ac-timeline-node-pulse-shadow);
    flex: none;
  }

  /* Status Indicators */
  .qp-status {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 8px 10px;
    border-radius: 999px;
    border: var(--ac-border-width) solid var(--ac-border);
    background: var(--ac-surface-muted);
    color: var(--ac-text-muted);
    font-size: 11px;
    user-select: none;
    align-self: center;
  }

  .qp-status--error {
    border-color: color-mix(in srgb, var(--ac-danger) 55%, var(--ac-border));
    color: var(--ac-danger);
    background: color-mix(in srgb, var(--ac-danger) 12%, transparent);
  }

  .qp-status--success {
    border-color: color-mix(in srgb, var(--ac-success) 55%, var(--ac-border));
    color: color-mix(in srgb, var(--ac-success) 85%, var(--ac-text));
    background: color-mix(in srgb, var(--ac-success) 10%, transparent);
  }

  .qp-status--warning {
    border-color: color-mix(in srgb, var(--ac-warning) 55%, var(--ac-border));
    color: color-mix(in srgb, var(--ac-warning) 85%, var(--ac-text));
    background: color-mix(in srgb, var(--ac-warning) 10%, transparent);
  }

  /* Composer */
  .qp-composer {
    padding: 12px 14px;
    border-top: 1px solid var(--qp-divider);
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .qp-textarea {
    width: 100%;
    min-height: 42px;
    max-height: 160px;
    resize: none;
    padding: 10px 10px;
    border-radius: var(--ac-radius-card);
    border: 1px solid var(--qp-input-border);
    background: var(--qp-input-bg);
    color: var(--ac-text);
    font-family: var(--ac-font-body);
    font-size: 13px;
    line-height: 1.35;
    outline: none;
  }

  .qp-textarea::placeholder {
    color: var(--ac-text-placeholder);
  }

  .qp-actions {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
  }

  .qp-actions-left {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 11px;
    color: var(--ac-text-subtle);
    user-select: none;
  }

  .qp-actions-right {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .qp-kbd {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    border: var(--ac-border-width) solid var(--qp-divider);
    background: var(--ac-surface-muted);
    padding: 4px 8px;
    border-radius: 999px;
    font-family: var(--ac-font-code);
    font-size: 10px;
    color: var(--ac-text-muted);
  }

  /* Empty State */
  .qp-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 12px;
    padding: 40px 20px;
    text-align: center;
    color: var(--ac-text-muted);
  }

  .qp-empty-icon {
    font-size: 32px;
    opacity: 0.6;
  }

  .qp-empty-text {
    font-size: 13px;
    line-height: 1.5;
  }

  /* ============================================================
   * Search UI (Phase 1)
   * ============================================================ */

  /* Search Input Container */
  .qp-search {
    min-width: 0;
    width: 100%;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  /* Scope Chip */
  .qp-scope-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    border: 1px solid var(--qp-divider);
    background: rgba(255, 255, 255, 0.12);
    border-radius: 999px;
    padding: 6px 10px;
    color: var(--ac-text);
    font-family: var(--ac-font-body);
    font-size: 12px;
    cursor: pointer;
    user-select: none;
    flex: none;
    transition: background-color var(--ac-motion-fast);
  }

  .qp-scope-chip:hover {
    background: rgba(255, 255, 255, 0.18);
  }

  .qp-scope-chip__icon {
    font-size: 12px;
    line-height: 1;
  }

  .qp-scope-chip__label {
    font-weight: 600;
    letter-spacing: 0.2px;
    white-space: nowrap;
  }

  .qp-scope-chip__prefix {
    font-family: var(--ac-font-code);
    font-size: 10px;
    padding: 2px 6px;
    border-radius: 999px;
    border: 1px solid var(--qp-divider);
    background: rgba(255, 255, 255, 0.1);
    color: var(--ac-text-muted);
  }

  /* Search Input */
  .qp-search-input {
    flex: 1;
    min-width: 0;
    height: 38px;
    padding: 0 12px;
    border-radius: var(--ac-radius-card);
    border: 1px solid var(--qp-input-border);
    background: var(--qp-input-bg);
    color: var(--ac-text);
    font-family: var(--ac-font-body);
    font-size: 14px;
    line-height: 1.2;
    outline: none;
    transition: border-color var(--ac-motion-fast);
  }

  .qp-search-input:focus {
    border-color: var(--ac-accent);
  }

  .qp-search-input::placeholder {
    color: var(--ac-text-placeholder);
  }

  /* Icon Button (Clear, Close, Action, etc.) */
  .qp-icon-btn {
    width: 28px;
    height: 28px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: var(--ac-border-width) solid var(--qp-divider);
    background: transparent;
    color: var(--ac-text-muted);
    border-radius: var(--ac-radius-button);
    cursor: pointer;
    user-select: none;
    flex: none;
    transition: background-color var(--ac-motion-fast), color var(--ac-motion-fast), border-color var(--ac-motion-fast);
  }

  .qp-icon-btn:hover:not(:disabled) {
    background: var(--ac-hover-bg);
    color: var(--ac-text);
  }

  .qp-icon-btn:disabled {
    cursor: not-allowed;
    opacity: 0.5;
  }

  .qp-icon-btn svg {
    width: 16px;
    height: 16px;
  }

  /* Action button variant (send/stop) */
  .qp-icon-btn--action {
    width: 32px;
    height: 32px;
  }

  .qp-icon-btn--action svg {
    width: 16px;
    height: 16px;
  }

  .qp-icon-btn--primary {
    background: var(--ac-accent);
    border-color: var(--ac-accent);
    color: var(--ac-accent-contrast);
  }

  .qp-icon-btn--primary:hover:not(:disabled) {
    background: var(--ac-accent-hover);
    border-color: var(--ac-accent-hover);
    color: var(--ac-accent-contrast);
  }

  .qp-icon-btn--danger {
    background: var(--ac-danger);
    border-color: var(--ac-danger);
    color: #ffffff;
  }

  .qp-icon-btn--danger:hover:not(:disabled) {
    background: color-mix(in srgb, var(--ac-danger) 85%, #000);
    color: #ffffff;
  }

  /* Quick Entries Grid */
  .qp-entries {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 10px;
    padding: 10px 2px;
  }

  .qp-entry {
    border: var(--ac-border-width) solid var(--qp-divider);
    background: var(--ac-surface);
    border-radius: var(--ac-radius-card);
    padding: 14px 10px;
    cursor: pointer;
    user-select: none;
    color: var(--ac-text);
    font-family: var(--ac-font-body);
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    transition:
      background-color var(--ac-motion-fast),
      border-color var(--ac-motion-fast),
      box-shadow var(--ac-motion-fast);
  }

  .qp-entry:hover {
    background: var(--ac-hover-bg);
    box-shadow: var(--ac-shadow-card);
  }

  .qp-entry:active {
    box-shadow: none;
  }

  .qp-entry:disabled {
    cursor: not-allowed;
    opacity: 0.5;
  }

  .qp-entry[data-active='true'] {
    border-color: var(--ac-accent);
    background: var(--ac-accent-subtle);
  }

  .qp-entry__icon {
    width: 40px;
    height: 40px;
    border-radius: var(--ac-radius-inner);
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--ac-surface-muted);
    border: var(--ac-border-width) solid var(--qp-divider);
    font-size: 16px;
  }

  .qp-entry__label {
    font-weight: 600;
    font-size: 12px;
    letter-spacing: 0.2px;
  }

  .qp-entry__prefix {
    font-family: var(--ac-font-code);
    font-size: 10px;
    color: var(--ac-text-muted);
    border: var(--ac-border-width) solid var(--qp-divider);
    border-radius: 999px;
    padding: 2px 8px;
    background: var(--ac-surface-muted);
  }

  /* View Mount Points */
  .qp-header-mount,
  .qp-header-right-mount,
  .qp-content-mount,
  .qp-footer-mount {
    display: contents;
  }

  .qp-header-mount[hidden],
  .qp-header-right-mount[hidden],
  .qp-content-mount[hidden],
  .qp-footer-mount[hidden] {
    display: none;
  }

  /* Footer Hints */
  .qp-footer-hints {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px;
    padding: 8px 0;
    font-size: 11px;
    color: var(--ac-text-muted);
  }

  .qp-footer-hint {
    display: inline-flex;
    align-items: center;
    gap: 6px;
  }

  /* ============================================================
   * Markdown Content Styles (for markstream-vue)
   * ============================================================ */

  .qp-markdown-content {
    font-size: 13px;
    line-height: 1.5;
    color: var(--ac-text);
  }

  .qp-markdown-content pre {
    background-color: var(--ac-surface-muted);
    border: var(--ac-border-width) solid var(--ac-border);
    border-radius: var(--ac-radius-inner);
    padding: 12px;
    overflow-x: auto;
    margin: 0.5em 0;
  }

  .qp-markdown-content code {
    font-family: var(--ac-font-code);
    font-size: 0.875em;
    color: var(--ac-text);
  }

  .qp-markdown-content :not(pre) > code {
    background-color: var(--ac-surface-muted);
    padding: 0.125em 0.25em;
    border-radius: 4px;
  }

  .qp-markdown-content p {
    margin: 0.5em 0;
  }

  .qp-markdown-content p:first-child {
    margin-top: 0;
  }

  .qp-markdown-content p:last-child {
    margin-bottom: 0;
  }

  .qp-markdown-content ul,
  .qp-markdown-content ol {
    margin: 0.5em 0;
    padding-left: 1.5em;
  }

  .qp-markdown-content li {
    margin: 0.25em 0;
  }

  .qp-markdown-content h1,
  .qp-markdown-content h2,
  .qp-markdown-content h3,
  .qp-markdown-content h4,
  .qp-markdown-content h5,
  .qp-markdown-content h6 {
    margin: 0.75em 0 0.5em;
    font-weight: 600;
    line-height: 1.3;
  }

  .qp-markdown-content h1 { font-size: 1.5em; }
  .qp-markdown-content h2 { font-size: 1.3em; }
  .qp-markdown-content h3 { font-size: 1.15em; }
  .qp-markdown-content h4 { font-size: 1em; }

  .qp-markdown-content blockquote {
    border-left: 3px solid var(--ac-border-strong);
    padding-left: 1em;
    margin: 0.5em 0;
    color: var(--ac-text-muted);
  }

  .qp-markdown-content a {
    color: var(--ac-link);
    text-decoration: underline;
  }

  .qp-markdown-content a:hover {
    color: var(--ac-link-hover);
  }

  .qp-markdown-content table {
    border-collapse: collapse;
    margin: 0.5em 0;
    width: 100%;
    font-size: 0.9em;
  }

  .qp-markdown-content th,
  .qp-markdown-content td {
    border: var(--ac-border-width) solid var(--ac-border);
    padding: 0.5em;
    text-align: left;
  }

  .qp-markdown-content th {
    background-color: var(--ac-surface-muted);
    font-weight: 600;
  }

  .qp-markdown-content hr {
    border: none;
    border-top: var(--ac-border-width) solid var(--ac-border);
    margin: 1em 0;
  }

  .qp-markdown-content img {
    max-width: 100%;
    height: auto;
    border-radius: var(--ac-radius-inner);
  }

  .qp-markdown-content strong {
    font-weight: 600;
  }

  .qp-markdown-content em {
    font-style: italic;
  }
`,Me="__mcp_quick_panel_host__",Be="__mcp_quick_panel_ui__",De="__mcp_quick_panel_root__",Pe=2147483647,ce="agentTheme",z="warm-editorial",Ue="dark-console",Oe=new Set(["warm-editorial","blueprint-architect","zen-journal","neo-pop","dark-console","swiss-grid"]),Fe=new Set(["warm-editorial","blueprint-architect","zen-journal","neo-pop","swiss-grid"]),ze=["pointerdown","pointerup","pointermove","pointerenter","pointerleave","pointercancel","mousedown","mouseup","mousemove","mouseenter","mouseleave","click","dblclick","contextmenu","keydown","keyup","keypress","touchstart","touchmove","touchend","touchcancel","wheel","focus","blur","input","change"];function B(t,e,r){t.style.setProperty(e,r,"important")}function le(t){if(typeof t!="string")return z;const e=t.trim();return Oe.has(e)?e:z}function He(){var t,e;try{return(e=(t=globalThis.matchMedia)==null?void 0:t.call(globalThis,"(prefers-color-scheme: dark)").matches)!=null?e:!1}catch(r){return!1}}function ge(t){return He()&&Fe.has(t)?Ue:t}function he(){return M(this,null,function*(){var t;try{if(!((t=chrome==null?void 0:chrome.storage)!=null&&t.local))return z;const e=yield chrome.storage.local.get(ce);return le(e[ce])}catch(e){return z}})}function de(t,e){const r=le(e),n=ge(r);t.dataset.agentTheme=n}function Ge(t={}){var u,T,O,D,P,U;const e=new A;let r=null;const n=(u=t.hostId)!=null?u:Me,a=(T=t.zIndex)!=null?T:Pe,o=document.getElementById(n);if(o)try{o.remove()}catch(p){}const i=document.createElement("div");i.id=n,i.setAttribute("data-mcp-quick-panel","true"),B(i,"position","fixed"),B(i,"inset","0"),B(i,"z-index",String(a)),B(i,"pointer-events","none"),B(i,"contain","layout style paint"),B(i,"isolation","isolate");const m=i.attachShadow({mode:"open"}),l=document.createElement("style");l.textContent=W,m.append(l);const s=document.createElement("div");s.id=Be,B(s,"position","fixed"),B(s,"inset","0"),B(s,"pointer-events","none"),m.append(s);const f=document.createElement("div");f.id=De,f.className="agent-theme qp-root";const I=ge(z);f.dataset.agentTheme=I,s.append(f),((O=document.documentElement)!=null?O:document.body).append(i),e.add(()=>i.remove()),r={host:i,shadowRoot:m,uiRoot:s,root:f};const y=p=>{p.stopPropagation()};for(const p of ze)e.listen(f,p,y);M(null,null,function*(){const p=yield he();de(f,p)});let k=z;M(null,null,function*(){k=yield he()});const g=(p,q)=>{if(q!=="local")return;const F=p[ce];F&&(k=le(F.newValue),de(f,k))};try{(P=(D=chrome==null?void 0:chrome.storage)==null?void 0:D.onChanged)==null||P.addListener(g),e.add(()=>{var p,q;return(q=(p=chrome==null?void 0:chrome.storage)==null?void 0:p.onChanged)==null?void 0:q.removeListener(g)})}catch(p){}try{const p=(U=globalThis.matchMedia)==null?void 0:U.call(globalThis,"(prefers-color-scheme: dark)");if(p){const q=()=>{de(f,k)};typeof p.addEventListener=="function"&&(p.addEventListener("change",q),e.add(()=>p.removeEventListener("change",q)))}}catch(p){}const h=p=>{if(!(p instanceof Node))return!1;if(p===i)return!0;const q=typeof p.getRootNode=="function"?p.getRootNode():null;return q instanceof ShadowRoot&&q.host===i};return{getElements:()=>r,isOverlayElement:h,isEventFromUi:p=>{try{if(typeof p.composedPath=="function")return p.composedPath().some(q=>h(q))}catch(q){}return h(p.target)},dispose:()=>{r=null,e.dispose()}}}function $e(t){let e="";const r=document.createElement("div");return r.className="qp-markdown-content",t.appendChild(r),{setContent(n,a=!1){e=n,r.textContent=n},getContent(){return e},dispose(){try{r.remove()}catch(n){}}}}const be=10;function Qe(t){return typeof t=="string"&&t.trim().length>0}function We(...t){return t.filter(Boolean).join(" ")}function Ve(t){const e=new Date(t);if(Number.isNaN(e.getTime()))return"";try{return e.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}catch(r){return""}}function _e(t){return t.isStreaming===!0&&t.isFinal!==!0}function ve(t){return t==="user"?"qp-msg qp-msg--user":"qp-msg qp-msg--assistant"}function Ee(t){return We("qp-bubble",t==="user"&&"qp-bubble--user")}function je(t){const e=t.trim();return{short:e.length<=be?e:e.slice(0,be),full:e}}function Ke(t){return t.role==="tool"?"Tool":t.role==="system"?"System":t.messageType==="tool_use"?"Tool":t.messageType==="tool_result"?"Result":null}function Xe(){const t=document.createElement("div");Object.assign(t.style,{display:"inline-flex",alignItems:"center",gap:"6px",minWidth:"0"});const e=document.createElement("span");e.className="qp-msg-stream-dot ac-pulse",e.hidden=!0;const r=document.createElement("span");return t.append(e,r),{container:t,streamDot:e,time:r}}function Ye(){const t=document.createElement("span");t.hidden=!0;const e=document.createElement("code");return t.append(e),{container:t,requestId:e}}function xe(t,e){const r=document.createElement("div");r.className=ve(e.role),r.dataset.messageId=t,r.dataset.role=e.role,r.dataset.messageType=e.messageType;const n=document.createElement("div");n.className=Ee(e.role);const a=document.createElement("div");a.className="qp-msg-text";const o=document.createElement("div");o.className="qp-msg-meta";const i=Xe(),m=Ye();o.append(i.container,m.container),n.append(a,o),r.append(n);let l=null;return e.role==="assistant"&&(l=$e(a)),{wrapper:r,bubble:n,textEl:a,metaEl:o,metaLeftEl:i.container,streamDotEl:i.streamDot,timeEl:i.time,metaRightEl:m.container,requestIdEl:m.requestId,markdownRenderer:l}}function qe(t,e,r){var s;const n=ve(r.role);t.wrapper.className!==n&&(t.wrapper.className=n),t.wrapper.dataset.role=r.role,t.wrapper.dataset.messageType=r.messageType,t.wrapper.dataset.messageId=e;const a=Ee(r.role);t.bubble.className!==a&&(t.bubble.className=a);const o=(s=r.content)!=null?s:"";r.role==="assistant"&&t.markdownRenderer?t.markdownRenderer.setContent(o,_e(r)):t.textEl.textContent!==o&&(t.textEl.textContent=o);const i=Ke(r),m=Ve(r.createdAt)||"—";t.timeEl.textContent=i?`${i} • ${m}`:m,t.streamDotEl.hidden=!_e(r);const l=Qe(r.requestId)?r.requestId.trim():"";if(l){const f=je(l);t.requestIdEl.textContent=f.short,t.requestIdEl.title=f.full,t.metaRightEl.hidden=!1}else t.requestIdEl.textContent="",t.requestIdEl.title="",t.metaRightEl.hidden=!0}function Je(t){var k;const e=t.container,r=(k=t.scrollContainer)!=null?k:null,n=t.autoScrollThresholdPx,a=new Map;let o=!1;function i(){if(!r)return!0;const{scrollHeight:g,scrollTop:h,clientHeight:b}=r;return g-h-b<=n}function m(){if(r)try{r.scrollTo({top:r.scrollHeight})}catch(g){r.scrollTop=r.scrollHeight}}function l(g){var T;if(o)return;const h=(T=g.id)==null?void 0:T.trim();if(!h)return;const b=i();let u=a.get(h);u||(u=xe(h,g),a.set(h,u),e.append(u.wrapper)),qe(u,h,g),b&&m()}function s(g){var u;if(o)return;const h=g==null?void 0:g.trim();if(!h)return;const b=a.get(h);if(b){a.delete(h),b.markdownRenderer&&b.markdownRenderer.dispose();try{b.wrapper.remove()}catch(T){(u=b.wrapper.parentElement)==null||u.removeChild(b.wrapper)}}}function f(){if(!o){for(const g of a.values())g.markdownRenderer&&g.markdownRenderer.dispose();a.clear(),e.textContent=""}}function I(g){var h;if(!o){for(const b of a.values())b.markdownRenderer&&b.markdownRenderer.dispose();a.clear(),e.textContent="";for(const b of g){const u=(h=b.id)==null?void 0:h.trim();if(!u)continue;const T=xe(u,b);a.set(u,T),qe(T,u,b),e.append(T.wrapper)}m()}}function w(){return a.size}function y(){if(!o){o=!0;for(const g of a.values())g.markdownRenderer&&g.markdownRenderer.dispose();a.clear(),e.textContent=""}}return{upsert:l,remove:s,clear:f,setMessages:I,getMessageCount:w,scrollToBottom:m,dispose:y}}const H="[QuickPanelAiChatPanel]",Ze="Agent",we="Quick Panel",et="Ask the agent...",tt=3e3,Z=600,rt=42,nt=160,Te=2400,at='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg>',ye='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>',ot='<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="1"/></svg>';function Re(t){return typeof t=="string"&&t.trim().length>0}function V(t,e){const r=t.trim();return r.length<=e?r:`${r.slice(0,Math.max(0,e-1)).trimEnd()}…`}function st(t){try{t.focus()}catch(e){}}function it(t){return t==="completed"||t==="error"||t==="cancelled"}function ct(){var e,r,n,a;const t={pageUrl:(e=globalThis.location)==null?void 0:e.href};try{const o=(r=globalThis.getSelection)==null?void 0:r.call(globalThis),i=(a=(n=o==null?void 0:o.toString())==null?void 0:n.trim())!=null?a:"";i&&(t.selectedText=V(i,tt))}catch(o){}return t}function lt(t,e,r){return{id:`local-user:${e}`,sessionId:t,role:"user",content:r,messageType:"chat",requestId:e,isStreaming:!1,isFinal:!0,createdAt:new Date().toISOString()}}function ke(t){if(!t)return null;const e=[],r=Number.isFinite(t.inputTokens)?t.inputTokens:0,n=Number.isFinite(t.outputTokens)?t.outputTokens:0;if(e.push(`in ${r}`,`out ${n}`),Number.isFinite(t.durationMs)&&t.durationMs>0){const a=Math.max(1,Math.round(t.durationMs/1e3));e.push(`${a}s`)}return Number.isFinite(t.totalCostUsd)&&t.totalCostUsd>0&&e.push(`$${t.totalCostUsd.toFixed(4)}`),e.join(" • ")}function dt(t){var X,c,d;const e=((X=t.title)==null?void 0:X.trim())||Ze,r=((c=t.subtitle)==null?void 0:c.trim())||we,n=((d=t.placeholder)==null?void 0:d.trim())||et,a=document.createElement("div");a.className="qp-overlay",a.setAttribute("data-mcp-quick-panel-ai-chat","true");const o=document.createElement("div");o.className="qp-panel",o.setAttribute("role","dialog"),o.setAttribute("aria-modal","true"),o.setAttribute("aria-label",e);const i=document.createElement("div");i.className="qp-header";const m=document.createElement("div");m.className="qp-header-left";const l=document.createElement("div");l.className="qp-brand",l.textContent="✦";const s=document.createElement("div");s.className="qp-title";const f=document.createElement("div");f.className="qp-title-name",f.textContent=e;const I=document.createElement("div");I.className="qp-title-sub",I.textContent=r,s.append(f,I),m.append(l,s);const w=document.createElement("div");w.className="qp-header-right";const y=document.createElement("div");y.className="qp-stream-indicator",y.hidden=!0;const k=document.createElement("span");k.className="qp-stream-dot ac-pulse";const g=document.createElement("span");g.textContent="Streaming",y.append(k,g);const h=document.createElement("button");h.type="button",h.className="qp-icon-btn ac-focus-ring",h.innerHTML=at,h.setAttribute("aria-label","Close Quick Panel"),w.append(y,h),i.append(m,w);const b=document.createElement("div");b.className="qp-content ac-scroll";const u=document.createElement("div");u.className="qp-empty";const T=document.createElement("div");T.className="qp-empty-icon",T.textContent="✦";const O=document.createElement("div");O.className="qp-empty-text",O.textContent="Ask about this page. Streaming replies appear here.",u.append(T,O);const D=document.createElement("div");D.className="qp-messages",b.append(u,D);const P=document.createElement("div");P.className="qp-composer";const U=document.createElement("div");U.className="qp-status",U.hidden=!0;const p=document.createElement("textarea");p.className="qp-textarea ac-focus-ring",p.placeholder=n,p.rows=1;const q=document.createElement("div");q.className="qp-actions";const F=document.createElement("div");F.className="qp-actions-left";const G=[{key:"Enter",label:"Send"},{key:"Shift+Enter",label:"New line"},{key:"Esc",label:"Close"}];for(const E of G){const C=document.createElement("span");C.className="qp-kbd",C.textContent=E.key;const N=document.createElement("span");N.textContent=E.label,F.append(C,N)}const $=document.createElement("div");$.className="qp-actions-right";const L=document.createElement("button");return L.type="button",L.className="qp-icon-btn qp-icon-btn--action qp-icon-btn--primary ac-focus-ring",L.innerHTML=ye,L.setAttribute("aria-label","Send message"),L.dataset.action="send",$.append(L),q.append(F,$),P.append(U,p,q),o.append(i,b,P),a.append(o),{overlay:a,panel:o,titleSubEl:I,streamIndicator:y,streamText:g,closeBtn:h,contentEl:b,emptyEl:u,messagesEl:D,banner:U,textarea:p,actionBtn:L}}function ut(t){var L,X;const e=new A,r=t.mount,n=t.agentBridge,a=((L=t.subtitle)==null?void 0:L.trim())||we;try{const c=(X=r.querySelector)==null?void 0:X.call(r,'[data-mcp-quick-panel-ai-chat="true"]');c instanceof HTMLElement&&c.remove()}catch(c){}let o=!1,i=null,m=null,l={sending:!1,streaming:!1,cancelling:!1,currentRequestId:null,sessionId:null,lastStatus:null,lastUsage:null,errorMessage:null};const s=dt(t);r.append(s.overlay),e.add(()=>s.overlay.remove());const f=Je({container:s.messagesEl,scrollContainer:s.contentEl,autoScrollThresholdPx:96});e.add(()=>f.dispose());function I(){m&&(clearTimeout(m),m=null)}function w(){I(),s.banner.hidden=!0,s.banner.className="qp-status",s.banner.textContent=""}function y(c,d,E){I(),s.banner.hidden=!1,s.banner.className="qp-status",c==="error"&&s.banner.classList.add("qp-status--error"),c==="success"&&s.banner.classList.add("qp-status--success"),c==="warning"&&s.banner.classList.add("qp-status--warning"),s.banner.textContent=d,E&&E>0&&(m=setTimeout(w,E))}function k(){try{s.textarea.style.height="auto";const c=Math.min(nt,Math.max(rt,s.textarea.scrollHeight));s.textarea.style.height=`${c}px`}catch(c){}}function g(){const c=f.getMessageCount()>0;s.emptyEl.hidden=c,s.messagesEl.hidden=!c}function h(){if(l.errorMessage){s.titleSubEl.textContent="Error";return}if(l.streaming){s.titleSubEl.textContent="Streaming…";return}if(l.sending){s.titleSubEl.textContent="Sending…";return}const c=ke(l.lastUsage);s.titleSubEl.textContent=c?`Last: ${c}`:a}function b(){const c=s.textarea.value.trim(),d=l.sending||l.streaming||l.cancelling,E=c.length>0&&!d,C=l.currentRequestId!==null&&!l.cancelling;d?(s.actionBtn.innerHTML=ot,s.actionBtn.setAttribute("aria-label","Stop request"),s.actionBtn.dataset.action="stop",s.actionBtn.disabled=!C,s.actionBtn.classList.remove("qp-icon-btn--primary"),s.actionBtn.classList.add("qp-icon-btn--danger")):(s.actionBtn.innerHTML=ye,s.actionBtn.setAttribute("aria-label","Send message"),s.actionBtn.dataset.action="send",s.actionBtn.disabled=!E,s.actionBtn.classList.remove("qp-icon-btn--danger"),s.actionBtn.classList.add("qp-icon-btn--primary")),s.streamIndicator.hidden=!d,l.cancelling?s.streamText.textContent="Cancelling":l.sending?s.streamText.textContent="Sending":s.streamText.textContent="Streaming",s.textarea.disabled=l.sending||l.cancelling,h(),g()}function u(c){l=Y(Y({},l),c),b()}function T(){if(i){try{i()}catch(c){}i=null}}function O(){return M(this,null,function*(){try{if(t.getContext){const d=yield t.getContext();if(d&&typeof d=="object")return d}}catch(d){console.warn(`${H} getContext failed:`,d)}const c=ct();if(!(!Re(c.pageUrl)&&!Re(c.selectedText)))return c})}function D(){return M(this,null,function*(){if(o||l.sending||l.streaming||l.cancelling)return;const c=s.textarea.value.trim();if(!c)return;u({errorMessage:null,lastUsage:null,lastStatus:null}),w();const d=s.textarea.value;s.textarea.value="",k(),u({sending:!0});const E=yield O();if(o)return;const C={instruction:c,context:E!=null?E:void 0},N=yield n.sendToAI(C);if(!o){if(!N.success){s.textarea.value=d,k();const ae=V(N.error,Z);u({sending:!1,errorMessage:ae}),y("error",ae);return}f.upsert(lt(N.sessionId,N.requestId,c)),f.scrollToBottom(),u({sending:!1,streaming:!0,currentRequestId:N.requestId,sessionId:N.sessionId,lastStatus:"starting"}),T(),i=n.onRequestEvent(N.requestId,ae=>{o||p(ae)})}})}function P(){return M(this,null,function*(){if(o||!l.currentRequestId||l.cancelling)return;const c=l.currentRequestId,d=l.sessionId||void 0;u({cancelling:!0});const E=yield n.cancelRequest(c,d);if(!o){if(!E.success){const C=V(E.error,Z);u({cancelling:!1,errorMessage:C}),y("error",C);return}u({cancelling:!1})}})}function U(c,d){if(T(),u({streaming:!1,sending:!1,cancelling:!1,currentRequestId:null,sessionId:null,lastStatus:c}),c==="completed"){const E=ke(l.lastUsage),C=E?`Completed • ${E}`:"Completed";y("success",C,Te);return}if(c==="cancelled"){y("warning","Cancelled",Te);return}if(c==="error"){const E=V(d||l.errorMessage||"Request failed",Z);u({errorMessage:E}),y("error",E)}}function p(c){if(!o){if(!c||typeof c!="object"||!("type"in c)){console.warn(`${H} Invalid event structure:`,c);return}try{switch(c.type){case"message":{const d=c.data;if(!d||typeof d!="object"||typeof d.id!="string"){console.warn(`${H} Invalid message data:`,d);return}if(d.role==="user"){const E=`local-user:${d.requestId}`;f.remove(E)}f.upsert(d),d.isStreaming===!0&&!d.isFinal&&u({streaming:!0});return}case"status":{const d=c.data;if(!d||typeof d!="object"||typeof d.status!="string"){console.warn(`${H} Invalid status data:`,d);return}if(u({lastStatus:d.status}),d.status==="starting"||d.status==="ready"||d.status==="running"){u({streaming:!0});return}it(d.status)&&U(d.status,d.message);return}case"usage":{u({lastUsage:c.data});return}case"error":{const d=V(c.error||"Unknown error",Z);u({errorMessage:d}),y("error",d),T(),u({streaming:!1,sending:!1,cancelling:!1,currentRequestId:null,sessionId:null,lastStatus:"error"});return}case"connected":case"heartbeat":return}}catch(d){console.warn(`${H} Error handling event:`,d,c)}}}e.listen(s.overlay,"click",c=>{o||c.target===s.overlay&&G()}),e.listen(s.closeBtn,"click",()=>G()),e.listen(s.actionBtn,"click",()=>{if(o)return;s.actionBtn.dataset.action==="stop"?P():D()}),e.listen(s.textarea,"input",()=>{o||(k(),b())}),e.listen(s.textarea,"keydown",c=>{if(!o){if(c.key==="Escape"&&!c.isComposing){c.preventDefault(),G();return}c.key==="Enter"&&!c.shiftKey&&!c.isComposing&&(c.preventDefault(),D())}});function q(){o||st(s.textarea)}function F(){o||(f.clear(),w(),u({lastUsage:null,lastStatus:null,errorMessage:null}))}function G(){var c;if(!o){l.currentRequestId&&P();try{(c=t.onRequestClose)==null||c.call(t)}catch(d){console.warn(`${H} onRequestClose failed:`,d)}$()}}function $(){o||(o=!0,T(),I(),e.dispose())}return k(),b(),t.autoFocus!==!1&&q(),{getState:()=>Y({},l),focusInput:q,clearMessages:F,close:G,dispose:$}}const j="[QuickPanelController]";function pt(t={}){let e=!1,r=null,n=null,a=null;function o(){return(!r||r.isDisposed())&&(r=Q()),r}function i(){if(a){try{a.dispose()}catch(w){console.warn(`${j} Error disposing chat panel:`,w)}a=null}if(n){try{n.dispose()}catch(w){console.warn(`${j} Error disposing shadow host:`,w)}n=null}}function m(){if(e){console.warn(`${j} Cannot show - controller is disposed`);return}if(a&&(n!=null&&n.getElements())){a.focusInput();return}i(),n=Ge({hostId:t.hostId,zIndex:t.zIndex});const w=n.getElements();if(!w){console.error(`${j} Failed to create shadow host elements`),i();return}const y=o();a=ut({mount:w.root,agentBridge:y,title:t.title,subtitle:t.subtitle,placeholder:t.placeholder,autoFocus:!0,onRequestClose:()=>l()})}function l(){e||i()}function s(){e||(f()?l():m())}function f(){return a!==null&&(n==null?void 0:n.getElements())!==null}function I(){if(!e&&(e=!0,i(),r)){try{r.dispose()}catch(w){console.warn(`${j} Error disposing agent bridge:`,w)}r=null}}return{show:m,hide:l,toggle:s,isVisible:f,dispose:I}}const mt={matches:["<all_urls>"],runAt:"document_idle",main(){console.log("[QuickPanelContentScript] Content script loaded on:",window.location.href);let t=null;function e(){return t||(t=pt({title:"Agent",subtitle:"Quick Panel",placeholder:"Ask about this page..."})),t}function r(n,a,o){var m;const i=n;if((i==null?void 0:i.action)==="toggle_quick_panel"){console.log("[QuickPanelContentScript] Received toggle_quick_panel message");try{const l=e();l.toggle();const s=l.isVisible();console.log("[QuickPanelContentScript] Toggle completed, visible:",s),o({success:!0,visible:s})}catch(l){console.error("[QuickPanelContentScript] Toggle error:",l),o({success:!1,error:String(l)})}return!0}if((i==null?void 0:i.action)==="show_quick_panel"){try{e().show(),o({success:!0})}catch(l){console.error("[QuickPanelContentScript] Show error:",l),o({success:!1,error:String(l)})}return!0}if((i==null?void 0:i.action)==="hide_quick_panel"){try{t&&t.hide(),o({success:!0})}catch(l){console.error("[QuickPanelContentScript] Hide error:",l),o({success:!1,error:String(l)})}return!0}return(i==null?void 0:i.action)==="get_quick_panel_status"?(o({success:!0,visible:(m=t==null?void 0:t.isVisible())!=null?m:!1,initialized:t!==null}),!0):!1}chrome.runtime.onMessage.addListener(r),window.addEventListener("unload",()=>{chrome.runtime.onMessage.removeListener(r),t&&(t.dispose(),t=null)})}},ee=(Ie=(Se=globalThis.browser)==null?void 0:Se.runtime)!=null&&Ie.id?globalThis.browser:globalThis.chrome;function te(t,...e){}const ft={debug:(...t)=>te(console.debug,...t),log:(...t)=>te(console.log,...t),warn:(...t)=>te(console.warn,...t),error:(...t)=>te(console.error,...t)},ne=class ne extends Event{constructor(e,r){super(ne.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=r}};S(ne,"EVENT_NAME",pe("wxt:locationchange"));let ue=ne;function pe(t){var e;return`${(e=ee==null?void 0:ee.runtime)==null?void 0:e.id}:quick-panel:${t}`}function gt(t){let e,r;return{run(){e==null&&(r=new URL(location.href),e=t.setInterval(()=>{let n=new URL(location.href);n.href!==r.href&&(window.dispatchEvent(new ue(n,r)),r=n)},1e3))}}}const K=class K{constructor(e,r){S(this,"isTopFrame",window.self===window.top);S(this,"abortController");S(this,"locationWatcher",gt(this));S(this,"receivedMessageIds",new Set);this.contentScriptName=e,this.options=r,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return ee.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,r){const n=setInterval(()=>{this.isValid&&e()},r);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,r){const n=setTimeout(()=>{this.isValid&&e()},r);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){const r=requestAnimationFrame((...n)=>{this.isValid&&e(...n)});return this.onInvalidated(()=>cancelAnimationFrame(r)),r}requestIdleCallback(e,r){const n=requestIdleCallback((...a)=>{this.signal.aborted||e(...a)},r);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,r,n,a){var o;r==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(o=e.addEventListener)==null||o.call(e,r.startsWith("wxt:")?pe(r):r,n,Le(Y({},a),{signal:this.signal}))}notifyInvalidated(){this.abort("Content script context invalidated"),ft.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:K.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(e){var o,i,m;const r=((o=e.data)==null?void 0:o.type)===K.SCRIPT_STARTED_MESSAGE_TYPE,n=((i=e.data)==null?void 0:i.contentScriptName)===this.contentScriptName,a=!this.receivedMessageIds.has((m=e.data)==null?void 0:m.messageId);return r&&n&&a}listenForNewerScripts(e){let r=!0;const n=a=>{if(this.verifyScriptStartedEvent(a)){this.receivedMessageIds.add(a.data.messageId);const o=r;if(r=!1,o&&(e!=null&&e.ignoreFirstEvent))return;this.notifyInvalidated()}};addEventListener("message",n),this.onInvalidated(()=>removeEventListener("message",n))}};S(K,"SCRIPT_STARTED_MESSAGE_TYPE",pe("wxt:content-script-started"));let me=K;function xt(){}function re(t,...e){}const ht={debug:(...t)=>re(console.debug,...t),log:(...t)=>re(console.log,...t),warn:(...t)=>re(console.warn,...t),error:(...t)=>re(console.error,...t)};return M(null,null,function*(){try{const t=mt,{main:e}=t,r=Ne(t,["main"]),n=new me("quick-panel",r);return yield e(n)}catch(e){throw ht.error('The content script "quick-panel" crashed on startup!',e),e}})})();
quickPanel;