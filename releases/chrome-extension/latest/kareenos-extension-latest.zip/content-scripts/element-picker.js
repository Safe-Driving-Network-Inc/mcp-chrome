var elementPicker=(function(){"use strict";var Ge=Object.defineProperty,Ye=Object.defineProperties;var Qe=Object.getOwnPropertyDescriptors;var re=Object.getOwnPropertySymbols;var Se=Object.prototype.hasOwnProperty,Te=Object.prototype.propertyIsEnumerable;var ge=(v,u,g)=>u in v?Ge(v,u,{enumerable:!0,configurable:!0,writable:!0,value:g}):v[u]=g,ne=(v,u)=>{for(var g in u||(u={}))Se.call(u,g)&&ge(v,g,u[g]);if(re)for(var g of re(u))Te.call(u,g)&&ge(v,g,u[g]);return v},be=(v,u)=>Ye(v,Qe(u));var Ne=(v,u)=>{var g={};for(var C in v)Se.call(v,C)&&u.indexOf(C)<0&&(g[C]=v[C]);if(v!=null&&re)for(var C of re(v))u.indexOf(C)<0&&Te.call(v,C)&&(g[C]=v[C]);return g};var L=(v,u,g)=>ge(v,typeof u!="symbol"?u+"":u,g);var O=(v,u,g)=>new Promise((C,V)=>{var ae=_=>{try{A(g.next(_))}catch(D){V(D)}},oe=_=>{try{A(g.throw(_))}catch(D){V(D)}},A=_=>_.done?C(_.value):Promise.resolve(_.value).then(ae,oe);A((g=g.apply(v,u)).next())});var we,Ee;function v(t){return t}class u{constructor(){L(this,"disposed",!1);L(this,"disposers",[])}get isDisposed(){return this.disposed}add(e){if(this.disposed){try{e()}catch(r){}return}this.disposers.push(e)}listen(e,r,n,c){e.addEventListener(r,n,c),this.add(()=>e.removeEventListener(r,n,c))}observeResize(e,r,n){const c=new ResizeObserver(r);return c.observe(e,n),this.add(()=>c.disconnect()),c}observeMutation(e,r,n){const c=new MutationObserver(r);return c.observe(e,n),this.add(()=>c.disconnect()),c}requestAnimationFrame(e){const r=requestAnimationFrame(e);let n=!1;const c=()=>{n||(n=!0,cancelAnimationFrame(r))};return this.add(c),c}dispose(){if(!this.disposed){this.disposed=!0;for(let e=this.disposers.length-1;e>=0;e--)try{this.disposers[e]()}catch(r){}this.disposers.length=0}}}const g=`
  /* ============================================================
   * Reset & Box Sizing
   * ============================================================ */

  :host {
    all: initial;
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }

  [hidden] {
    display: none !important;
  }

  /* ============================================================
   * Root Container & Theme Tokens
   * Subset of AgentChat tokens for Quick Panel use
   * ============================================================ */

  .qp-root {
    position: fixed;
    inset: 0;
    pointer-events: none;
    font-family: var(--ac-font-body, ui-sans-serif, system-ui);
    color: var(--ac-text, #111827);
    line-height: 1.4;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  .qp-root.agent-theme {
    /* ===========================================
     * Font Stacks
     * =========================================== */
    --ac-font-sans:
      'Inter', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial,
      'Apple Color Emoji', 'Segoe UI Emoji';
    --ac-font-serif: 'Newsreader', ui-serif, Georgia, Cambria, 'Times New Roman', Times, serif;
    --ac-font-mono:
      'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono',
      'Courier New', monospace;
    --ac-font-grotesk:
      'Space Grotesk', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial;

    --ac-font-body: var(--ac-font-sans);
    --ac-font-heading: var(--ac-font-serif);
    --ac-font-code: var(--ac-font-mono);

    /* ===========================================
     * Geometry & Spacing
     * =========================================== */
    --ac-border-width: 1px;
    --ac-border-width-strong: 2px;
    --ac-radius-container: 0px;
    --ac-radius-card: 12px;
    --ac-radius-inner: 8px;
    --ac-radius-button: 8px;

    /* ===========================================
     * Motion
     * =========================================== */
    --ac-motion-fast: 120ms;
    --ac-motion-normal: 180ms;

    /* ===========================================
     * Warm Editorial Theme (Default)
     * =========================================== */
    --ac-bg: transparent;
    --ac-bg-pattern: none;
    --ac-bg-pattern-size: 16px 16px;

    --ac-header-bg: rgba(253, 252, 248, 0.95);
    --ac-header-border: rgba(245, 245, 244, 0.5);

    --ac-surface: #ffffff;
    --ac-surface-muted: #f2f0eb;
    --ac-surface-inset: #f2f0eb;

    --ac-text: #1a1a1a;
    --ac-text-muted: #6e6e6e;
    --ac-text-subtle: #a8a29e;
    --ac-text-inverse: #ffffff;
    --ac-text-placeholder: #a8a29e;

    --ac-border: #e7e5e4;
    --ac-border-strong: #d6d3d1;

    --ac-hover-bg: #f5f5f4;
    --ac-hover-bg-subtle: #fafaf9;

    --ac-accent: #d97757;
    --ac-accent-hover: #c4664a;
    --ac-accent-subtle: rgba(217, 119, 87, 0.12);
    --ac-accent-contrast: #ffffff;

    --ac-link: var(--ac-accent);
    --ac-link-hover: var(--ac-accent-hover);

    --ac-selection-bg: #ffedd5;
    --ac-selection-text: #7c2d12;

    --ac-shadow-card: 0 1px 3px rgba(0, 0, 0, 0.08);
    --ac-shadow-float: 0 4px 20px -2px rgba(0, 0, 0, 0.05);

    --ac-focus-ring: rgba(214, 211, 209, 0.9);

    --ac-timeline-node-pulse-shadow:
      0 0 0 2px rgba(217, 119, 87, 0.25), 0 0 12px rgba(217, 119, 87, 0.2);

    /* Status Colors */
    --ac-success: #22c55e;
    --ac-warning: #f59e0b;
    --ac-danger: #ef4444;

    /* Scrollbar */
    --ac-scrollbar-size: 4px;
    --ac-scrollbar-thumb: rgba(0, 0, 0, 0.25);
    --ac-scrollbar-thumb-hover: rgba(0, 0, 0, 0.4);

    /* ===========================================
     * Quick Panel Solid Tokens (Editorial Style)
     * No glassmorphism - solid backgrounds for clarity
     * =========================================== */
    --qp-panel-bg: var(--ac-surface);
    --qp-panel-border: var(--ac-border);
    --qp-panel-shadow: var(--ac-shadow-card), 0 25px 50px -12px rgba(0, 0, 0, 0.15);
    --qp-divider: var(--ac-border);
    --qp-input-bg: var(--ac-surface);
    --qp-input-border: var(--ac-border);
  }

  /* ===========================================
   * Dark Console Theme
   * =========================================== */
  .qp-root.agent-theme[data-agent-theme='dark-console'] {
    --ac-font-body: var(--ac-font-mono);
    --ac-font-heading: var(--ac-font-mono);
    --ac-font-code: var(--ac-font-mono);

    --ac-surface: #0f1117;
    --ac-surface-muted: #0a0c10;
    --ac-surface-inset: #1a1d26;

    --ac-text: #e5e7eb;
    --ac-text-muted: #9ca3af;
    --ac-text-subtle: #6b7280;
    --ac-text-inverse: #0a0c10;
    --ac-text-placeholder: #4b5563;

    --ac-border: #1f2937;
    --ac-border-strong: #374151;

    --ac-hover-bg: rgba(255, 255, 255, 0.06);
    --ac-hover-bg-subtle: rgba(255, 255, 255, 0.04);

    --ac-accent: #d97757;
    --ac-accent-hover: #e8956f;
    --ac-accent-subtle: rgba(217, 119, 87, 0.18);
    --ac-accent-contrast: #ffffff;

    --ac-focus-ring: rgba(217, 119, 87, 0.4);
    --ac-timeline-node-pulse-shadow:
      0 0 0 2px rgba(217, 119, 87, 0.35), 0 0 14px rgba(217, 119, 87, 0.25);

    --ac-scrollbar-thumb: rgba(255, 255, 255, 0.12);
    --ac-scrollbar-thumb-hover: rgba(255, 255, 255, 0.22);

    --qp-panel-bg: var(--ac-surface);
    --qp-panel-border: var(--ac-border);
    --qp-panel-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4);
    --qp-divider: var(--ac-border);
    --qp-input-bg: var(--ac-surface-inset);
    --qp-input-border: var(--ac-border);
  }

  .qp-root ::selection {
    background: var(--ac-selection-bg);
    color: var(--ac-selection-text);
  }

  /* ============================================================
   * Utility Classes (AgentChat Subset)
   * ============================================================ */

  /* Scrollbar Styling */
  .qp-root .ac-scroll {
    scrollbar-width: thin;
    scrollbar-color: var(--ac-scrollbar-thumb) transparent;
  }

  .qp-root .ac-scroll::-webkit-scrollbar {
    width: var(--ac-scrollbar-size);
    height: var(--ac-scrollbar-size);
  }

  .qp-root .ac-scroll::-webkit-scrollbar-track {
    background: transparent;
  }

  .qp-root .ac-scroll::-webkit-scrollbar-thumb {
    background-color: var(--ac-scrollbar-thumb);
    border-radius: 999px;
  }

  .qp-root .ac-scroll::-webkit-scrollbar-thumb:hover {
    background-color: var(--ac-scrollbar-thumb-hover);
  }

  /* Focus Ring */
  .qp-root .ac-focus-ring:focus-visible {
    outline: none;
    box-shadow: 0 0 0 2px var(--ac-focus-ring);
  }

  /* Button Base */
  .qp-root .ac-btn {
    transition:
      background-color var(--ac-motion-fast),
      color var(--ac-motion-fast);
  }

  .qp-root .ac-btn:hover {
    background-color: var(--ac-hover-bg);
  }

  /* Pulse Animation (Streaming Indicator) */
  @keyframes ac-pulse {
    0%, 100% {
      opacity: 1;
    }
    50% {
      opacity: 0.5;
    }
  }

  .qp-root .ac-pulse {
    animation: ac-pulse 1.5s cubic-bezier(0.4, 0, 0.6, 1) infinite;
  }

  @media (prefers-reduced-motion: reduce) {
    .qp-root .ac-pulse {
      animation: none;
    }
  }

  /* Text Shimmer (Streaming Status) */
  .qp-root .text-shimmer {
    background: linear-gradient(
      90deg,
      var(--ac-accent, #d97757) 0%,
      var(--ac-accent-hover, #ffcab0) 50%,
      var(--ac-accent, #d97757) 100%
    );
    background-size: 200% auto;
    color: transparent;
    -webkit-background-clip: text;
    background-clip: text;
    animation: ac-shimmer 3s linear infinite;
  }

  @keyframes ac-shimmer {
    to {
      background-position: 200% center;
    }
  }

  /* ============================================================
   * Liquid Glass Panel (PRD V6)
   * ============================================================ */

  .qp-overlay {
    position: fixed;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 24px;
    pointer-events: auto;
  }

  .qp-panel {
    width: min(760px, calc(100vw - 48px));
    max-height: min(720px, calc(100vh - 48px));
    display: flex;
    flex-direction: column;
    border-radius: 24px;
    overflow: hidden;
    pointer-events: auto;

    background: var(--qp-panel-bg);
    border: var(--ac-border-width) solid var(--qp-panel-border);
    box-shadow: var(--qp-panel-shadow);
  }

  /* ============================================================
   * AI Chat Layout Components
   * ============================================================ */

  /* Header */
  .qp-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 14px 16px;
    border-bottom: var(--ac-border-width) solid var(--qp-divider);
  }

  .qp-header-left {
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .qp-brand {
    width: 34px;
    height: 34px;
    border-radius: var(--ac-radius-inner);
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--ac-accent-subtle);
    color: var(--ac-accent);
    font-size: 24px;
  }

  .qp-title {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }

  .qp-title-name {
    font-weight: 700;
    font-size: 13px;
    letter-spacing: 0.2px;
    color: var(--ac-text);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .qp-title-sub {
    font-size: 11px;
    color: var(--ac-text-muted);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .qp-header-right {
    display: flex;
    align-items: center;
    gap: 10px;
    flex: none;
  }

  .qp-stream-indicator {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    color: var(--ac-text-muted);
    user-select: none;
  }

  .qp-stream-dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: var(--ac-accent);
    box-shadow: var(--ac-timeline-node-pulse-shadow);
  }

  /* Buttons */
  .qp-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    border: var(--ac-border-width) solid var(--qp-divider);
    background: var(--ac-hover-bg);
    color: var(--ac-text);
    border-radius: var(--ac-radius-button);
    padding: 8px 10px;
    font-size: 11px;
    cursor: pointer;
    user-select: none;
    font-family: inherit;
    transition: background-color var(--ac-motion-fast);
  }

  .qp-btn:hover:not(:disabled) {
    background: var(--ac-hover-bg-subtle);
  }

  .qp-btn:disabled {
    cursor: not-allowed;
    opacity: 0.6;
  }

  .qp-btn--primary {
    background: var(--ac-accent);
    border-color: var(--ac-accent);
    color: var(--ac-accent-contrast);
  }

  .qp-btn--primary:hover:not(:disabled) {
    background: var(--ac-accent-hover);
  }

  .qp-btn--danger {
    background: var(--ac-danger);
    border-color: var(--ac-danger);
    color: #ffffff;
  }

  /* Content Area */
  .qp-content {
    flex: 1;
    overflow: auto;
    padding: 14px;
    min-height: 0;
  }

  .qp-messages {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  /* Message Bubbles */
  .qp-msg {
    display: flex;
    gap: 10px;
  }

  .qp-msg--user {
    justify-content: flex-end;
  }

  .qp-msg--assistant {
    justify-content: flex-start;
  }

  .qp-bubble {
    max-width: 90%;
    border-radius: var(--ac-radius-card);
    border: var(--ac-border-width) solid var(--ac-border);
    box-shadow: var(--ac-shadow-card);
    padding: 10px 12px;
    background: var(--ac-surface);
  }

  .qp-bubble--user {
    background: color-mix(in srgb, var(--ac-accent-subtle) 80%, transparent);
    border-color: color-mix(in srgb, var(--ac-border) 70%, transparent);
  }

  .qp-msg-text {
    font-size: 13px;
    white-space: pre-wrap;
    word-break: break-word;
    color: var(--ac-text);
  }

  .qp-msg-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-top: 6px;
    font-size: 10px;
    color: var(--ac-text-subtle);
  }

  .qp-msg-meta code {
    font-family: var(--ac-font-code);
    font-size: 10px;
  }

  .qp-msg-stream-dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: var(--ac-accent);
    box-shadow: var(--ac-timeline-node-pulse-shadow);
    flex: none;
  }

  /* Status Indicators */
  .qp-status {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 8px 10px;
    border-radius: 999px;
    border: var(--ac-border-width) solid var(--ac-border);
    background: var(--ac-surface-muted);
    color: var(--ac-text-muted);
    font-size: 11px;
    user-select: none;
    align-self: center;
  }

  .qp-status--error {
    border-color: color-mix(in srgb, var(--ac-danger) 55%, var(--ac-border));
    color: var(--ac-danger);
    background: color-mix(in srgb, var(--ac-danger) 12%, transparent);
  }

  .qp-status--success {
    border-color: color-mix(in srgb, var(--ac-success) 55%, var(--ac-border));
    color: color-mix(in srgb, var(--ac-success) 85%, var(--ac-text));
    background: color-mix(in srgb, var(--ac-success) 10%, transparent);
  }

  .qp-status--warning {
    border-color: color-mix(in srgb, var(--ac-warning) 55%, var(--ac-border));
    color: color-mix(in srgb, var(--ac-warning) 85%, var(--ac-text));
    background: color-mix(in srgb, var(--ac-warning) 10%, transparent);
  }

  /* Composer */
  .qp-composer {
    padding: 12px 14px;
    border-top: 1px solid var(--qp-divider);
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .qp-textarea {
    width: 100%;
    min-height: 42px;
    max-height: 160px;
    resize: none;
    padding: 10px 10px;
    border-radius: var(--ac-radius-card);
    border: 1px solid var(--qp-input-border);
    background: var(--qp-input-bg);
    color: var(--ac-text);
    font-family: var(--ac-font-body);
    font-size: 13px;
    line-height: 1.35;
    outline: none;
  }

  .qp-textarea::placeholder {
    color: var(--ac-text-placeholder);
  }

  .qp-actions {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
  }

  .qp-actions-left {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 11px;
    color: var(--ac-text-subtle);
    user-select: none;
  }

  .qp-actions-right {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .qp-kbd {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    border: var(--ac-border-width) solid var(--qp-divider);
    background: var(--ac-surface-muted);
    padding: 4px 8px;
    border-radius: 999px;
    font-family: var(--ac-font-code);
    font-size: 10px;
    color: var(--ac-text-muted);
  }

  /* Empty State */
  .qp-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 12px;
    padding: 40px 20px;
    text-align: center;
    color: var(--ac-text-muted);
  }

  .qp-empty-icon {
    font-size: 32px;
    opacity: 0.6;
  }

  .qp-empty-text {
    font-size: 13px;
    line-height: 1.5;
  }

  /* ============================================================
   * Search UI (Phase 1)
   * ============================================================ */

  /* Search Input Container */
  .qp-search {
    min-width: 0;
    width: 100%;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  /* Scope Chip */
  .qp-scope-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    border: 1px solid var(--qp-divider);
    background: rgba(255, 255, 255, 0.12);
    border-radius: 999px;
    padding: 6px 10px;
    color: var(--ac-text);
    font-family: var(--ac-font-body);
    font-size: 12px;
    cursor: pointer;
    user-select: none;
    flex: none;
    transition: background-color var(--ac-motion-fast);
  }

  .qp-scope-chip:hover {
    background: rgba(255, 255, 255, 0.18);
  }

  .qp-scope-chip__icon {
    font-size: 12px;
    line-height: 1;
  }

  .qp-scope-chip__label {
    font-weight: 600;
    letter-spacing: 0.2px;
    white-space: nowrap;
  }

  .qp-scope-chip__prefix {
    font-family: var(--ac-font-code);
    font-size: 10px;
    padding: 2px 6px;
    border-radius: 999px;
    border: 1px solid var(--qp-divider);
    background: rgba(255, 255, 255, 0.1);
    color: var(--ac-text-muted);
  }

  /* Search Input */
  .qp-search-input {
    flex: 1;
    min-width: 0;
    height: 38px;
    padding: 0 12px;
    border-radius: var(--ac-radius-card);
    border: 1px solid var(--qp-input-border);
    background: var(--qp-input-bg);
    color: var(--ac-text);
    font-family: var(--ac-font-body);
    font-size: 14px;
    line-height: 1.2;
    outline: none;
    transition: border-color var(--ac-motion-fast);
  }

  .qp-search-input:focus {
    border-color: var(--ac-accent);
  }

  .qp-search-input::placeholder {
    color: var(--ac-text-placeholder);
  }

  /* Icon Button (Clear, Close, Action, etc.) */
  .qp-icon-btn {
    width: 28px;
    height: 28px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: var(--ac-border-width) solid var(--qp-divider);
    background: transparent;
    color: var(--ac-text-muted);
    border-radius: var(--ac-radius-button);
    cursor: pointer;
    user-select: none;
    flex: none;
    transition: background-color var(--ac-motion-fast), color var(--ac-motion-fast), border-color var(--ac-motion-fast);
  }

  .qp-icon-btn:hover:not(:disabled) {
    background: var(--ac-hover-bg);
    color: var(--ac-text);
  }

  .qp-icon-btn:disabled {
    cursor: not-allowed;
    opacity: 0.5;
  }

  .qp-icon-btn svg {
    width: 16px;
    height: 16px;
  }

  /* Action button variant (send/stop) */
  .qp-icon-btn--action {
    width: 32px;
    height: 32px;
  }

  .qp-icon-btn--action svg {
    width: 16px;
    height: 16px;
  }

  .qp-icon-btn--primary {
    background: var(--ac-accent);
    border-color: var(--ac-accent);
    color: var(--ac-accent-contrast);
  }

  .qp-icon-btn--primary:hover:not(:disabled) {
    background: var(--ac-accent-hover);
    border-color: var(--ac-accent-hover);
    color: var(--ac-accent-contrast);
  }

  .qp-icon-btn--danger {
    background: var(--ac-danger);
    border-color: var(--ac-danger);
    color: #ffffff;
  }

  .qp-icon-btn--danger:hover:not(:disabled) {
    background: color-mix(in srgb, var(--ac-danger) 85%, #000);
    color: #ffffff;
  }

  /* Quick Entries Grid */
  .qp-entries {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 10px;
    padding: 10px 2px;
  }

  .qp-entry {
    border: var(--ac-border-width) solid var(--qp-divider);
    background: var(--ac-surface);
    border-radius: var(--ac-radius-card);
    padding: 14px 10px;
    cursor: pointer;
    user-select: none;
    color: var(--ac-text);
    font-family: var(--ac-font-body);
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    transition:
      background-color var(--ac-motion-fast),
      border-color var(--ac-motion-fast),
      box-shadow var(--ac-motion-fast);
  }

  .qp-entry:hover {
    background: var(--ac-hover-bg);
    box-shadow: var(--ac-shadow-card);
  }

  .qp-entry:active {
    box-shadow: none;
  }

  .qp-entry:disabled {
    cursor: not-allowed;
    opacity: 0.5;
  }

  .qp-entry[data-active='true'] {
    border-color: var(--ac-accent);
    background: var(--ac-accent-subtle);
  }

  .qp-entry__icon {
    width: 40px;
    height: 40px;
    border-radius: var(--ac-radius-inner);
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--ac-surface-muted);
    border: var(--ac-border-width) solid var(--qp-divider);
    font-size: 16px;
  }

  .qp-entry__label {
    font-weight: 600;
    font-size: 12px;
    letter-spacing: 0.2px;
  }

  .qp-entry__prefix {
    font-family: var(--ac-font-code);
    font-size: 10px;
    color: var(--ac-text-muted);
    border: var(--ac-border-width) solid var(--qp-divider);
    border-radius: 999px;
    padding: 2px 8px;
    background: var(--ac-surface-muted);
  }

  /* View Mount Points */
  .qp-header-mount,
  .qp-header-right-mount,
  .qp-content-mount,
  .qp-footer-mount {
    display: contents;
  }

  .qp-header-mount[hidden],
  .qp-header-right-mount[hidden],
  .qp-content-mount[hidden],
  .qp-footer-mount[hidden] {
    display: none;
  }

  /* Footer Hints */
  .qp-footer-hints {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px;
    padding: 8px 0;
    font-size: 11px;
    color: var(--ac-text-muted);
  }

  .qp-footer-hint {
    display: inline-flex;
    align-items: center;
    gap: 6px;
  }

  /* ============================================================
   * Markdown Content Styles (for markstream-vue)
   * ============================================================ */

  .qp-markdown-content {
    font-size: 13px;
    line-height: 1.5;
    color: var(--ac-text);
  }

  .qp-markdown-content pre {
    background-color: var(--ac-surface-muted);
    border: var(--ac-border-width) solid var(--ac-border);
    border-radius: var(--ac-radius-inner);
    padding: 12px;
    overflow-x: auto;
    margin: 0.5em 0;
  }

  .qp-markdown-content code {
    font-family: var(--ac-font-code);
    font-size: 0.875em;
    color: var(--ac-text);
  }

  .qp-markdown-content :not(pre) > code {
    background-color: var(--ac-surface-muted);
    padding: 0.125em 0.25em;
    border-radius: 4px;
  }

  .qp-markdown-content p {
    margin: 0.5em 0;
  }

  .qp-markdown-content p:first-child {
    margin-top: 0;
  }

  .qp-markdown-content p:last-child {
    margin-bottom: 0;
  }

  .qp-markdown-content ul,
  .qp-markdown-content ol {
    margin: 0.5em 0;
    padding-left: 1.5em;
  }

  .qp-markdown-content li {
    margin: 0.25em 0;
  }

  .qp-markdown-content h1,
  .qp-markdown-content h2,
  .qp-markdown-content h3,
  .qp-markdown-content h4,
  .qp-markdown-content h5,
  .qp-markdown-content h6 {
    margin: 0.75em 0 0.5em;
    font-weight: 600;
    line-height: 1.3;
  }

  .qp-markdown-content h1 { font-size: 1.5em; }
  .qp-markdown-content h2 { font-size: 1.3em; }
  .qp-markdown-content h3 { font-size: 1.15em; }
  .qp-markdown-content h4 { font-size: 1em; }

  .qp-markdown-content blockquote {
    border-left: 3px solid var(--ac-border-strong);
    padding-left: 1em;
    margin: 0.5em 0;
    color: var(--ac-text-muted);
  }

  .qp-markdown-content a {
    color: var(--ac-link);
    text-decoration: underline;
  }

  .qp-markdown-content a:hover {
    color: var(--ac-link-hover);
  }

  .qp-markdown-content table {
    border-collapse: collapse;
    margin: 0.5em 0;
    width: 100%;
    font-size: 0.9em;
  }

  .qp-markdown-content th,
  .qp-markdown-content td {
    border: var(--ac-border-width) solid var(--ac-border);
    padding: 0.5em;
    text-align: left;
  }

  .qp-markdown-content th {
    background-color: var(--ac-surface-muted);
    font-weight: 600;
  }

  .qp-markdown-content hr {
    border: none;
    border-top: var(--ac-border-width) solid var(--ac-border);
    margin: 1em 0;
  }

  .qp-markdown-content img {
    max-width: 100%;
    height: auto;
    border-radius: var(--ac-radius-inner);
  }

  .qp-markdown-content strong {
    font-weight: 600;
  }

  .qp-markdown-content em {
    font-style: italic;
  }
`,C="__mcp_quick_panel_host__",V="__mcp_quick_panel_ui__",ae="__mcp_quick_panel_root__",oe=2147483647,A="agentTheme",_="warm-editorial",D="dark-console",Me=new Set(["warm-editorial","blueprint-architect","zen-journal","neo-pop","dark-console","swiss-grid"]),Pe=new Set(["warm-editorial","blueprint-architect","zen-journal","neo-pop","swiss-grid"]),ze=["pointerdown","pointerup","pointermove","pointerenter","pointerleave","pointercancel","mousedown","mouseup","mousemove","mouseenter","mouseleave","click","dblclick","contextmenu","keydown","keyup","keypress","touchstart","touchmove","touchend","touchcancel","wheel","focus","blur","input","change"];function M(t,e,r){t.style.setProperty(e,r,"important")}function ce(t){if(typeof t!="string")return _;const e=t.trim();return Me.has(e)?e:_}function Re(){var t,e;try{return(e=(t=globalThis.matchMedia)==null?void 0:t.call(globalThis,"(prefers-color-scheme: dark)").matches)!=null?e:!1}catch(r){return!1}}function he(t){return Re()&&Pe.has(t)?D:t}function ve(){return O(this,null,function*(){var t;try{if(!((t=chrome==null?void 0:chrome.storage)!=null&&t.local))return _;const e=yield chrome.storage.local.get(A);return ce(e[A])}catch(e){return _}})}function ie(t,e){const r=ce(e),n=he(r);t.dataset.agentTheme=n}function Le(t={}){var Z,K,j,H,J,ee;const e=new u;let r=null;const n=(Z=t.hostId)!=null?Z:C,c=(K=t.zIndex)!=null?K:oe,o=document.getElementById(n);if(o)try{o.remove()}catch(s){}const i=document.createElement("div");i.id=n,i.setAttribute("data-mcp-quick-panel","true"),M(i,"position","fixed"),M(i,"inset","0"),M(i,"z-index",String(c)),M(i,"pointer-events","none"),M(i,"contain","layout style paint"),M(i,"isolation","isolate");const p=i.attachShadow({mode:"open"}),I=document.createElement("style");I.textContent=g,p.append(I);const x=document.createElement("div");x.id=V,M(x,"position","fixed"),M(x,"inset","0"),M(x,"pointer-events","none"),p.append(x);const w=document.createElement("div");w.id=ae,w.className="agent-theme qp-root";const d=he(_);w.dataset.agentTheme=d,x.append(w),((j=document.documentElement)!=null?j:document.body).append(i),e.add(()=>i.remove()),r={host:i,shadowRoot:p,uiRoot:x,root:w};const T=s=>{s.stopPropagation()};for(const s of ze)e.listen(w,s,T);O(null,null,function*(){const s=yield ve();ie(w,s)});let P=_;O(null,null,function*(){P=yield ve()});const z=(s,y)=>{if(y!=="local")return;const te=s[A];te&&(P=ce(te.newValue),ie(w,P))};try{(J=(H=chrome==null?void 0:chrome.storage)==null?void 0:H.onChanged)==null||J.addListener(z),e.add(()=>{var s,y;return(y=(s=chrome==null?void 0:chrome.storage)==null?void 0:s.onChanged)==null?void 0:y.removeListener(z)})}catch(s){}try{const s=(ee=globalThis.matchMedia)==null?void 0:ee.call(globalThis,"(prefers-color-scheme: dark)");if(s){const y=()=>{ie(w,P)};typeof s.addEventListener=="function"&&(s.addEventListener("change",y),e.add(()=>s.removeEventListener("change",y)))}}catch(s){}const $=s=>{if(!(s instanceof Node))return!1;if(s===i)return!0;const y=typeof s.getRootNode=="function"?s.getRootNode():null;return y instanceof ShadowRoot&&y.host===i};return{getElements:()=>r,isOverlayElement:$,isEventFromUi:s=>{try{if(typeof s.composedPath=="function")return s.composedPath().some(y=>$(y))}catch(y){}return $(s.target)},dispose:()=>{r=null,e.dispose()}}}const Ae="__mcp_element_picker_host__",Ue=2147483647,De=`
  /* Overlay positioning - bottom-right corner */
  .ep-overlay {
    position: fixed;
    inset: 0;
    display: flex;
    align-items: flex-end;
    justify-content: flex-end;
    padding: 16px;
    pointer-events: none;
  }

  /* Panel sizing */
  .ep-panel {
    width: min(480px, calc(100vw - 32px));
    max-height: min(600px, calc(100vh - 32px));
    pointer-events: auto;
  }

  /* Countdown badge */
  .ep-countdown {
    font-family: var(--ac-font-code);
    font-size: 12px;
    color: var(--ac-text-muted);
    padding: 4px 10px;
    border-radius: 999px;
    border: 1px solid var(--qp-glass-divider);
    background: color-mix(in srgb, var(--qp-glass-input-bg) 80%, transparent);
    user-select: none;
    white-space: nowrap;
  }

  .ep-countdown--warning {
    color: var(--ac-warning);
    border-color: color-mix(in srgb, var(--ac-warning) 40%, var(--qp-glass-divider));
  }

  .ep-countdown--danger {
    color: var(--ac-danger);
    border-color: color-mix(in srgb, var(--ac-danger) 40%, var(--qp-glass-divider));
    animation: ep-pulse 1s ease-in-out infinite;
  }

  @keyframes ep-pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.6; }
  }

  /* Hint text */
  .ep-hint {
    margin: 0 0 10px 0;
    font-size: 12px;
    color: var(--ac-text-muted);
  }

  /* Error banner */
  .ep-error {
    margin: 0 0 10px 0;
    padding: 8px 10px;
    border-radius: var(--ac-radius-card);
    border: 1px solid color-mix(in srgb, var(--ac-danger) 55%, var(--ac-border));
    background: color-mix(in srgb, var(--ac-danger) 10%, transparent);
    color: color-mix(in srgb, var(--ac-danger) 85%, var(--ac-text));
    font-size: 12px;
  }

  /* Request list */
  .ep-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  /* Request item card */
  .ep-item {
    border-radius: var(--ac-radius-card);
    border: var(--ac-border-width) solid var(--ac-border);
    box-shadow: var(--ac-shadow-card);
    background: var(--ac-surface);
    padding: 10px 12px;
    transition: border-color var(--ac-motion-fast), box-shadow var(--ac-motion-fast);
  }

  .ep-item--active {
    border-color: color-mix(in srgb, var(--ac-accent) 55%, var(--ac-border));
    box-shadow:
      0 0 0 2px color-mix(in srgb, var(--ac-accent-subtle) 65%, transparent),
      var(--ac-shadow-card);
  }

  /* Item header */
  .ep-item-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
  }

  .ep-item-title {
    min-width: 0;
    font-weight: 600;
    font-size: 13px;
    color: var(--ac-text);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* Status badge */
  .ep-badge {
    flex: none;
    font-size: 11px;
    padding: 2px 8px;
    border-radius: 999px;
    border: 1px solid var(--qp-glass-divider);
    color: var(--ac-text-muted);
    background: color-mix(in srgb, var(--ac-surface-muted) 65%, transparent);
    user-select: none;
  }

  .ep-badge--selected {
    border-color: color-mix(in srgb, var(--ac-success) 55%, var(--qp-glass-divider));
    color: color-mix(in srgb, var(--ac-success) 85%, var(--ac-text));
    background: color-mix(in srgb, var(--ac-success) 10%, transparent);
  }

  .ep-badge--picking {
    border-color: color-mix(in srgb, var(--ac-accent) 55%, var(--qp-glass-divider));
    color: var(--ac-accent);
    background: color-mix(in srgb, var(--ac-accent) 10%, transparent);
    animation: ep-pulse 1.5s ease-in-out infinite;
  }

  /* Description text */
  .ep-desc {
    margin-top: 6px;
    font-size: 12px;
    color: var(--ac-text-muted);
    white-space: pre-wrap;
  }

  /* Picked element info */
  .ep-picked {
    margin-top: 8px;
    font-size: 12px;
    color: var(--ac-text);
    display: flex;
    flex-direction: column;
    gap: 4px;
    padding: 8px;
    border-radius: var(--ac-radius-inner);
    background: var(--ac-surface-muted);
  }

  .ep-picked-text {
    font-weight: 500;
    word-break: break-word;
  }

  .ep-picked-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    font-size: 11px;
  }

  .ep-picked code {
    font-family: var(--ac-font-code);
    font-size: 10px;
    color: var(--ac-text-muted);
    padding: 2px 4px;
    border-radius: 4px;
    background: rgba(0, 0, 0, 0.05);
    word-break: break-all;
  }

  /* Action buttons row */
  .ep-actions {
    margin-top: 8px;
    display: flex;
    gap: 8px;
  }

  /* Footer */
  .ep-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
  }

  .ep-footer-left {
    font-size: 11px;
    color: var(--ac-text-muted);
  }

  .ep-footer-right {
    display: flex;
    gap: 8px;
  }
`;function Fe(t){const e=Math.max(0,t-Date.now()),r=Math.floor(e/1e3),n=Math.floor(r/60),c=r%60,o=`${String(n).padStart(2,"0")}:${String(c).padStart(2,"0")}`;let i="normal";return r<=30?i="danger":r<=60&&(i="warning"),{text:o,level:i}}function xe(t,e=80){const r=String(t||"").trim().replace(/\s+/g," ");return r.length<=e?r:`${r.slice(0,Math.max(0,e-1))}...`}function $e(t={}){var ye,Ie;let e=!1,r=null,n=null,c=null,o=null,i=null,p=null,I=null,x=null,w=null,d=null,S=null,T=null,P=null;const z=new Map,$=(ye=t.hostId)!=null?ye:Ae,qe=(Ie=t.zIndex)!=null?Ie:Ue;function Z(){if(r&&n)return;if(r=Le({hostId:$,zIndex:qe}),n=r.getElements(),!n)throw new Error("Failed to mount Element Picker shadow host");const a=new u;c=a;const m=document.createElement("style");m.textContent=De,n.shadowRoot.append(m),a.add(()=>m.remove()),i=document.createElement("div"),i.className="ep-overlay",p=document.createElement("div"),p.className="qp-panel qp-liquid-shimmer ep-panel",p.setAttribute("role","dialog"),p.setAttribute("aria-modal","false"),p.setAttribute("aria-label","Element Picker");const l=document.createElement("div");l.className="qp-header";const E=document.createElement("div");E.className="qp-header-left";const f=document.createElement("div");f.className="qp-brand",f.textContent="👆";const b=document.createElement("div");b.className="qp-title";const q=document.createElement("div");q.className="qp-title-name",q.textContent="Element Picker";const h=document.createElement("div");h.className="qp-title-sub",h.textContent="Click on the requested elements",b.append(q,h),E.append(f,b);const k=document.createElement("div");k.className="qp-header-right",I=document.createElement("span"),I.className="ep-countdown",I.textContent="03:00",k.append(I),l.append(E,k);const U=document.createElement("div");U.className="qp-content ac-scroll";const R=document.createElement("div");R.className="ep-hint",R.textContent="Click on each element the AI needs. Press Esc to cancel.",x=document.createElement("div"),x.className="ep-error",x.hidden=!0,w=document.createElement("div"),w.className="ep-list",U.append(R,x,w);const pe=document.createElement("div");pe.className="qp-composer";const ue=document.createElement("div");ue.className="ep-footer";const me=document.createElement("div");me.className="ep-footer-left",T=document.createElement("span"),T.textContent="0/0 selected",me.append(T);const fe=document.createElement("div");fe.className="ep-footer-right",S=document.createElement("button"),S.type="button",S.className="qp-btn ac-btn ac-focus-ring",S.textContent="Cancel",d=document.createElement("button"),d.type="button",d.className="qp-btn ac-btn ac-focus-ring qp-btn--primary",d.textContent="Confirm",fe.append(S,d),ue.append(me,fe),pe.append(ue),p.append(l,U,pe),i.append(p),n.root.append(i),a.add(()=>i==null?void 0:i.remove()),a.listen(S,"click",()=>{var N;return(N=t.onCancel)==null?void 0:N.call(t)}),a.listen(d,"click",()=>{var N;return(N=t.onConfirm)==null?void 0:N.call(t)});const _e=N=>{var Ce;N instanceof KeyboardEvent&&N.key==="Escape"&&(N.preventDefault(),N.stopPropagation(),(Ce=t.onCancel)==null||Ce.call(t))};n.shadowRoot.addEventListener("keydown",_e,{capture:!0}),a.add(()=>n==null?void 0:n.shadowRoot.removeEventListener("keydown",_e,{capture:!0}))}function K(){P!==null&&(clearInterval(P),P=null)}function j(){if(!o||!I)return;const a=Fe(o.deadlineTs);I.textContent=a.text,I.className=`ep-countdown${a.level!=="normal"?` ep-countdown--${a.level}`:""}`}function H(a){const m=document.createElement("div");if(m.className="ep-picked",a.text){const h=document.createElement("div");h.className="ep-picked-text",h.textContent=`"${xe(a.text,80)}"`,m.append(h)}const l=document.createElement("div");l.className="ep-picked-meta";const E=document.createElement("code");E.textContent=a.tagName||"element",l.append(E);const f=document.createElement("code");if(f.textContent=`ref=${a.ref}`,l.append(f),a.frameId>0){const h=document.createElement("code");h.textContent=`frame=${a.frameId}`,l.append(h)}m.append(l);const b=document.createElement("div"),q=document.createElement("code");return q.textContent=xe(a.selector||"",100),b.append(q),m.append(b),m}function J(a){const m=document.createElement("div");m.className="ep-item",m.dataset.requestId=a.id;const l=document.createElement("div");l.className="ep-item-header";const E=document.createElement("div");E.className="ep-item-title",E.textContent=a.name;const f=document.createElement("div");if(f.className="ep-badge",f.textContent="Pending",l.append(E,f),m.append(l),a.description){const k=document.createElement("div");k.className="ep-desc",k.textContent=a.description,m.append(k)}const b=document.createElement("div");b.className="ep-actions";const q=document.createElement("button");q.type="button",q.className="qp-btn ac-btn ac-focus-ring",q.textContent="Pick",q.addEventListener("click",()=>{var k;return(k=t.onSetActiveRequest)==null?void 0:k.call(t,a.id)});const h=document.createElement("button");return h.type="button",h.className="qp-btn ac-btn ac-focus-ring",h.textContent="Clear",h.disabled=!0,h.addEventListener("click",()=>{var k;return(k=t.onClearSelection)==null?void 0:k.call(t,a.id)}),b.append(q,h),m.append(b),{container:m,badge:f,pickedContainer:null,pickBtn:q,clearBtn:h}}function ee(a,m,l,E){var U;const{container:f,badge:b,pickBtn:q,clearBtn:h}=a;f.classList.toggle("ep-item--active",E),l?(b.className="ep-badge ep-badge--selected",b.textContent="Selected"):E?(b.className="ep-badge ep-badge--picking",b.textContent="Picking..."):(b.className="ep-badge",b.textContent="Pending"),q.textContent=E?"Picking...":"Pick",q.disabled=E,h.disabled=!l;const k=f.querySelector(".ep-actions");if(l)if(a.pickedContainer){const R=H(l);a.pickedContainer.replaceWith(R),a.pickedContainer=R}else{const R=H(l);(U=k==null?void 0:k.parentNode)==null||U.insertBefore(R,k),a.pickedContainer=R}else a.pickedContainer&&(a.pickedContainer.remove(),a.pickedContainer=null)}function s(){if(!(!o||!w)){w.innerHTML="",z.clear();for(const a of o.requests){const m=J(a);z.set(a.id,m),w.append(m.container)}}}function y(){if(!o||!w||!I||!d||!x||!T)return;j();const a=o.errorMessage?o.errorMessage.trim():"";a?(x.hidden=!1,x.textContent=a):(x.hidden=!0,x.textContent=""),(z.size!==o.requests.length||o.requests.some(f=>!z.has(f.id)))&&s();let l=0;for(const f of o.requests){const b=o.selections[f.id]||null,q=o.activeRequestId===f.id;b&&l++;const h=z.get(f.id);h&&ee(h,f,b,q)}T.textContent=`${l}/${o.requests.length} selected`;const E=l===o.requests.length;d.disabled=!E,d.textContent=E?"Confirm":`Confirm (${l}/${o.requests.length})`}function te(a){e||(Z(),o=a,y(),K(),P=setInterval(()=>{e||!o||j()},250))}function Ve(a){var m,l,E,f,b;e||!o||o.sessionId!==a.sessionId||(o=be(ne(ne({},o),a),{sessionId:o.sessionId,requests:(m=a.requests)!=null?m:o.requests,activeRequestId:(l=a.activeRequestId)!=null?l:o.activeRequestId,selections:(E=a.selections)!=null?E:o.selections,deadlineTs:(f=a.deadlineTs)!=null?f:o.deadlineTs,errorMessage:(b=a.errorMessage)!=null?b:o.errorMessage}),y())}function ke(){K(),o=null,z.clear();try{c==null||c.dispose()}finally{c=null}i=null,p=null,I=null,x=null,w=null,d=null,S=null,T=null;try{r==null||r.dispose()}finally{r=null,n=null}}function Be(){e||(e=!0,ke())}return{show:te,update:Ve,hide:ke,isVisible:()=>!!r&&!!n,dispose:Be}}const B={ELEMENT_PICKER_UI_EVENT:"element_picker_ui_event"},G={ELEMENT_PICKER_UI_PING:"elementPickerUiPing",ELEMENT_PICKER_UI_SHOW:"elementPickerUiShow",ELEMENT_PICKER_UI_UPDATE:"elementPickerUiUpdate",ELEMENT_PICKER_UI_HIDE:"elementPickerUiHide"},Ke={matches:["<all_urls>"],runAt:"document_idle",main(){if(window.top!==window)return;let t=null,e=null;function r(){return t||(t=$e({onCancel:()=>{e&&chrome.runtime.sendMessage({type:B.ELEMENT_PICKER_UI_EVENT,sessionId:e,event:"cancel"})},onConfirm:()=>{e&&chrome.runtime.sendMessage({type:B.ELEMENT_PICKER_UI_EVENT,sessionId:e,event:"confirm"})},onSetActiveRequest:c=>{e&&chrome.runtime.sendMessage({type:B.ELEMENT_PICKER_UI_EVENT,sessionId:e,event:"set_active_request",requestId:c})},onClearSelection:c=>{e&&chrome.runtime.sendMessage({type:B.ELEMENT_PICKER_UI_EVENT,sessionId:e,event:"clear_selection",requestId:c})}}),t)}function n(c,o,i){var I,x,w;const p=c;if(!(p!=null&&p.action))return!1;if(p.action===G.ELEMENT_PICKER_UI_PING)return i({success:!0}),!0;if(p.action===G.ELEMENT_PICKER_UI_SHOW){const d=p;if(e=typeof d.sessionId=="string"?d.sessionId:null,!e)return i({success:!1,error:"Missing sessionId"}),!0;const S=r(),T={sessionId:e,requests:Array.isArray(d.requests)?d.requests:[],activeRequestId:(I=d.activeRequestId)!=null?I:null,selections:{},deadlineTs:typeof d.deadlineTs=="number"?d.deadlineTs:Date.now(),errorMessage:null};return S.show(T),i({success:!0}),!0}if(p.action===G.ELEMENT_PICKER_UI_UPDATE){const d=p;return!e||d.sessionId!==e?(i({success:!1,error:"Session mismatch"}),!0):(t==null||t.update({sessionId:e,activeRequestId:(x=d.activeRequestId)!=null?x:null,selections:d.selections||{},deadlineTs:d.deadlineTs,errorMessage:(w=d.errorMessage)!=null?w:null}),i({success:!0}),!0)}return p.action===G.ELEMENT_PICKER_UI_HIDE?(e&&p.sessionId!==e&&console.warn("[ElementPicker] Session mismatch on hide, hiding anyway"),t==null||t.hide(),e=null,i({success:!0}),!0):!1}chrome.runtime.onMessage.addListener(n),window.addEventListener("unload",()=>{chrome.runtime.onMessage.removeListener(n),t==null||t.dispose(),t=null,e=null})}},Y=(Ee=(we=globalThis.browser)==null?void 0:we.runtime)!=null&&Ee.id?globalThis.browser:globalThis.chrome;function Q(t,...e){}const je={debug:(...t)=>Q(console.debug,...t),log:(...t)=>Q(console.log,...t),warn:(...t)=>Q(console.warn,...t),error:(...t)=>Q(console.error,...t)},X=class X extends Event{constructor(e,r){super(X.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=r}};L(X,"EVENT_NAME",de("wxt:locationchange"));let se=X;function de(t){var e;return`${(e=Y==null?void 0:Y.runtime)==null?void 0:e.id}:element-picker:${t}`}function He(t){let e,r;return{run(){e==null&&(r=new URL(location.href),e=t.setInterval(()=>{let n=new URL(location.href);n.href!==r.href&&(window.dispatchEvent(new se(n,r)),r=n)},1e3))}}}const F=class F{constructor(e,r){L(this,"isTopFrame",window.self===window.top);L(this,"abortController");L(this,"locationWatcher",He(this));L(this,"receivedMessageIds",new Set);this.contentScriptName=e,this.options=r,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return Y.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,r){const n=setInterval(()=>{this.isValid&&e()},r);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,r){const n=setTimeout(()=>{this.isValid&&e()},r);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){const r=requestAnimationFrame((...n)=>{this.isValid&&e(...n)});return this.onInvalidated(()=>cancelAnimationFrame(r)),r}requestIdleCallback(e,r){const n=requestIdleCallback((...c)=>{this.signal.aborted||e(...c)},r);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,r,n,c){var o;r==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(o=e.addEventListener)==null||o.call(e,r.startsWith("wxt:")?de(r):r,n,be(ne({},c),{signal:this.signal}))}notifyInvalidated(){this.abort("Content script context invalidated"),je.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:F.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(e){var o,i,p;const r=((o=e.data)==null?void 0:o.type)===F.SCRIPT_STARTED_MESSAGE_TYPE,n=((i=e.data)==null?void 0:i.contentScriptName)===this.contentScriptName,c=!this.receivedMessageIds.has((p=e.data)==null?void 0:p.messageId);return r&&n&&c}listenForNewerScripts(e){let r=!0;const n=c=>{if(this.verifyScriptStartedEvent(c)){this.receivedMessageIds.add(c.data.messageId);const o=r;if(r=!1,o&&(e!=null&&e.ignoreFirstEvent))return;this.notifyInvalidated()}};addEventListener("message",n),this.onInvalidated(()=>removeEventListener("message",n))}};L(F,"SCRIPT_STARTED_MESSAGE_TYPE",de("wxt:content-script-started"));let le=F;function Xe(){}function W(t,...e){}const Oe={debug:(...t)=>W(console.debug,...t),log:(...t)=>W(console.log,...t),warn:(...t)=>W(console.warn,...t),error:(...t)=>W(console.error,...t)};return O(null,null,function*(){try{const t=Ke,{main:e}=t,r=Ne(t,["main"]),n=new le("element-picker",r);return yield e(n)}catch(e){throw Oe.error('The content script "element-picker" crashed on startup!',e),e}})})();
elementPicker;