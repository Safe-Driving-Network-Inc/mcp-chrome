/* eslint-disable */
// fill-helper.js
// This script is injected into the page to handle form filling operations

if (window.__FILL_HELPER_INITIALIZED__) {
  // Already initialized, skip
} else {
  window.__FILL_HELPER_INITIALIZED__ = true;

  // Resolve a fill target when the caller gives no selector/ref: prefer the
  // currently focused editable element; else the single visible editable box on
  // the page (input/textarea/contenteditable/[role=textbox]). Matches the common
  // case of a compose field that auto-focuses, so the agent can "just type".
  function __kResolveFillTarget() {
    const fillable = (el) => {
      if (!el || el.nodeType !== 1) return false;
      const tag = el.tagName;
      if (tag === 'TEXTAREA') return true;
      if (tag === 'INPUT') {
        const t = (el.getAttribute('type') || 'text').toLowerCase();
        return !['hidden', 'submit', 'button', 'checkbox', 'radio', 'file', 'image'].includes(t);
      }
      return el.isContentEditable || el.getAttribute('role') === 'textbox';
    };
    const visible = (el) => {
      let s;
      try {
        s = window.getComputedStyle(el);
      } catch (e) {
        return false;
      }
      if (!s || s.display === 'none' || s.visibility === 'hidden' || s.opacity === '0')
        return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    };
    // 1. focused element
    const active = document.activeElement;
    if (active && fillable(active) && visible(active)) return active;
    // 2. single visible editable box (prefer a message compose field)
    const all = Array.from(
      document.querySelectorAll('textarea, input, [contenteditable="true"], [role="textbox"]'),
    ).filter((el) => fillable(el) && visible(el));
    if (!all.length) return null;
    const compose = all.find((el) => /msg-form|compose|message/i.test(el.className || ''));
    return compose || all[0];
  }

  /**
   * Fill an input element with the specified value
   * @param {string} selector - CSS selector for the element to fill
   * @param {string} value - Value to fill into the element
   * @returns {Promise<Object>} - Result of the fill operation
   */
  async function fillElement(selector, value, ref = null, expectEpoch = null) {
    try {
      // Find the element
      let element = null;
      if (ref && typeof ref === 'string') {
        // Resolve through k-dom-core when present (epoch-checked: STALE_REF /
        // DETACHED come back as structured errors); the legacy map otherwise.
        if (typeof window.__kResolveRef === 'function') {
          const res = window.__kResolveRef(ref, expectEpoch);
          if (res && res.error) return res;
          element = res && res.el;
        } else {
          try {
            const map = window.__claudeElementMap;
            const weak = map && map[ref];
            element = weak && typeof weak.deref === 'function' ? weak.deref() : null;
          } catch (e) {
            // ignore
          }
        }
        if (!element || !(element instanceof Element)) {
          return {
            error: { code: 'STALE_REF', message: `Element ref "${ref}" is not known in this frame — take a new browser_snapshot.`, details: { ref } },
          };
        }
      } else if (selector) {
        // Reuse click-helper's text-aware resolver when present (supports
        // text=Label targeting); otherwise resolve safely without throwing on an
        // invalid CSS selector.
        element =
          typeof window.__kResolveElement === 'function'
            ? window.__kResolveElement(selector)
            : (function () {
                // Deep query across OPEN shadow roots — LinkedIn-class UIs render
                // the composer inside a shadow root where document.querySelector
                // sees nothing (upload-helper has the same traversal).
                function deep(sel, root, depth) {
                  if (depth > 10) return null;
                  try {
                    const hit = root.querySelector(sel);
                    if (hit) return hit;
                  } catch (e) {
                    return null;
                  }
                  let all = [];
                  try {
                    all = root.querySelectorAll('*');
                  } catch (e) {
                    return null;
                  }
                  for (let j = 0; j < all.length; j++) {
                    if (all[j].shadowRoot) {
                      const found = deep(sel, all[j].shadowRoot, depth + 1);
                      if (found) return found;
                    }
                  }
                  return null;
                }
                return deep(selector, document, 0);
              })();
      } else {
        // No selector and no ref: target the focused editable element, else the
        // single obvious editable box (e.g. a message compose field that
        // auto-focuses). Lets the agent "just type into the focused box".
        element = __kResolveFillTarget();
      }
      if (!element) {
        return {
          error: {
            code: 'NOT_FOUND',
            message: selector
              ? `Element with selector "${selector}" not found in this frame`
              : `No selector given and no focused/visible editable field was found`,
            details: { selector: selector || null },
          },
        };
      }

      // Bring it on screen BEFORE judging visibility — a snapshot ref may point
      // below the fold, and "not visible" for an off-screen field was a false
      // negative (the fill used to scroll into view only after the check).
      try {
        element.scrollIntoView({ behavior: 'auto', block: 'center', inline: 'center' });
      } catch (_) {}
      await new Promise((resolve) => setTimeout(resolve, 80));

      // Get element information
      const rect = element.getBoundingClientRect();
      const elementInfo = {
        tagName: element.tagName,
        id: element.id,
        className: element.className,
        type: element.type || null,
        isVisible: isElementVisible(element),
        rect: {
          x: rect.x,
          y: rect.y,
          width: rect.width,
          height: rect.height,
          top: rect.top,
          right: rect.right,
          bottom: rect.bottom,
          left: rect.left,
        },
      };

      // Check if element is visible
      if (!elementInfo.isVisible) {
        return {
          error: { code: 'NOT_VISIBLE', message: `Element ${ref || '"' + selector + '"'} is not visible (hidden, zero-size or covered)`, details: { selector: selector || null, ref: ref || null } },
          elementInfo,
        };
      }
      if (element.disabled || element.getAttribute('aria-disabled') === 'true') {
        return {
          error: { code: 'DISABLED', message: `Element ${ref || '"' + selector + '"'} is disabled — the page must enable it first`, details: { selector: selector || null, ref: ref || null } },
          elementInfo,
        };
      }

      // Check if element is an input, textarea, or select
      const validTags = ['INPUT', 'TEXTAREA', 'SELECT'];
      // Keep a permissive list to allow type-specific branches below to handle behavior
      const validInputTypes = [
        'text',
        'email',
        'password',
        'number',
        'search',
        'tel',
        'url',
        'date',
        'datetime-local',
        'month',
        'time',
        'week',
        'color',
        'checkbox',
        'radio',
        'range',
      ];

      // Rich-text editors (LinkedIn, Gmail, Notion, etc.) are contenteditable
      // DIVs, not form controls — they're fillable too (handled by a dedicated
      // branch below). Let them pass the tag gate.
      if (!validTags.includes(element.tagName) && !element.isContentEditable) {
        // If the element is a custom element with open shadow root, try to find a fillable inner control
        try {
          const anyEl = /** @type {any} */ (element);
          const sr = anyEl && anyEl.shadowRoot ? anyEl.shadowRoot : null;
          if (sr) {
            // Search common fillable targets inside shadow root (breadth-first)
            const queue = Array.from(sr.children || []);
            const isFillable = (el) =>
              !!el &&
              (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT');
            while (queue.length) {
              const cur = queue.shift();
              if (!cur) continue;
              if (isFillable(cur)) {
                element = cur;
                break;
              }
              try {
                const children = cur.children || [];
                for (let i = 0; i < children.length; i++) queue.push(children[i]);
                const innerSr = /** @type {any} */ (cur).shadowRoot;
                if (innerSr && innerSr.children) {
                  for (let i = 0; i < innerSr.children.length; i++) queue.push(innerSr.children[i]);
                }
              } catch (_) {}
            }
            if (!validTags.includes(element.tagName)) {
              return {
                error: { code: 'NOT_FILLABLE', message: `Element ${ref || '"' + selector + '"'} is not a fillable element (must be an input, textarea, select or a rich-text editor)` },
                elementInfo,
              };
            }
          } else {
            return {
              error: { code: 'NOT_FILLABLE', message: `Element ${ref || '"' + selector + '"'} is not a fillable element (must be an input, textarea, select or a rich-text editor)` },
              elementInfo,
            };
          }
        } catch (_) {
          return {
            error: { code: 'NOT_FILLABLE', message: `Element ${ref || '"' + selector + '"'} is not a fillable element (must be an input, textarea, select or a rich-text editor)` },
            elementInfo,
          };
        }
      }

      // For input elements, check if the type is valid (allow type-specific branches below)
      if (
        element.tagName === 'INPUT' &&
        !validInputTypes.includes(element.type) &&
        element.type !== null
      ) {
        return {
          error: { code: 'NOT_FILLABLE', message: `Input ${ref || '"' + selector + '"'} has type "${element.type}" which is not fillable` },
          elementInfo,
        };
      }

      // Scroll element into view
      element.scrollIntoView({ behavior: 'auto', block: 'center', inline: 'center' });
      await new Promise((resolve) => setTimeout(resolve, 100));

      // Focus the element
      element.focus();

      // Type-specific handling for tricky inputs first
      if (element.tagName === 'INPUT' && element.type === 'checkbox') {
        // Accept boolean or string-like boolean
        let checkedVal;
        if (typeof value === 'boolean') {
          checkedVal = value;
        } else if (typeof value === 'string') {
          const v = value.trim().toLowerCase();
          if (['true', '1', 'yes', 'on'].includes(v)) checkedVal = true;
          else if (['false', '0', 'no', 'off'].includes(v)) checkedVal = false;
        }
        if (typeof checkedVal !== 'boolean') {
          return {
            error:
              'Checkbox requires a boolean (true/false) or a boolean-like string ("true"/"false"/"on"/"off").',
            elementInfo,
          };
        }
        const previous = element.checked;
        element.checked = checkedVal;
        element.focus();
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
        element.blur();
        return {
          success: true,
          message: `Checkbox set to ${element.checked}`,
          elementInfo: { ...elementInfo, checked: element.checked, previousChecked: previous },
        };
      }

      if (element.tagName === 'INPUT' && element.type === 'radio') {
        // For radios, the selector/ref should target the specific input to select
        const previous = element.checked;
        element.checked = true;
        element.focus();
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
        element.blur();
        return {
          success: true,
          message: 'Radio selected',
          elementInfo: {
            ...elementInfo,
            checked: element.checked,
            previousChecked: previous,
            name: element.name || null,
          },
        };
      }

      if (element.tagName === 'INPUT' && element.type === 'range') {
        const numericValue = typeof value === 'number' ? value : Number(value);
        if (Number.isNaN(numericValue)) {
          return { error: 'Range input requires a numeric value', elementInfo };
        }
        const previous = element.value;
        element.value = String(numericValue);
        element.focus();
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
        element.blur();
        return {
          success: true,
          message: `Set range to ${element.value} (min: ${element.min}, max: ${element.max})`,
          elementInfo: { ...elementInfo, value: element.value },
        };
      }

      if (element.tagName === 'INPUT' && element.type === 'number') {
        if (value !== '' && value !== null && value !== undefined && Number.isNaN(Number(value))) {
          return { error: 'Number input requires a numeric value', elementInfo };
        }
        const previous = element.value;
        element.value = String(value ?? '');
        element.focus();
        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
        element.blur();
        return {
          success: true,
          message: `Set number input to ${element.value} (previous: ${previous})`,
          elementInfo: { ...elementInfo, value: element.value },
        };
      }

      // Rich-text / contenteditable editors (LinkedIn, Gmail, Notion, ProseMirror,
      // Draft.js, etc.). element.value is meaningless here; insert through the
      // native editing pipeline so the host framework's beforeinput/input handlers
      // see it (setting textContent alone is usually ignored by these editors).
      if (element.isContentEditable) {
        element.focus();
        // Select all existing content so the insert replaces it.
        try {
          const sel = window.getSelection();
          const range = document.createRange();
          range.selectNodeContents(element);
          sel.removeAllRanges();
          sel.addRange(range);
        } catch (_) {}
        let inserted = false;
        try {
          inserted = document.execCommand('insertText', false, String(value));
        } catch (_) {
          inserted = false;
        }
        if (!inserted) {
          // Fallback: clear + set textContent + fire an input event so frameworks react.
          element.textContent = String(value);
          element.dispatchEvent(
            new InputEvent('input', {
              bubbles: true,
              cancelable: true,
              inputType: 'insertText',
              data: String(value),
            }),
          );
        }
        element.dispatchEvent(new Event('change', { bubbles: true }));
        if (typeof element.blur === 'function') element.blur();
        return {
          success: true,
          message: 'Filled contenteditable element' + (inserted ? '' : ' (textContent fallback)'),
          elementInfo: { ...elementInfo, isContentEditable: true },
        };
      }

      // Fill the element based on its type
      if (element.tagName === 'SELECT') {
        // For select elements, find the option with matching value or text
        let optionFound = false;
        for (const option of element.options) {
          if (option.value === value || option.text === value) {
            element.value = option.value;
            optionFound = true;
            break;
          }
        }

        if (!optionFound) {
          return {
            error: `No option with value or text "${value}" found in select element`,
            elementInfo,
          };
        }

        // Trigger change event
        element.dispatchEvent(new Event('change', { bubbles: true }));
      } else {
        // Input / textarea. Use the NATIVE value setter so React-controlled inputs
        // (which override the value property) actually fire their onChange — setting
        // element.value directly is silently swallowed by React's synthetic events.
        let nativeSetter = null;
        try {
          const proto =
            element.tagName === 'TEXTAREA'
              ? window.HTMLTextAreaElement.prototype
              : window.HTMLInputElement.prototype;
          const desc = Object.getOwnPropertyDescriptor(proto, 'value');
          nativeSetter = desc && desc.set ? desc.set : null;
        } catch (_) {
          nativeSetter = null;
        }
        const setVal = (v) => {
          if (nativeSetter) {
            try {
              nativeSetter.call(element, v);
              return;
            } catch (_) {}
          }
          element.value = v;
        };
        // Clear the current value then set new value
        setVal('');
        element.dispatchEvent(new Event('input', { bubbles: true }));

        setVal(String(value));

        element.dispatchEvent(new Event('input', { bubbles: true }));
        element.dispatchEvent(new Event('change', { bubbles: true }));
      }

      // Blur the element
      element.blur();

      return {
        success: true,
        message: 'Element filled successfully',
        elementInfo: {
          ...elementInfo,
          value: element.value, // Include the final value in the response
        },
      };
    } catch (error) {
      return {
        error: { code: 'EXECUTION_ERROR', message: `Error filling element: ${error.message}` },
      };
    }
  }

  /**
   * Check if an element is visible
   * @param {Element} element - The element to check
   * @returns {boolean} - Whether the element is visible
   */
  function isElementVisible(element) {
    if (!element) return false;

    const style = window.getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
      return false;
    }

    const rect = element.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) {
      return false;
    }

    // Check if element is within viewport
    if (
      rect.bottom < 0 ||
      rect.top > window.innerHeight ||
      rect.right < 0 ||
      rect.left > window.innerWidth
    ) {
      return false;
    }

    // Check if element is actually visible at its center point
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const elementAtPoint = document.elementFromPoint(centerX, centerY);
    if (!elementAtPoint) return false;

    // Accept the target, a descendant, or an ANCESTOR at the point (a label span
    // with pointer-events:none hands the hit to the owning control — the norm on
    // hashed-class sites; click-helper accepts the same).
    return (
      element === elementAtPoint ||
      element.contains(elementAtPoint) ||
      elementAtPoint.contains(element)
    );
  }

  // Listen for messages from the extension
  chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    if (request.action === 'fillElement') {
      fillElement(request.selector, request.value, request.ref, request.expect_epoch)
        .then(sendResponse)
        .catch((error) => {
          sendResponse({
            error: `Unexpected error: ${error.message}`,
          });
        });
      return true; // Indicates async response
    } else if (request.action === 'chrome_fill_or_select_ping') {
      sendResponse({ status: 'pong' });
      return false;
    }
  });
}
